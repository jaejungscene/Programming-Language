var linkRoutes = [
    {
        url:'/login',
        // element:loginView,
        name:'login',
        independent: true
    },
    {
        url:'*',
        // element:Error404,
        name:'error404',
        independent: true
        
    }
]
console.log(typeof(linkRoutes));
export default linkRoutes;