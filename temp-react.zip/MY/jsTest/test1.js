// import linkRoutes from "./routes";

var linkRoutes = [
    {
        url:'/login',
        // element:loginView,
        name:'login',
        independent: true
    },
    {
        url:'*',
        // element:Error404,
        name:'error404',
        independent: true
        
    }
]

linkRoutes.map((props, key) => {
    console.log(props, key);
})

// let arr = [2, 3, 5, 7]

// arr.map((element, index, array) => {
//     console.log(element);
//     console.log(index);
//     console.log(array);
//     console.log(this);
//     console.log();
//     // return element;
// });