import './App.css';
import { ComponentOnlyOnce, DontDoThisComponent } from './test/useStateTest';
import linkRoutes from './routes';
import { BrowserRouter, Route, Routes } from 'react-router-dom/dist';

function App() {
  linkRoutes.map((props, key) => {
    console.log("props: ",props);
    console.log("key: ",key);
  });

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          {linkRoutes.map((props, key) => {
            return (
              <Route
                path={props.url}
                element={<props.element/>}
                key={key}
              />
            )
          })}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
