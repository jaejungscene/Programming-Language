import React from "react";

//useEffect의 두 번째 인자(배열)에 값이 없으면 딱 한 번만 로딩되고 실행되지 않습니다.
function ComponentOnlyOnce(){
	const [time, setTime] = React.useState(0);
    React.useEffect(() => {
        setTime(time+1); //state를 바꿔서 또 렌더링이 되더라도 setTime은 호출되지 않습니다.
        console.log(time+'컴포넌트가 화면에 처음 렌더링될 때 딱 한 번 실행됩니다.');
    }, []);
    console.log(time);
    return (
        <div>
            hello world {time}
        </div>
    )
}

//아래와 같이 하면 안됩니다.
function DontDoThisComponent(){
    const [time, setTime] = React.useState(0);
    React.useEffect(() => {
        setTime(time+1); //state인 time을 업데이트하면 useEffect안의 함수가 또 실행됩니다.
        console.log('time이 바뀔 때마다 계속 업데이트됩니다.');
    }, [time]); //time이 업데이트 될때마다 함수가 실행됩니다.
}

export {ComponentOnlyOnce, DontDoThisComponent};