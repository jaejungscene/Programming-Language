import Error404 from "./components/Error404";
import LoginView from "./components/LoginView";
import Main from "./components/Main";
import ReactLogoSpinView from "./components/ReactLogoSpinView";

var linkRoutes = [
    {
        url:'/',
        element:ReactLogoSpinView,
        name:'react logo',
        independent: true

    },

    {
        url:'/main',
        element:Main,
        name:'main',
        independent: true
    },
    {
        url:'/login',
        element:LoginView,
        name:'login',
        independent: true
    },
    {
        url:'*',
        element:Error404,
        name:'error404',
        independent: true
        
    }
]

export default linkRoutes;