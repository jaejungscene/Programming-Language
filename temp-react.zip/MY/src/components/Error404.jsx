import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Stack } from "react-bootstrap/esm";
import { Link } from "react-router-dom/dist";

function Error404() {
    console.log("ERROR404");
    return (
        <Stack style={{ alignItems: 'center' }}>
            <FontAwesomeIcon style={{ marginTop: '5%' }} color='gray' size='10x' />
            <h1 style={{ fontSize: '100px'}}>Error 404</h1>
            <h4>This requested URL was not found.</h4>
            <Link to='/'> Return to Home</Link>
        </Stack>
    );
}

export default Error404