function Main(){
    return (
        <div style={{ fontSize: '100px'}}>
            main page
        </div>
    )
}
export default Main;