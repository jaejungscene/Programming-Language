function LoginView(){
    return (
        <div style={{ fontSize: '100px'}}>
            login page
        </div>
    )
}

export default LoginView;