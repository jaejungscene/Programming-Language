import React from 'react';
import MainView from './components/views/MainView';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import linkRoutes from './routes';
import "./public/bootstrap/dist/css/bootstrap.css"
import './public/css/compile.css';
import useStore from './stores/useStore';
import PrivateRoute from './components/parts/Common/PrivateRoute';


const App = () => {
  console.log("APP");
  const { mainViewStore } = useStore();
  mainViewStore.mainViewInitialize();
  //mainViewStore.setLanguage();

  return (
    <BrowserRouter>
      {/* 라우팅 처리는 프로그램 시작 시에 해줍니다.*/}
      <Routes>
        {linkRoutes.map((props, key) => {
          if (props.independent === true) {
            return (
              <Route
                path={props.url}
                element={<props.element />}
                key={key}
              />
            );
          }
          console.log(props);
        })}
        {/* <Route          
          path="/"
          element={
            <PrivateRoute store={mainViewStore} temp={'hello'}>
              <MainView />
            </PrivateRoute>
          }
        >
          {linkRoutes.map((props, key) => {
            if (props.independent === false) {
              return (
                <Route
                  path={props.url}
                  element={
                    <PrivateRoute store={mainViewStore}>
                      <props.element />
                    </PrivateRoute>
                  }
                  key={key}
                />
              );
            }
          })}
        </Route> */}
      </Routes>
    </BrowserRouter>
  );
};

export default App;
