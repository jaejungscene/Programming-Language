import trendMonitoringView from './components/parts/TrendMonitoringView';
import IpMonitoringView from './components/parts/IpMonitoringView';
import dryView from './components/parts/DryingFurnaceView';
import eqpView from './components/parts/EquipmentManagementView';
import logView from './components/parts/LogManagementView';
import machineAgentView from './components/parts/MachineAgentView';
import alarmHistoryView from './components/parts/AlarmHistoryView';
import settingView from './components/parts/SettingView';
import PlcMemoryMapEdit from './components/views/PlcMemoryMapEditView'
import userView from './components/parts/UserManagementView';
import loginView from './components/views/LoginView';
import Error404 from './components/views/Error404';
import drivingPartsView from './components/parts/DrivingPartsView';

var linkRoutes = [
    {
        url:'/login',
        element:loginView,
        name:'login',
        independent: true
        
    },
    {
        url:'*',
        element:Error404,
        name:'error404',
        independent: true
        
    },
    {
        url:'/dashboard/trendMonitoring',
        element:trendMonitoringView,
        name:'dashboard',
        independent: false
    },
    {
        url:'/dashboard/ipMonitoring',
        element:IpMonitoringView,
        name:'dashboard3',
        independent: false
    },
    {
        url:'/monitoring/dryZone',
        element:dryView,
        name:'dryZone',
        independent: false
    },
    {
        url:'/monitoring/drivingParts',
        element:drivingPartsView,
        name:'drivingParts',
        independent: false
    },
    {
        url:'/alarmHistory',
        element:alarmHistoryView,
        name:'alarmHistory',
        independent: false
    },
    {
        url:'/machineAgent',
        element:machineAgentView,
        name:'machineAgent',
        independent: false
    },
    {
        url:'/system/userManagement',
        element:userView,
        name:'userManagement',
        independent: false
    },
    {
        url:'/system/equipmentManagement',
        element:eqpView,
        name:'equipmentManagement',
        independent: false
    },
    {
        url:'/system/logManagement',
        element:logView,
        name:'logManagement',
        independent: false
    },
    {
        url:'/system/setting',
        element:settingView,
        name:'setting',
        independent: false
    },
    {
        url:'/system/setting/PlcCollectionEdit',
        element:settingView,
        name:'PlcCollectionEdit',
        independent: false
    },
    {
        url:'/system/setting',
        element:PlcMemoryMapEdit,
        name:'PlcMemoryMapEdit',
        independent: false
    }
]

export default linkRoutes;