import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import './languages/i18n';


const root = document.getElementById("root");

createRoot(root).render(
  <React.StrictMode> {/**StricMode일 때 UseEffect가 두 번 랜더링된다. 릴리즈 모드에서는 발생하지 않음. */}
    <App />
  </React.StrictMode>
);
