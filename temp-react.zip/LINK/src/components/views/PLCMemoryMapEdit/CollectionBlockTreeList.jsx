import { Observer, PropTypes } from 'mobx-react';
import Stack from 'react-bootstrap/Stack';
import useStore from '../../../stores/useStore'
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { DropDownList } from '@progress/kendo-react-dropdowns';
import KendoLoading from '../../parts/Common/KendoLoading';
import CheckEditPermissionForm from "../../parts/PlcEditParts/CheckEditPermissionForm";
import NotPlcListView from '../../parts/PlcEditParts/NotPlcListView';
import NotEditPlcPermission from '../../parts/PlcEditParts/NotEditPlcPermission';
import swal from 'sweetalert2';

import {
    TreeList,
    TreeListToolbar,
    mapTree,
    extendDataItem,
    removeItems,
    modifySubItems,
    TreeListTextEditor,
    TreeListBooleanEditor,
    TreeListNumericEditor,
} from "@progress/kendo-react-treelist";

import treeListCell from "./TreeListCell";

let isBlockBtnCheck = false;

function CollectionBlockTreeList(props) {

    const { mainViewStore } = useStore();
    const { PLCAddressEditStore } = useStore();
    const [loading, setLoading] = useState(false);
    const [openPermissionCheckForm, setOpenPermissionCheckForm] = useState(false);
    const [enabelSave, setEnableSave] = useState(false);
    const [enableCancle, setEnableCancle] = useState(false);
    const [collectionInfoList, setCollectionInfoList] = useState({
        collectionData: [],
        expanded: [1, 2, 32],
        inEdit: [],
    });
    const { collectionData, expanded, inEdit } = collectionInfoList;
    const subItemsField = "BlockList";
    const expandField = "expanded";
    const editField = "inEdit";
    const navigate = useNavigate();
    const [curPlcIndex, setCurPlcIndex] = useState(0);

    useEffect(() => {
        setCurPlcIndex(PLCAddressEditStore.currentPlcInfoId - 1);
        ViewCollectionBlockInfo();
    }, [PLCAddressEditStore.plcMemoryMap])

    useEffect(() => {
        plcInfoListinitialize();

    }, []);
    async function plcInfoListinitialize() {
        await PLCAddressEditStore.initializeComponentDatas();

        ViewCollectionBlockInfo();
    };
    const ViewCollectionBlockInfo = () => {
        const tempBlock = PLCAddressEditStore.blockMap.map((block) => ({
            ...block,

            ['id']: block.BlockInfoId * 10,
            ['BlockInfoId']: block.BlockInfoId,
            ['name']: block.BlockName,
            ['StartAddress']: block.BlockStartAddress,
            ['EndAddress']: block.BlockEndAddress,
            //Type === 0 이면 미쯔비시, 1이면 지멘스
            ['BlockSize']: PLCAddressEditStore.currentPlcType === 0 ? Number(block.BlockEndAddress.substr(1)) - Number(block.BlockStartAddress.substr(1)) + 1
                : PLCAddressEditStore.currentPlcType === 1 ? Number(block.BlockEndAddress.split('.')[1].replace(/[^0-9]/g, "")) - Number(block.BlockStartAddress.split('.')[1].replace(/[^0-9]/g, "")) + 1
                    // parseInt(block.BlockEndAddress.slice(0, block.StartAddress.search('/[^0-9]/g'))) - (parseInt(block.BlockEndAddress.slice(block.StartAddress.search('/[^0-9]/g')))) +1
                    : 'NaN',
            ['AddressType']: block.AddressType,
            //['Unit'] : block.Unit,
            ['isBlock']: true
        }));
        let collectionInfoIdList = [];
        const tempCollection = PLCAddressEditStore.collectionMap.map((collection) => (collectionInfoIdList.push(collection.CollectionInfoId), {
            ...collection,

            ['id']: collection.CollectionInfoId,
            ['CollectionInfoId']: collection.CollectionInfoId,
            ['name']: collection.CollectionName,
            ['BlockList']: tempBlock.filter(block => block.CollectionInfoId === collection.CollectionInfoId),
            ['isBlock']: false
        }));
        setCollectionInfoList({
            collectionData: tempCollection.slice(),
            expanded: collectionInfoIdList,
            inEdit: [],
        })
    };

    const saveClick = () => {
        setOpenPermissionCheckForm(true);
        setEnableCancle(false);
        setEnableSave(false);
    };
    const cancleClick = () => {
        ViewCollectionBlockInfo();
        setEnableCancle(false);
        setEnableSave(false);
    };
    const permissionCheckFormClose = () => {
        // cancleClick();
        setEnableCancle(true);
        setEnableSave(true);
        setOpenPermissionCheckForm(false);
    };
    const permissionCheck = async (event) => {
        setLoading(true);
        const loginUser = {
            userId: mainViewStore.loginUser.UserId,
            userPassword: event.password
        }
        const result = await mainViewStore.loginAPI(loginUser);
        if (result) {
            saveCollectionBlockInfo();
        }
        else {
            PLCAddressEditStore.alertMessage("Password Error", "error")
        }
        setLoading(false);
    };
    const saveCollectionBlockInfo = async () => {
        setOpenPermissionCheckForm(false);
        let msg = '';
        const result = await PLCAddressEditStore.setDBCollectionBlock(collectionInfoList.collectionData);
        if (result === false) {
            msg += "DB Insert Failure";
            PLCAddressEditStore.alertMessage(msg, "error")
            cancleClick();
        }
        else {
            msg += "DB Insert Success";
            PLCAddressEditStore.alertMessage(msg, "success")
            ViewCollectionBlockInfo();
            navigate('/system/setting', { state: { TabKey: 'PlcMemoryMapEdit' } });
        }

    };

    const addChild = (dataItem) => {
        isBlockBtnCheck = true;
        const newRecord = createNewItem(isBlockBtnCheck);
        setCollectionInfoList({
            ...collectionInfoList,
            inEdit: [...collectionInfoList.inEdit, newRecord],
            expanded: [...collectionInfoList.expanded, dataItem.id],
            collectionData: modifySubItems(
                collectionInfoList.collectionData,
                subItemsField,
                (item) => item.id === dataItem.id,
                (subItems) => [newRecord, ...subItems]
            ),
        });
    };
    const enterEdit = (dataItem) => {
        if (dataItem.SendPeriod === undefined) {
            isBlockBtnCheck = true;
        }
        else {
            isBlockBtnCheck = false;
        }
        setCollectionInfoList({
            ...collectionInfoList,
            inEdit: [...collectionInfoList.inEdit, extendDataItem(dataItem, subItemsField)],
        });
    };
    function validationCheckBlock(blockStartData, blockEndData, inputData) {
        let startArray = [];
        let endArray = [];
        //Object -> Array로 변환
        blockStartData.forEach(element => {
            startArray.push(Object.values(element));
        });
        startArray = startArray.reduce(function (acc, cur) {
            return acc.concat(cur);
        });
        blockEndData.forEach(element => {
            endArray.push(Object.values(element));
        });
        endArray = endArray.reduce(function (acc, cur) {
            return acc.concat(cur);
        });

        // 중복 체크
        if (startArray.concat(endArray).length !== (new Set(startArray.concat(endArray))).size) {
            return false;
        }
        //범위체크를 위한 그룹화
        let startGroup = [];
        let endGroup = [];
        let charArray = [];
        startArray.forEach(element => {
            if (!charArray.includes(element[0])) {
                charArray.push(element[0]);
                startGroup.push(startArray.filter((startItem) => startItem[0] === element[0]));
            }
        });
        charArray = [];
        endArray.forEach(element => {
            if (!charArray.includes(element[0])) {
                charArray.push(element[0]);
                endGroup.push(endArray.filter((endItem) => endItem[0] === element[0]));
            }
        });
        let returnValue = true;
        startGroup.some((startArray) => {
            startArray.some((startItem) => {
                //전체 Block 데이터 중, InputData와 다른 값만 비교 
                if (startItem !== inputData.StartAddress) {
                    //같은 Block만 비교
                    if (startItem[0] === inputData.StartAddress[0]) {
                        //StartAddress 범위 비교              
                        if (Number(startItem.slice(1)) < Number(inputData.StartAddress.slice(1))) {
                            if (Number(inputData.StartAddress.slice(1)) < Number(endGroup[startGroup.indexOf(startArray)][startArray.indexOf(startItem)].slice(1))) {
                                returnValue = false;
                                return true;
                            }
                        }
                        else if (Number(startItem.slice(1)) < Number(inputData.EndAddress.slice(1))) {
                            returnValue = false;
                            return true;
                        }
                    }

                }
            });
            if (returnValue === false)
                return true;
        });
        if (!returnValue)
            return returnValue;
        return true;
    }

    const save = (dataItem) => {
        if (isBlockBtnCheck) {

            if (dataItem.StartAddress == "" || dataItem.StartAddress == null) {
                PLCAddressEditStore.alertMessage("StartAddress 를 입력해주세요.", "error");
                return;
            }
            if (dataItem.EndAddress == "" || dataItem.EndAddress == null) {
                PLCAddressEditStore.alertMessage("EndAddress 를 입력해주세요.", "error");
                return;
            }
            if (dataItem.StartAddress.replace(/[0-9]/g, "") !== dataItem.EndAddress.replace(/[0-9]/g, "")) {
                PLCAddressEditStore.alertMessage("StartAddress와 EndAddress Block 정보가 일치하지 않습니다.", "error");
                return;
            }
            if (Number(dataItem.StartAddress.slice(1)) > Number(dataItem.EndAddress.slice(1))) {
                PLCAddressEditStore.alertMessage("StartAddress가 EndAddress 보다 주소가 큽니다..", "error");
                return;
            }
            else {
                let blockStartData = [];
                let blockEndData = [];
                //Start / End Address 추출
                blockStartData = collectionInfoList.collectionData.map((item) => ({
                    ...item.BlockList.map((b) => b.StartAddress),
                }));
                blockEndData = collectionInfoList.collectionData.map((item) => ({
                    ...item.BlockList.map((b) => b.EndAddress),

                }));
                /*
                if (!validationCheckBlock(blockStartData, blockEndData, dataItem)) {
                    PLCAddressEditStore.alertMessage("범위가 중복된 주소가 존재합니다", "error");
                    return;
                }
                */

            }
            let plcType = PLCAddressEditStore.currentPlcType;
            if (plcType === 0)
                dataItem.BlockSize = dataItem.EndAddress.replace(/[^0-9]/g, "") - dataItem.StartAddress.replace(/[^0-9]/g, "") + 1;
            else if (plcType === 1)
                dataItem.BlockSize = Number(dataItem.EndAddress.split('.')[1].replace(/[^0-9]/g, "")) - Number(dataItem.StartAddress.split('.')[1].replace(/[^0-9]/g, "")) + 1

        }
        else {
            if (dataItem.SendPeriod == "" || dataItem.SendPeriod == null) {
                PLCAddressEditStore.alertMessage("SendPeriod 를 입력해주세요.", "error");
                return;
            }
            let setData = dataItem.SendPeriod.toString();
            if (setData.startsWith('-') == true) {
                PLCAddressEditStore.alertMessage("SendPeriod 는 마이너스를 입력할 수 없습니다.", "error");
                return;
            }
        }

        const { isNew, inEdit, ...itemToSave } = dataItem;
        setCollectionInfoList({
            ...collectionInfoList,
            collectionData: mapTree(collectionInfoList.collectionData, subItemsField, (item) =>
                item.id === itemToSave.id ? itemToSave : item
            ),
            inEdit: collectionInfoList.inEdit.filter((i) => i.id !== itemToSave.id),
        });
    };
    const cancel = (editedItem) => {
        const { inEdit, collectionData: data } = collectionInfoList;
        if (editedItem.isNew) {
            return remove(editedItem);
        }
        setCollectionInfoList({
            ...collectionInfoList,
            collectionData: mapTree(data, subItemsField, (item) =>
                item.id === editedItem.id ? inEdit.find((i) => i.id === item.id) : item
            ),
            inEdit: inEdit.filter((i) => i.id !== editedItem.id),
        });
    };
    const remove = (dataItem) => {
        setCollectionInfoList({
            ...collectionInfoList,
            collectionData: removeItems(collectionInfoList.collectionData, subItemsField, (i) => i.id === dataItem.id),
            inEdit: collectionInfoList.inEdit.filter((i) => i.id !== dataItem.id),
        });
        setEnableCancle(true);
        setEnableSave(true);
    };
    const onExpandChange = (e) => {
        setCollectionInfoList({
            ...collectionInfoList,
            expanded: e.value
                ? collectionInfoList.expanded.filter((id) => id !== e.dataItem.id)
                : [...collectionInfoList.expanded, e.dataItem.id],
        });
    };
    const onItemChange = (event) => {
        const field = event.field;
        setCollectionInfoList({
            ...collectionInfoList,
            collectionData: mapTree(collectionInfoList.collectionData, subItemsField, (item) =>
                item.id === event.dataItem.id
                    ? extendDataItem(item, subItemsField, {
                        [field]: event.value,
                    })
                    : item
            ),
        });
        setEnableCancle(true);
        setEnableSave(true);
    };
    const addCollection = () => {
        isBlockBtnCheck = false;

        const newRecord = createNewItem(isBlockBtnCheck);

        setCollectionInfoList({
            ...collectionInfoList,
            collectionData: [newRecord, ...collectionInfoList.collectionData],
            inEdit: [
                ...collectionInfoList.inEdit,
                {
                    ...newRecord,
                },
            ],
        });
    };
    const createNewItem = (isBlock) => {
        const timestamp = parseInt(new Date().getTime());
        return {
            id: timestamp,
            isNew: true,
            isBlock: isBlock,
        };
    };
    const CommandCell = treeListCell(
        enterEdit,
        remove,
        save,
        cancel,
        addChild,
        editField
    );

    const collectionColumns = [
        {
            field: "name",
            title: "Name",
            width: "300px",
            editCell: TreeListTextEditor,
            expandable: true,
        },
        {
            field: "SendPeriod",
            title: "SendPeriod",
            width: "200px",
            editCell: TreeListNumericEditor,
        },
        {
            field: "StartAddress",
            title: "StartAddress",
            width: "180px",
            editable: false
        },
        {
            field: "EndAddress",
            title: "EndAddress",
            width: "180px",
            editable: false
        },
        {
            field: "BlockSize",
            title: "BlockSize",
            width: "100px",
            editable: false
        },
        {
            field: "AddressType",
            title: "AddressType",
            width: "160px",
            editable: false
        },
        // {
        //     field: "Unit",
        //     title: "Unit",
        //     width: "160px",
        //     editable: false
        // },
        {
            cell: CommandCell,
            width: "260px",
        },
    ];
    const blockColumns = [
        {
            field: "name",
            title: "Name",
            width: "280px",
            editCell: TreeListTextEditor,
            expandable: true,
        },
        {
            field: "SendPeriod",
            title: "SendPeriod",
            width: "260px",
            editable: false
        },
        {
            field: "StartAddress",
            title: "StartAddress",
            width: "160px",
            editCell: TreeListTextEditor,
            expandable: false,
        },
        {
            field: "EndAddress",
            title: "EndAddress",
            width: "160px",
            editCell: TreeListTextEditor,
            expandable: false,
        },
        {
            field: "BlockSize",
            title: "BlockSize",
            width: "160px",
            editable: false
        },
        {
            field: "AddressType",
            title: "AddressType",
            width: "160px",
            editCell: TreeListTextEditor,
        },
        // {
        //     field: "Unit",
        //     title: "Unit",
        //     width: "160px",
        //     editCell: TreeListTextEditor,
        // },
        {
            cell: CommandCell,
            width: "360px",
        },
    ];

    const plcFilterChange = async (e) => {
        if (enableCancle) {
            let result = await swal.fire({
                icon: "warning",
                title: '변경사항이 폐기됩니다.\n 진행하시겠습니까?',
                text: "",
                showCancelButton: true,
                confirmButtonText: "확인",
                cancelButtonText: "취소",
            }).then((res) => {
                if (res.isConfirmed) {
                    return true;
                }
                else {
                    return false;
                }
            });
            if (result) {
                PLCAddressEditStore.changeSelectPlcCollection(PLCAddressEditStore.plcList.indexOf(e.target.value) + 1);
                cancleClick();
                setCurPlcIndex(PLCAddressEditStore.plcList.indexOf(e.target.value) + 1);
                return;
            } else {
                return;
            }
        }
        await PLCAddressEditStore.changeSelectPlcCollection(PLCAddressEditStore.plcList.indexOf(e.target.value) + 1);
        ViewCollectionBlockInfo();
    };

    return (

        <Observer>
            {() => (
                <div>
                    {mainViewStore.loginUser.Authority === 2 ?
                        PLCAddressEditStore.plcList.length > 0 ? (
                            <TreeList
                                style={{
                                    overflow: 'scroll',
                                    height: "955px",
                                    margin: "10px",
                                    fontSize: "13px",
                                }}
                                data={mapTree(collectionData, subItemsField, (item) =>
                                    extendDataItem(item, subItemsField, {
                                        [expandField]: expanded.includes(item.id),
                                        [editField]: Boolean(inEdit.find((i) => i.id === item.id)),
                                    })
                                )}
                                editField={editField}
                                expandField={expandField}
                                subItemsField={subItemsField}
                                onItemChange={onItemChange}
                                onExpandChange={onExpandChange}
                                columns={isBlockBtnCheck ? blockColumns : collectionColumns}
                                toolbar={
                                    <TreeListToolbar>
                                        <Stack direction="horizontal" gap={2} style={{ margin: '5px' }}>
                                            <div>PLC ID</div>
                                            <DropDownList
                                                onChange={plcFilterChange}
                                                data={PLCAddressEditStore.plcList}
                                                value={PLCAddressEditStore.plcList[curPlcIndex]}
                                                defaultValue={PLCAddressEditStore.plcList[0]}
                                                style={{
                                                    width: "250px",
                                                }}
                                            />
                                            <button
                                                title="Add Collection"
                                                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                                                onClick={addCollection}
                                                style={{
                                                    borderColor: '#0d6efd',
                                                    backgroundColor: '#0d6efd',
                                                    color: 'white',

                                                }}
                                            >
                                                Add Collection
                                            </button>
                                        </Stack>


                                        <Stack style={{ width: "30px" }}>

                                        </Stack>

                                        <Stack direction="horizontal" style={{ margin: '5px' }}>
                                            <button
                                                title="Mater Save"
                                                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                                                onClick={saveClick}
                                                disabled={!enabelSave}
                                                style={{
                                                    backgroundColor: '#0d6efd',
                                                    color: 'white',

                                                }}
                                            >
                                                Save Changes
                                            </button>
                                            <button
                                                title="Mater Cancle"
                                                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                                                onClick={cancleClick}
                                                disabled={!enableCancle}
                                                style={{
                                                    backgroundColor: '#0d6efd',
                                                    color: 'white',

                                                }}
                                            >
                                                Cancle Changes
                                            </button>

                                        </Stack>
                                    </TreeListToolbar>
                                }
                            />
                        ) : (
                            <div style={{ position: 'absolute', top: '20%', left: '30%' }}>
                                <NotPlcListView PLCAddressEditStore={PLCAddressEditStore} moveToPLCAddPage={() => { props.handleTabSelect('baseInfo') }} />
                            </div>
                        ) : (
                            <div style={{ position: 'absolute', top: '25%', left: '30%' }}>
                                <NotEditPlcPermission moveToPLCAddPage={() => { props.handleTabSelect('baseInfo') }}/>
                            </div>

                        )
                    }
                    {loading && <KendoLoading />}
                    {openPermissionCheckForm && (
                        <CheckEditPermissionForm
                            cancelEdit={permissionCheckFormClose}
                            onSubmit={permissionCheck}
                        />
                    )}
                </div>

            )}
        </Observer>
    );
}

export default CollectionBlockTreeList;


