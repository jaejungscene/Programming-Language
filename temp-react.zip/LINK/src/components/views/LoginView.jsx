import { Observer } from 'mobx-react';
import Form from 'react-bootstrap/Form';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { faKey } from '@fortawesome/free-solid-svg-icons';
import Row from 'react-bootstrap/Row';
import Stack from 'react-bootstrap/Stack';
import Button from 'react-bootstrap/Button';
import useStore from '../../stores/useStore';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';


function LoginView()  {
    console.log("LOGIN VIEW");
    const { mainViewStore } = useStore();
    const navigate = useNavigate(); 
    const { t } = useTranslation();

    async function onLogin(){
        let result = await mainViewStore.onLogin();

        //navigate는 리액트 구성요소 또는 리액트 훅에서만 동작한다.
        if(result){
            navigate('/dashboard/trendMonitoring');
        }
    }
    const onKeyPress=(e) =>{
        if(e.key === 'Enter'){
            onLogin();            
        }
    }

    return (
       
        <Observer>
            {() => (
                <Stack style={{ alignItems: 'center' }}>
                    <h1 style={{ fontSize: '140px', marginTop: '5%' }}> {t('LAN_PROGRAM_TITLE')}</h1>
                    <Row style={{ marginTop: '15%' }}>
                        <span className="input-group-addon" style={{ width: '50px', float: 'left' }}>
                            <FontAwesomeIcon color='gray' size='3x' icon={faUser} />
                        </span>
                        <Form.Control className="form-login" id="login_id" value={mainViewStore.inputUserId} onKeyPress={onKeyPress} onChange={(e) => {mainViewStore.onChangeId(e.target.value)}} type="text" style={{ marginLeft:'10px', height: '46px', width: '250px', float: 'left' }} placeholder={t('LAN_USER_NAME')} />
                    </Row>
                    <Row>
                        <span className="input-group-addon" style={{ width: '50px', float: 'left' }}>
                            <FontAwesomeIcon color='gray' size='3x' icon={faKey} />
                        </span>
                        <Form.Control className="form-login" id="login_pw" value={mainViewStore.inputUserPassword} onKeyPress={onKeyPress} onChange={(e) => {mainViewStore.onChangePassword(e.target.value)}} type="password" style={{ marginLeft:'10px', height: '46px', width: '250px', float: 'left' }} placeholder={t('LAN_USER_PASSWORD')} autoComplete='off' />
                    </Row>
                    <Button id="loginBtn" variant="primary" style={{ marginTop: '2%', fontSize:'20px' }} onClick={() => { onLogin() }}> {t('LAN_LOGIN')}</Button>
                </Stack>
            )
            }
        </Observer>
    );
}

export default LoginView;                   