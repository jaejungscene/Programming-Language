import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileCircleXmark } from '@fortawesome/free-solid-svg-icons';
import Row from 'react-bootstrap/Row';
import Stack from 'react-bootstrap/Stack';

function Error404() {
    console.log("ERROR404");
    return (
        <Stack style={{ alignItems: 'center' }}>
            <FontAwesomeIcon style={{ marginTop: '5%' }} color='gray' size='10x' icon={faFileCircleXmark} />
            <h1 style={{ fontSize: '100px'}}>404</h1>
            <h4>This requested URL was not found.</h4>
            <Row style={{ marginTop: '5%' }}>
                <Link className='navbar-brand' to='/'> Return to Home</Link>
            </Row>
        </Stack>
    );
}


export default Error404;