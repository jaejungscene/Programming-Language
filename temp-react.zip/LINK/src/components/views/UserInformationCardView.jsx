import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';
import { FaUser } from "react-icons/fa";

function UserInformationCardView(props) {

    const { t } = useTranslation();

    function convertAuthorityToName(id) {

        let authority = '';
        switch (id) {
            case 1: authority = t('LAN_OPERATOR');
                break;
            case 2: authority = t('LAN_SERVICE_ENGINEER');
                break;
            case 3: authority = t('LAN_DEVELOPER');
                break;
            case 4: authority = t('LAN_ADMINISTRATOR');
                break;
            default: authority = t('LAN_OPERATOR');
                break;
        }

        return authority;
    }

    if(props.user === undefined){
        return;
    }

    return (
        <Observer>
            {() => (
                <Modal
                    {...props}
                    size="None"
                >
                    <Modal.Header style={{ paddingBottom: '0px', backgroundColor: '#343a40' }}>
                        <Modal.Title id="contained-modal-title-vcenter">
                            <div style={{ fontSize:"30px", color: 'white' }}>
                                {t('LAN_USER_INFORMATION')}
                            </div>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{ paddingTop: "0px" }}>
                        <Row xs="auto">
                            <Col>
                                <FaUser style={{ fontSize: "90px", marginTop:"20px"}}></FaUser>
                            </Col>
                            <Col style={{borderRight:"2px solid lightgray", marginTop:"10px"}}>
    
                            </Col>
                            <Col style={{ marginLeft: "25px" }}>
                                <Row>
                                    <div style={{ fontSize: "25px", fontWeight: "bold", float: "right" }}>
                                        {props.user.UserName}
                                        <div style={{ fontSize: "17px", color: 'gray', fontWeight: "lighter"}}>
                                            {convertAuthorityToName(props.user.Authority)}
                                        </div>
                                    </div>
                                </Row>
                                <Row>
                                    <div style={{ fontSize: "17px", fontWeight: "lighter" }}>
                                        {props.user.PhoneNumber}
                                    </div>
                                </Row>
                                <Row>
                                    <div style={{ fontSize: "17px", fontWeight: "lighter" }}>
                                        {props.user.Mail}
                                    </div>
                                </Row>
                            </Col>
                        </Row>
                    </Modal.Body>
                </Modal>
            )
            }
        </Observer>
    )
}

export default UserInformationCardView;