import React from 'react';
import SuperMarketTemplate from '../parts/SuperMarketTemplate';
import ShopItemList from '../parts/ShopItemList';
import BasketItemList from '../parts/BasketItemList';
import TotalPrice from '../parts/TotalPrice';
import CounterComponent from '../parts/CounterComponent';

const SuperMarket = () => {
  return (
    <div>
      <CounterComponent />
      <hr />
      <SuperMarketTemplate
        items={<ShopItemList />}
        basket={<BasketItemList />}
        total={<TotalPrice />}
      />
    </div>
  );
};

export default SuperMarket;