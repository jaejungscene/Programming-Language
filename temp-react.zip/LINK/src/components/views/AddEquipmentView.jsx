import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import EquipmentTypeDropDown from '../parts/Common/EquipmentTypeDropDown';
import PLCTypeDropDown from '../parts/Common/PLCTypeDropDown';
import useStore from '../../stores/useStore';
import { Observer } from 'mobx-react';
import swal from 'sweetalert2';
import { useTranslation } from 'react-i18next';

function AddEquipmentView(props) {

    const { addEquipmentStore } = useStore();
    const { t } = useTranslation();
    async function onSaveEquipment() {

        let equipmentNameCheckResult = addEquipmentStore.equipmentNameValidationCheck();

        if(!equipmentNameCheckResult){
            swal.fire({
                title: t('MSG_EQUIPMENT_NAME_ENTER'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });

            return;
        }

        let ipCheckResult = addEquipmentStore.ipValidationCheck();
        if(!ipCheckResult){
            swal.fire({
                title: t('MSG_EQUIPMENT_IP_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
            
            return;
        }

        let portCheckResult = addEquipmentStore.portValidationCheck();
        if(!portCheckResult){
            swal.fire({
                title: t('MSG_EQUIPMENT_PORT_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
            
            return;
        }

        let result = await addEquipmentStore.onSaveEquipment();

        if (result) {
            swal.fire({
                title: t('MSG_EQUIPMENT_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else {
            swal.fire({
                title: t('MSG_EQUIPMENT_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }

        onClose();
    }

    function onClose() {        
        props.onHide();
        addEquipmentStore.clearData();        
    }

    return (
        <Observer>
            {() => (
                <Modal
                    {...props}
                    size="None"
                >
                    <Modal.Header closeButton style={{paddingBottom:'0px'}}>
                        <Modal.Title id="contained-modal-title-vcenter">
                            <div style={{ width: '200px' }}>
                                {t('LAN_ADD_EQUIPMENT')}
                                <hr />
                            </div>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body style={{paddingTop:'0px'}}>
                        <br />
                        <Row xs="auto">
                            <Col style={{fontSize:'13px', color:'gray'}}>
                                {t('LAN_EQUIPMENT_TYPE')}
                            </Col>                            
                        </Row>
                        <Row xs="auto">
                            <Col style={{ marginTop: '5px' }}>
                                <EquipmentTypeDropDown value={addEquipmentStore.equipmentType} onChange={(e) => { addEquipmentStore.onChangeEquipmentType(e.target.value) }} />
                            </Col>
                        </Row>
                        <Row xs="auto" style={{ paddingTop: '10px' }}>
                            <Col style={{fontSize:'13px', color:'gray'}}>
                                {t('LAN_EQUIPMENT_NAME')}
                            </Col>                            
                        </Row>
                        <Row xs="auto">
                            <Col style={{ marginTop: '5px' }}>
                                <Form.Control style={{ width: '200px' }} type="text" placeholder={t('LAN_EQUIPMENT_NAME')} defaultValue={addEquipmentStore.equipmentName} onChange={(e) => addEquipmentStore.onChangeEquipmentName(e.target.value)} />
                            </Col>
                        </Row>
                        <Row xs="auto" style={{ paddingTop: '10px' }}>
                            <Col style={{fontSize:'13px', color:'gray'}}>
                                {t('LAN_EQUIPMENT_PLC_TYPE')}
                            </Col>                            
                        </Row>
                        <Row xs="auto">
                            <Col style={{ marginTop: '5px' }}>
                                <PLCTypeDropDown value={addEquipmentStore.protocolType} onChange={(e) => { addEquipmentStore.onChangeEquipmentPLCType(e.target.value) }} />
                            </Col>
                        </Row>
                        <Row xs="auto" style={{ paddingTop: '10px' }}>
                            <Col style={{fontSize:'13px', color:'gray'}}>
                                {t('LAN_EQUIPMENT_PLC_ADDRESS')}
                            </Col>                            
                        </Row>
                        <Row xs="auto">
                            <Col style={{ marginTop: '5px' }}>
                                <Form.Control style={{ width: '200px' }} type="text" placeholder="IP:Port" defaultValue={addEquipmentStore.equipmentIp} onChange={(e) => addEquipmentStore.onChangeEquipmentIp(e.target.value)} />
                            </Col>
                        </Row>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={onSaveEquipment}>{t('LAN_ADD')}</Button>
                        <Button variant="danger" onClick={onClose}>{t('LAN_CLOSE')}</Button>
                    </Modal.Footer>
                </Modal>
            )
            }
        </Observer>
    )
}

export default AddEquipmentView;