import { Link } from 'react-router-dom';

const Home = () => {
    return (
      <div>
        <h1>Root Page</h1>
        <p>Dash Board.</p>
        <hr />
        <Link to="/testMarket">Go Demo</Link>
      </div>
    );
  };
  
  export default Home;