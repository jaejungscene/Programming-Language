import React from 'react'
import PlcDatagridView from '../parts/PlcEditParts/PlcDatagridView'
import '@progress/kendo-theme-default/dist/all.css';
function PlcMemoryMapEditView(props) {
 
  return (
    <div>
      <PlcDatagridView moveToPLCAddPage = {() => {props.handleTabSelect('baseInfo')}}></PlcDatagridView>
    </div>
  )
}

export default PlcMemoryMapEditView