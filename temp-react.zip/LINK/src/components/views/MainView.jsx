import HeaderView from '../parts/HeaderView'
import Sidebar from '../parts/Sidebar'
import { Outlet } from 'react-router-dom';
import React, { useEffect, useState } from "react";
import useStore from '../../stores/useStore';
import Fetcher from '../parts/Common/Fetcher';

function MainView() {
    console.log("MAIN VIEW COMPOENT");
    
    const [equipmentChanged, setEquipmentChanged] = useState(false);

    function equipmentChangeCallback(){
        setEquipmentChanged(true);
    }

    useEffect(() => {
        //login User check
        let loginUser = sessionStorage.getItem('loginUser');
        loginUser = JSON.parse(loginUser)
        if (loginUser === null || loginUser === undefined) {
            return;
        }
        
    }, [])
    
    return (
        <div className='body'>
            <HeaderView equipmentChangeEvent={equipmentChangeCallback}>
            </HeaderView>
            <main>
                <Sidebar>
                </Sidebar>
                    <Outlet context={{'equipmentChanged':[equipmentChanged, setEquipmentChanged]}} />
                    
            </main>
        </div>
    );
}

export default MainView;