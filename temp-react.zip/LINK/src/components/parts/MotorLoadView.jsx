
function ServoMotorView(){

    return (
        <article className="article_pms">
            모터부하 입니다.
        </article>
    );

}

export default ServoMotorView;