import { Observer } from 'mobx-react';
import React, { useEffect, useState, useRef, useCallback } from 'react'
import {
    Grid,
    GridToolbar
} from "@progress/kendo-react-grid";
import PlcMemoryMapToolBarView from './PlcMemoryMapToolBarView';
import useStore from '../../../stores/useStore';
import NotPlcListView from './NotPlcListView';
import NotEditPlcPermission from '../PlcEditParts/NotEditPlcPermission';
import KendoLoading from '../../parts/Common/KendoLoading';
import { filterBy } from "@progress/kendo-data-query";
import { CellRender, RowRender } from "./DatagridItemRender";
import { PlcColumnView } from './PlcColumnView';
import PlcRealTimeChart from './PlcRealTimeChart';
import swal from 'sweetalert2';

function PlcDatagridView(props) {
    const { mainViewStore, PLCAddressEditStore } = useStore();

    const [gridData, setGridData] = useState();
    const [selectPlcId, setSelectPlcId] = useState(0);
    const [enableloading, setEnableLoading] = useState(false);
    const [enableEdit, setEnableEdit] = useState(false);
    const [filter, setFilter] = useState();
    const [clickItem, setClickItem] = useState(undefined);
    const [rowClickstate, setRowClickState] = useState(false);
    const chartValue = useRef({ Value: 0 });
    const Editability_FIELD = "inEdit";
    const [realtimeValue, setRealtimeValue] = useState();

    const [importState, setImportState] = useState(false);

    useEffect(() => {
        // setSelectPlcId(PLCAddressEditStore.currentPlcInfoId);
        setGridData(PLCAddressEditStore.plcMemoryMap);

    }, [PLCAddressEditStore.plcMemoryMap]);

    useEffect(() => {
        plcInfoListinitialize();
    }, []);

    useEffect(() => {
        plcRealTimeDataRead();
    }, [clickItem]);

    //#region test 
    // const interval = useRef();
    // useEffect(() => {

    //     if (interval.current) {
    //         clearInterval(interval.current);
    //         interval.current = null;
    //     }
    //     interval.current = setInterval(() => {

    //         let newRealtimeValue = [];
    //         let plcRealTimeDatas = [
    //             { PLCAddressId: 'D14000', Value: Math.floor(Math.random() * 100) },
    //             { PLCAddressId: 'D14001', Value: Math.floor(Math.random() * 100) },
    //             { PLCAddressId: 'D14002', Value: Math.floor(Math.random() * 100) },
    //             { PLCAddressId: 'D14003', Value: Math.floor(Math.random() * 100) },
    //             { PLCAddressId: 'D14004', Value: Math.floor(Math.random() * 100) },
    //             { PLCAddressId: 'D14005', Value: Math.floor(Math.random() * 100) },
    //             { PLCAddressId: 'D14006', Value: Math.floor(Math.random() * 100) },
    //         ];

    //         PLCAddressEditStore.plcMemoryMap.forEach(prevState => {
    //             plcRealTimeDatas.forEach(plcRealTimeData => {
    //                 if (prevState.PLCAddress === plcRealTimeData.PLCAddressId) {
    //                     prevState['Value'] = plcRealTimeData['Value'];
    //                     if (prevState['Value'] < prevState['WarningThreshold']) {
    //                         //Normal
    //                         prevState['State'] = "Normal";
    //                     }
    //                     else if (prevState['Value'] >= prevState['WarningThreshold'] && prevState['Value'] < prevState['ErrorThreshold']) {
    //                         //Warning
    //                         prevState['State'] = "Warning";
    //                     }
    //                     else {
    //                         //Error
    //                         prevState['State'] = "Error";
    //                     }
    //                     newRealtimeValue.push({ "PLCAddressId": prevState.PLCAddress, "Value": prevState['Value'], "State": prevState['State'] })
    //                 }
    //             });
    //         });

    //         if (enableEdit === false) {
    //             setRealtimeValue(newRealtimeValue);
    //         }
    //         if (clickItem != undefined && enableEdit === false) {
    //             chartValue.current = (newRealtimeValue.find(newData => newData.PLCAddressId === clickItem.PLCAddress));
    //         }
    //     }, 100);

    //     return () => clearInterval(interval.current);
    // }, [clickItem]);
    //#endregion test 
    async function plcInfoListinitialize() {
        await PLCAddressEditStore.initializeComponentDatas();

        setGridData(PLCAddressEditStore.plcMemoryMap);
    }
    async function plcRealTimeDataRead() {
        await mainViewStore.webSocket.on('plcRealTimeDataBroadcast', async (plcRealTimeDatas) => {
            let newRealtimeValue = [];
            PLCAddressEditStore.plcMemoryMap.forEach(prevState => {
                plcRealTimeDatas.forEach(plcRealTimeData => {
                    if (prevState.PLCAddress === plcRealTimeData.PLCAddressId) {
                        prevState['Value'] = plcRealTimeData['Value'];
                        let UpperErrorThreshold = prevState['UpperErrorThreshold'];
                        let UpperWarningThreshold = (prevState['UpperErrorThreshold'] * 0.8).toFixed(1);
                        let LowerErrorThreshold = prevState['LowerErrorThreshold'];
                        let LowerWarningThreshold = (prevState['LowerErrorThreshold'] * 1.2).toFixed(1);
                        if (prevState['Value'] > LowerWarningThreshold && prevState['Value'] < UpperWarningThreshold) {
                            //Normal
                            prevState['State'] = "Normal";
                        }
                        else if ((prevState['Value'] >= UpperWarningThreshold && prevState['Value'] < UpperErrorThreshold) ||
                                 (prevState['Value'] <= LowerWarningThreshold && prevState['Value'] > LowerErrorThreshold) ) {
                            //Warning
                            prevState['State'] = "Warning";
                        }
                        else {
                            //Error
                            prevState['State'] = "Error";
                        }
                        newRealtimeValue.push({ "PLCAddressId": prevState.PLCAddress, "Value": prevState['Value'], "State": prevState['State'] })
                    }
                });
            });
            if (enableEdit === false) {
                setRealtimeValue(newRealtimeValue);
            }
            if (clickItem != undefined && enableEdit === false) {
                chartValue.current = (newRealtimeValue.find(newData => newData.PLCAddressId === clickItem.PLCAddress));
            }
        });
    }
    //#region cell
    const sendToMA = useCallback(async () => {
        let msg = '';
        const sendResult = await PLCAddressEditStore.sendPlcMapToMA();
        if (sendResult) {
            msg = "PLC Map Send To M/A Success\n";
            PLCAddressEditStore.alertMessage(msg, "success")

        }
        else {
            msg = "PLC Map Send To M/A Failure\n When MA is reconnected, synchronization proceeds automatically. \n";
            PLCAddressEditStore.alertMessage(msg, "error")
        }
        setEnableLoading(false);
    });
    const setSaveGridData = useCallback(async () => {
        //Import File Data Set 
        let results = [];
        let result = [];
        let msg = '';
        results.push(await PLCAddressEditStore.setDBPLCMemoryMap(gridData));
        if (importState) {
            //기존 데이터(Collection, Block, PlcAddress) 모두 삭제
            results.push(await PLCAddressEditStore.deleteAllCollectionBlockInfoByPlcId(PLCAddressEditStore.currentPlcInfoId));
            // Impor Collection, Block, PlcAddress Update
            results.push(await PLCAddressEditStore.setDBImportCollectionBlock());

            setImportState(false);
        }
        result = results.find((result) => result.result === 0);

        if (result === undefined) {
            msg += "DB Insert Success";
            PLCAddressEditStore.alertMessage(msg, "success")
            if (saveResult)
                setSaveResult(false);
            else
                setSaveResult(true);


        }
        else {
            msg += "DB Insert Failure";
            PLCAddressEditStore.alertMessage(msg, "error")
            if (saveResult)
                setSaveResult(false);
            else
                setSaveResult(true);
        }
        dataChangePropsState();
        clickCancle();
        setEnableLoading(false);


    }, [gridData]);

    const enterEdit = useCallback(() => {
        setRowClickState(false);
        setClickItem(undefined);
        setEnableEdit(true);
        const newData = gridData.map((item) => ({
            ...item,
            [Editability_FIELD]: true,
        }));
        setGridData(newData);
    }, [gridData]);

    const exitEdit = useCallback(() => {
        setEnableEdit(false);
        if (gridData != undefined) {
            const newData = gridData.map((item) => ({
                ...item,
                [Editability_FIELD]: undefined,
            }));
            setGridData(newData);
        }

    }, [gridData]);

    const dataChangeEvent = useRef(false);
    const [saveResult, setSaveResult] = useState(false);
    const datagridItemChange = (event) => {
        if (dataChangeEvent.current)
            dataChangeEvent.current = false;
        else
            dataChangeEvent.current = true;
        let field = event.field || "";
        event.dataItem[field] = event.value;
        let newData = gridData.map((item) => {
            if (item.PLCAddress === event.dataItem.PLCAddress) {
                item[field] = event.value;
            }
            return item;
        });
        setGridData(newData);

    };
    const dataChangePropsState = useCallback(() => {
        if (dataChangeEvent.current)
            dataChangeEvent.current = false;
    }, [dataChangeEvent.current]);

    const customCellRender = (td, props) => (
        <CellRender
            originalProps={props}
            td={td}
            enterEdit={enterEdit}
            temp={Editability_FIELD}
            editFrwield={Editability_FIELD}
        />
    );

    const customRowRender = (tr, props) => (
        <RowRender
            originalProps={props}
            tr={tr}
            exitEdit={exitEdit}
            rowclick={rowclick}
        />
    );


    const changePlcList = async e => {
        const selectItem = e.target.value;
        const checkState = gridData.find((item) => {
            if (item[Editability_FIELD] === true)
                return true;
        });
        if (checkState) {
            let result = await swal.fire({
                icon: "warning",
                title: '변경사항이 폐기됩니다.\n 진행하시겠습니까?',
                text: "",
                showCancelButton: true,
                confirmButtonText: "확인",
                cancelButtonText: "취소",
            }).then((res) => {
                if (res.isConfirmed) {
                    return true;
                }
                else {
                    return false;
                }
            });
            if (result) {
                clickCancle();
            } else {
                return;
            }
        }
        setRowClickState(false);
        setClickItem(undefined);
        setSelectPlcId(PLCAddressEditStore.plcList.indexOf(selectItem) + 1);

        await PLCAddressEditStore.changeSelectPlc(PLCAddressEditStore.plcList.indexOf(selectItem) + 1);

        if (PLCAddressEditStore.plcMemoryMap.length > 0)
            setGridData(PLCAddressEditStore.plcMemoryMap);
        else
            setGridData([]);
    };


    const changeTypeFilter = useCallback((filterGridData) => {
        setGridData(filterGridData);
    }, []);

    const importGridData = useCallback((importData) => {
        setGridData(importData);
        setRowClickState(false);
        setClickItem(undefined);
        setImportState(true);
    }, []);

    const clickCancle = useCallback(() => {
        PLCAddressEditStore.plcMemoryMap = PLCAddressEditStore.plcMemoryMap.map((item) => ({
            ...item,
            [Editability_FIELD]: undefined,
        }));
        setGridData(PLCAddressEditStore.plcMemoryMap);
        setEnableEdit(false);
        if (importState)
            setImportState(false);

    }, []);

    const filterChange = (event) => {
        setGridData(filterBy(PLCAddressEditStore.plcMemoryMap, event.filter));
        setFilter(event.filter);
    };
    const childLoading = useCallback((bool) => {
        setEnableLoading(bool);
    }, []);
    const onChangeDataType = (changeItem) => {
        //Row 추가 이벤트 추후 개발 예정 - kmw
        // const index = PLCAddressEditStore.plcMemoryMap.indexOf(PLCAddressEditStore.plcMemoryMap.find((item) => item.PLCAddress === changeItem.PLCAddress));
        // let newData = [];
        // if (changeItem.DataType === "BIT") {

        //     for (let i = 7; i > 0; i--) {
        //         const plcAddress =Number(changeItem.PLCAddress.slice(1)) + (0.1*i);
        //         newData.push({
        //             ...changeItem,
        //             ["PLCAddressInfoId"]: parseInt(new Date().getTime()),
        //             ["PLCAddress"]:   changeItem.PLCAddress.slice(0,1) + plcAddress,
        //         });
        //     }
        // } else if (changeItem.DataType === "Byte") {

        // } else if (changeItem.DataType === "WORD") {

        // } else if (changeItem.DataType === "DWORD") {

        // }

        // if(gridData!=undefined){
        //     newData.forEach(element => {
        //         gridData.splice(index+1, 0, element)
        //     });
        //     // gridData.splice(index+1, 0, newData);
        //     // setGridData( gridData);
        // }
        // else{
        //     // newData.forEach(element => {
        //     //     PLCAddressEditStore.plcMemoryMap.splice(index+1, 0, element)
        //     // });
        //     // setGridData( PLCAddressEditStore.plcMemoryMap);
        // }
    };
    const toolbarProps = {
        plcList: PLCAddressEditStore.plcList,
        selectPlcId: selectPlcId,
        enableEdit: enableEdit,
        dataChangeEvent: dataChangeEvent.current,
        saveResult: saveResult,
        dataChangePropsState: dataChangePropsState,
        clickCancle: clickCancle,
        enableLoading: childLoading,
        changeTypeFilter: changeTypeFilter,
        changePlcList: changePlcList,
        importGridData: importGridData,
        enterEdit: enterEdit,
        exitEdit: exitEdit,
        setSaveGridData: setSaveGridData,
        sendToMA: sendToMA,
    };
    const columnProps = {
        onChangeDataType: onChangeDataType,
    };

    const column = PlcColumnView(columnProps);
    //#end Toolbar 

    //#region chart
    const chartProps = {
        selectItem: clickItem,
        chartValue: chartValue.current,
        loadingState: enableloading,
        enableLoading: childLoading,
    };
    const rowclick = (rowClickItem) => {
        if (enableEdit === false) {
            if (clickItem === undefined || (clickItem.PLCAddress != rowClickItem.PLCAddress)) {
                setEnableLoading(true);
                setRowClickState(true);
                setClickItem(rowClickItem);
            }
            else {
                setRowClickState(false);
                setClickItem(undefined);
            }
        }
    };

    //#endregion chart


    return (
        <Observer>
            {() => (
                <div>
                    {mainViewStore.loginUser.Authority === 2 ?
                        PLCAddressEditStore.plcList.length > 0 ? (
                            <div>
                                <Grid
                                    style={{
                                        height: "930px",
                                        fontSize: "13px",
                                        margin: "10px",
                                        width: '99%',
                                        borderWidth: 2,
                                        borderRadius: 5,
                                        borderStyle: 'solid',
                                    }}
                                    data={gridData}
                                    dataItemKey={PLCAddressEditStore.plcMemoryMpaHeader[0]}
                                    rowHeight={50}
                                    onItemChange={datagridItemChange}
                                    cellRender={customCellRender}
                                    rowRender={customRowRender}
                                    editField={Editability_FIELD}
                                    filterable={true}
                                    filter={filter}
                                    resizable={true}
                                    onFilterChange={filterChange}
                                >
                                    <GridToolbar>
                                        <PlcMemoryMapToolBarView {...toolbarProps}></PlcMemoryMapToolBarView>
                                    </GridToolbar>
                                    {column}
                                </Grid>

                                {rowClickstate ? (
                                    <PlcRealTimeChart {...chartProps}></PlcRealTimeChart>
                                ) : (
                                    <div></div>
                                )}
                            </div>

                        ) : (
                            <div style={{ position: 'absolute', top: '20%', left: '30%' }}>
                                <NotPlcListView PLCAddressEditStore={PLCAddressEditStore} moveToPLCAddPage={() => { props.moveToPLCAddPage() }} />
                            </div>

                        )
                        : <div style={{ position: 'absolute', top: '25%', left: '30%' }}>
                            <NotEditPlcPermission moveToPLCAddPage={() => { props.moveToPLCAddPage() }} />
                        </div>
                    }
                    {enableloading && <KendoLoading />}
                </div>
            )}
        </Observer>
    )
}

export default PlcDatagridView

