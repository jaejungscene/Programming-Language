import * as React from "react";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import useStore from '../../../stores/useStore';

export const FormulaType_DropDown = (props) => {
    const { PLCAddressEditStore } = useStore();    
    const { dataItem } = props.td;    
    const field = props.td.field || "";
    const dataValue = dataItem[field] === null ? "" : dataItem[field];

    const dropListChange = (e) => {
        if (props.td.onChange) {
            props.td.onChange({
                dataIndex: 0,
                dataItem: props.td.dataItem,
                field: props.td.field,
                syntheticEvent: e.syntheticEvent,
                value: e.target.value.value,
            });

        }
    };
    const formulaType_Click = (event) => {
        // if (event.detail == 2) {
        //     props.enterEdit(dataItem, props.td.field);
        // }
    };
    return (
        <td onClick={formulaType_Click}
        style={{textAlign:'center'}}>
            {dataItem.inEdit ? (
                <DropDownList
                    style={{
                        width: "100px",
                    }}
                    onChange={dropListChange}
                    value={PLCAddressEditStore.formulaType_Data.find((c) => c.value === dataValue)}
                    data={PLCAddressEditStore.formulaType_Data}
                    textField="text"
                />
            ) : (
                dataValue.toString()
            )}
        </td>
    );
};
export const BoolType_DropDown = (props) => {
    const { PLCAddressEditStore } = useStore();    
    const { dataItem } = props.td;    
    const field = props.td.field || "";
    const dataValue = dataItem[field] === null ? "" : dataItem[field];

    const dropListChange = (e) => {
        if (props.td.onChange) {
            props.td.onChange({
                dataIndex: 0,
                dataItem: props.td.dataItem,
                field: props.td.field,
                syntheticEvent: e.syntheticEvent,
                value: e.target.value.value,
            });

        }
    };

    return (
        <td 
        style={{textAlign:'center'}}>
            {dataItem.inEdit ? (
                <DropDownList
                    style={{
                        width: "100px",
                    }}
                    onChange={dropListChange}
                    value={PLCAddressEditStore.boolType_Data.find((c) => c.value === dataValue)}
                    data={PLCAddressEditStore.boolType_Data}
                    textField="text"
                />
            ) : (
                dataValue.toString()
            )}
        </td>
    );
};
export const DataType_DropDown = (props) => {
    const { PLCAddressEditStore } = useStore();    
    const { dataItem } = props.td;    
    const field = props.td.field || "";
    const dataValue = dataItem[field] === null ? "" : dataItem[field];
    const dropListChange = (e) => {
        if (props.td.onChange) {
            props.td.onChange({
                dataIndex: 0,
                dataItem: props.td.dataItem,
                field: props.td.field,
                syntheticEvent: e.syntheticEvent,
                value: e.target.value.value,
            });
            props.onChangeDataType(dataItem);
        }
    };


    const dataType_Click = (event) => {
        // if (event.detail == 2) {
        //     props.enterEdit(dataItem, props.td.field);
        // }
    };
    return (
        <td onClick={dataType_Click}
        style={{textAlign:'center'}}>
            {dataItem.inEdit ? (
                <DropDownList
                    style={{
                        width: "100px",
                    }}
                    onChange={dropListChange}
                    value={PLCAddressEditStore.dataType_Data.find((c) => c.value === dataValue)}
                    data={PLCAddressEditStore.dataType_Data}
                    textField="text"
                />
            ) : (
                dataValue.toString()
            )}
        </td>
    );
};

export const SelectPLCAddress_DropDown = (props) => {
    const { PLCAddressEditStore } = useStore();
    const selectPLCAddress_dropdownlist = PLCAddressEditStore.setSelectPLCAddress_dropDownList();

    const { dataItem } = props.td;
    const field = props.td.field || "";
    // const dataValue = dataItem[field] === null ? "" : dataItem[field];
    const dataValue = PLCAddressEditStore.plcMemoryMap[field]=== null ? "" : dataItem[field];
    const dropListChange = (e) => {
        if (props.td.onChange) {
            props.td.onChange({
                dataIndex: 0,
                dataItem: props.td.dataItem,
                field: props.td.field,
                syntheticEvent: e.syntheticEvent,
                value: e.target.value,
            });
        }
    };


    const selectPLCAddress_Click = (event) => {
        // if (event.detail == 2) {
        //     props.enterEdit(dataItem, props.td.field);
        // }
    };
    return (
        <td onClick={selectPLCAddress_Click}
        style={{textAlign:'center'}}>
            {dataItem.inEdit ? (
                <DropDownList
                    style={{
                        width: "100px",                        
                    }}
                    onChange={dropListChange}
                    value={selectPLCAddress_dropdownlist.find((c) => c === dataValue)}
                    data={selectPLCAddress_dropdownlist}
                    // textField="text"

                />
            ) : (
                // console.log(selectPLCAddress_dropdownlist)
                dataValue ? dataValue.toString() : "None"
                // console.log(PLCAddressEditStore.plcMemoryMap)
                // dataValue.toString()
            )}
        </td>
    );
};