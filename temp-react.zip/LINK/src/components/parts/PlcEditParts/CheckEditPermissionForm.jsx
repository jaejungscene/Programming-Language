import * as React from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement } from "@progress/kendo-react-form";
import { Input } from "@progress/kendo-react-inputs";

function CheckEditPermissionForm(props) {

    return (
        <Dialog title={"Save Permission Check"} onClose={props.cancelEdit}>
            <Form
                onSubmit={props.onSubmit}
                // initialValues={props.item}
                render={(formRenderProps) => (
                    <FormElement
                        style={{
                            maxWidth: 650,
                        }}
                    >
                        <fieldset className={"k-form-fieldset"}>
                            <div className="mb-3">
                                <Field                                    
                                    autoFocus
                                    type="password"
                                    name={"password"}
                                    component={Input}
                                    label={"Login Password"}
                                />
                            </div>

                        </fieldset>
                        <div className="k-form-buttons">
                            <button
                                type={"submit"}
                                disabled={!formRenderProps.allowSubmit}
                                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                                style={{
                                    borderColor: '#0d6efd',
                                    backgroundColor: '#0d6efd',
                                    color: 'white',
                                }}
                            >
                                Permission Check
                            </button>
                            <button
                                type={"submit"}
                                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                                onClick={props.cancelEdit}
                                style={{
                                    backgroundColor: '#0d6efd',
                                    color: 'white',
                                }}
                            >
                                Cancel
                            </button>

                        </div>
                    </FormElement>
                )}
            />
        </Dialog>
    );
};

export default CheckEditPermissionForm
