import React, { useEffect, useState, useRef } from 'react'
import Card from 'react-bootstrap/Card';
import LineChart from '../../parts/Common/Chart/LineChart';


function PlcRealTimeChart(props) {
    const [chartOptions, setChartOptions] = useState({});
    const prevSelectItem = useRef(undefined);
    const [xData, setxData] = useState([]);
    const [yData, setyData] = useState([]);

    useEffect(() => {        
        if (props.selectItem != undefined) {
            if(props.selectItem != prevSelectItem.current){
                prevSelectItem.current = props.selectItem;
                setxData([]);
                setyData([]);
                props.enableLoading(false);
            }
                
            if (yData.length > 100) {
                for (let i = 0 ; i < 2 ; i++){
                    yData.shift();
                    xData.shift();
                }
                setyData(yData.shift());
                setxData(xData.shift());
            }
            if (props.chartValue != undefined) {
                setyData([...yData, props.chartValue.Value]);
                setxData([...xData, (new Date().toLocaleTimeString().replace(/^\D*/, ""))]);

                setChartOptions(getRealTimeOption(props.selectItem, xData, yData));
            }
            else {
                setChartOptions({
                    title: {
                        show: true,
                        textStyle: {
                            color: '#0d6efd',
                            fontSize: '30px'
                        },
                        text: `[${props.selectItem.PLCAddress}_${props.selectItem.ParameterName}] No Data`,
                        left: 'center',
                        top: 'center'
                    },
                });
            }
        }
        return () => {
            prevSelectItem.current = undefined;      
            setChartOptions(undefined);      
        }

    }, [props.chartValue, props.selectItem]);

    const getRealTimeOption = (plcInfo, xSeriesData, ySeriesData) => {

        let option = {
            title: {
                text: `Address: "${plcInfo.PLCAddress}" Parameter: "${plcInfo.ParameterName}"`
            },
            tooltip: {
                trigger: "axis",
                axisPointer: {
                    type: "cross",
                    label: {
                        backgroundColor: "#283b56"
                    }
                }
            },
            legend: {
                data: [`"${plcInfo.PLCAddress}"_"${plcInfo.ParameterName}"`]
            },
            toolbox: {
                show: true,
                feature: {
                    dataView: { readOnly: false },
                    restore: {},
                    saveAsImage: {}
                }
            },
           
            xAxis: [
                {
                    type: "category",
                    boundaryGap: true,
                    markPoint: {
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff"
                                }
                            }
                        },
                    },
                    data: xSeriesData,
                }
            ],
            yAxis: [
                {
                    type: "value",
                    scale: true,
                }
            ],
            series: [
                {
                    name: `${plcInfo.ParameterName}`,
                    type: "line",
                    data: ySeriesData,
                }

            ]
        };
        return option;
    };
    return (
        <div>
            <Card style={{ height: '20rem' }}>
                <Card.Body>
                    <LineChart options={chartOptions} width='1600px' height='300px'></LineChart>
                </Card.Body>
            </Card>
        </div>
    )
}

export default PlcRealTimeChart
