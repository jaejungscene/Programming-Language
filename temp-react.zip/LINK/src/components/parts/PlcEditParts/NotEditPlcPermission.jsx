import React from 'react'

export default function NotEditPlcPermission(props) {
    const moveToPLCAddPage = () => {
        props.moveToPLCAddPage();
    }
    return (
        <div>
            <h1 className='ComponentAlignCenter' style={{ display: 'flex', justifyContent: 'center', textAlign: 'center' }}>
                해당 페이지 접근 권한이 없습니다.

            </h1>            
            <br></br>
            <p className='ComponentAlignCenter'>
                <button style={{ backgroundColor: '#0d6efd', height: '300px', width: '500px', fontSize: '30px' }} onClick={() => { moveToPLCAddPage() }}>
                    돌아가기
                </button>
            </p>
        </div>
    )
}
