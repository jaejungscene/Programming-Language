import { Observer } from 'mobx-react';
import React, { useState, useEffect, useRef, memo } from 'react'
import Stack from 'react-bootstrap/Stack'
import { DropDownList } from '@progress/kendo-react-dropdowns';
import useStore from '../../../stores/useStore';
import { Button } from "@progress/kendo-react-buttons";
import { CSVLink } from "react-csv";
import Papa from "papaparse";
import CheckEditPermissionForm from './CheckEditPermissionForm';
import { useTranslation } from 'react-i18next';
import swal from 'sweetalert2';

const PlcMemoryMapToolBarView = (props) => {    
    const { mainViewStore, PLCAddressEditStore } = useStore();
    const [enableEdit, setEnableEdit] = useState(true);
    const [enableSave, setEnableSave] = useState(false);
    const [enableCancel, setEnableCancel] = useState(false);
    const [enableExport, setEnableExport] = useState(true);
    const [enableImport, setEnableImport] = useState(true);
    const [enablePermissionCheck, setEnablePermissionCheck] = useState(false);
    const [curPlcIndex, setCurPlcIndex ] = useState(0);
    const { t } = useTranslation();

    useEffect(()=>{        
        setCurPlcIndex(PLCAddressEditStore.currentPlcInfoId -1);
    }, [PLCAddressEditStore.currentPlcInfoId, props.selectPlcId])

    useEffect(() => {
        if (enableEdit) {
            setEnableSave(false);
            setEnableCancel(false);
            setEnableEdit(true);
        }
        else {
            setEnableSave(true);
            setEnableCancel(true);
            setEnableEdit(false);
        }
        
        if(props.dataChangeEvent)
            props.dataChangePropsState();
    }, [props.dataChangeEvent]);
    useEffect(() => {
        if(!props.enableEdit){
            btnStateInit();
        }
       
    },[props.enableEdit]);
    useEffect(()=>{    
        btnStateInit();
    },[props.saveResult]);
    const btnStateInit = () => {
        setEnableEdit(true);
        setEnableCancel(false);
        setEnableSave(false);
        setEnableExport(true);
        setEnableImport(true);
    };
    const changeTypeFilter = (e) => {
        let filterGridData = [];
        if (e.target.value.includes("ALL")) {
            props.changeTypeFilter(PLCAddressEditStore.plcMemoryMap);
        }
        else if (e.target.value.includes("Not")) {
            PLCAddressEditStore.plcMemoryMap.forEach((o) => {
                if (o.ParameterName === "") {
                    filterGridData.push(o);
                }
            });
            props.changeTypeFilter(filterGridData);
        }
        else {
            PLCAddressEditStore.plcMemoryMap.forEach((o) => {
                if (o.ParameterName !== "") {
                    filterGridData.push(o);
                }
            });
            props.changeTypeFilter(filterGridData);
        }
    };
    const sendToMAClick = async () => {

        let result = await swal.fire({
            icon: "warning",
            title: 'MachineAgent에 \n Address Map을 전송하시겠습니까?',
            text: "",
            showCancelButton: true,
            confirmButtonText: "확인",
            cancelButtonText: "취소",
        }).then((res) => {
            if (res.isConfirmed) {
                props.enableLoading(true);
                setEnablePermissionCheck(false);
                props.sendToMA();
                return ;
            }
            else {
                return false;
            }
        });
    };
    const editClick = () => {
        setEnableEdit(false);
        setEnableExport(false);
        setEnableImport(false);
        setEnableCancel(true);
        props.enterEdit();
    };
    const saveClick = () => {
        setEnablePermissionCheck(true);
    };
    const cancleClick = () => {
        btnStateInit();
        props.clickCancle();
    }
    const _export = React.useRef();
    const excelExport = async () => {
        await PLCAddressEditStore.getDBPLCAddressList();
        _export.current.link.click();
    };
    const _importFile = React.useRef(null);
    const excelImport = () => {
        document.getElementById("inputfile").click();
    };
    const inputfileChange = () => {
        let importFileCheck = false;
        if (_importFile) {
            props.enableLoading(true);
            
            Papa.parse(_importFile.current.files[0], {
                header: true,
                skipEmptyLines: true,
                before: function () {
                    props.enableLoading(true);
                },
                complete: function (results) {
                    const rowsArray = [];
                    const valuesArray = [];

                    // Iterating data to get column name and their values
                    results.data.map((d) => {
                        rowsArray.push(Object.keys(d));
                        valuesArray.push(Object.values(d));
                    });
                    
                    if (rowsArray[0].length == PLCAddressEditStore.plcMemoryMpaHeader.length) {
                        
                        importFileCheck = PLCAddressEditStore.validationCheckImportCSV(results.data);
                        props.importGridData(results.data);
                        setEnableSave(true);
                        setEnableCancel(true);
                        setEnableExport(false);

                    }

                    props.enableLoading(false);
                    if (importFileCheck) {
                        PLCAddressEditStore.alertMessage("CSV File Import Success", "success")
                    }
                    else {
                        PLCAddressEditStore.alertMessage("CSV File Error", "error")
                    }
                    //ref initial
                    _importFile.current.value = '';
                },
            });

        }

    }
    const permissionCheckFormClose = () => {
        console.log('close');
        setEnablePermissionCheck(false);
    };
    const permissionCheck = async (event) => {
        props.enableLoading(true);
        const loginUser = {
            userId: mainViewStore.loginUser.UserId,
            userPassword: event.password
        }
        const result = await mainViewStore.loginAPI(loginUser);
        if (result) {
            savePLCAddressMap();
        }
        else {
            PLCAddressEditStore.alertMessage("Password Error", "error")
        }
        props.enableLoading(false);
    };
    const savePLCAddressMap = async () => {
        // PLCAddressEditStore.alertMessage("PLC Address Map Save Success", "success")
        props.enableLoading(true);
        setEnablePermissionCheck(false);        
        props.setSaveGridData();        

    };
    return (
        <Observer>
            {() => (
                <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between'}}>
                    <Stack direction="horizontal" gap={2}>
                        <div style={{ minWidth:"80px"}}>{t('LAN_EQUIPMENT_PLC_NAME')}</div>
                        <DropDownList
                            onChange={props.changePlcList}
                            data={PLCAddressEditStore.plcList}
                            defaultValue={PLCAddressEditStore.plcList[0]}
                            value= {PLCAddressEditStore.plcList[curPlcIndex]}
                            style={{
                                width: "300px"
                            }}
                        />
                        <div style={{minWidth:"100px", "margin":"0 10px"}}>{t('MSG_MAPPING_STATUS')}</div>
                        <DropDownList
                            onChange={changeTypeFilter}
                            data={PLCAddressEditStore.dropDown_TypeList}
                            defaultValue={PLCAddressEditStore.dropDown_TypeList[0]}
                            style={{
                                width: "200px",
                            }}
                        />
                    </Stack>
                    <Stack direction="horizontal">
                        <button
                            title="Save Changes"
                            className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                            onClick={sendToMAClick}                            
                            style={{
                                backgroundColor: '#0d6efd',
                                color: 'white',
                            }}
                        >
                            {t('MSG_SEND_TO_MA')}
                        </button>
                        <button
                            title="Edit Changes"
                            className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                            onClick={editClick}
                            disabled={!enableEdit}
                            style={{
                                backgroundColor: '#0d6efd',
                                color: 'white',
                            }}
                        >
                            {t('MSG_EDIT_CHANGES')}
                        </button>
                        <button
                            title="Save Changes"
                            className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                            onClick={saveClick}
                            disabled={!enableSave}
                            style={{
                                backgroundColor: '#0d6efd',
                                color: 'white',
                            }}
                        >
                            {t('MSG_SAVE_CHANGES')}
                        </button>
                        <button
                            title="Cancel Changes"
                            className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                            onClick={cancleClick}
                            disabled={!enableCancel}
                            style={{
                                backgroundColor: '#0d6efd',
                                color: 'white',
                            }}
                        >
                            {t('MSG_CANCEL_CHANGES')}
                        </button>
                        <input id="inputfile" onChange={inputfileChange}
                            ref={_importFile} className='d-none' type="file" accept=".csv" />
                        <Button
                            className="buttons-container-button"
                            icon="excel"
                            onClick={excelImport}
                            disabled={!enableImport}
                            style={{
                                backgroundColor: '#0d6efd',
                                color: 'white',
                            }}
                        >
                            {t('MSG_IMPORT_TO_EXCEL')}
                        </Button>

                        <Button
                            className="buttons-container-button"
                            icon="excel"
                            onClick={excelExport}
                            disabled={!enableExport}
                            style={{
                                backgroundColor: '#0d6efd',
                                color: 'white',
                            }}
                        >
                            {t('MSG_EXPORT_TO_EXCEL')}
                        </Button>
                        <CSVLink data={PLCAddressEditStore.plcMemoryMap} headers={PLCAddressEditStore.plcMemoryMpaHeader}
                            ref={_export} filename={"PLCAddressEdit"} >
                        </CSVLink>
                    </Stack>
                    {enablePermissionCheck &&
                        <CheckEditPermissionForm
                            cancelEdit={permissionCheckFormClose}
                            onSubmit={permissionCheck} 
                           />}
                </div>
            )}
        </Observer>

    )
};

export default memo(PlcMemoryMapToolBarView)

