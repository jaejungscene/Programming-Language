import { Observer } from 'mobx-react';
import { GridColumn } from "@progress/kendo-react-grid";
import * as React from "react";
import useStore from '../../../stores/useStore';
import { CustomHeaderCell, ValueCell } from "./DatagridItemRender";
import { DropdownFilterCell } from "./DropDownFilterCell";
import { FormulaType_DropDown, DataType_DropDown, SelectPLCAddress_DropDown, BoolType_DropDown } from './DropDownCell';

export const PlcColumnView = (props) => {
    
    const { PLCAddressEditStore } = useStore();
    const startAddressCategory = Array.from(
        new Set(
            PLCAddressEditStore.plcMemoryMap.map((p) => (p.StartAddress ? p.StartAddress : ""))
        )
    );

    const StartAddress_CategoryFillter =  React.useCallback((props) => (
        <DropdownFilterCell
            {...props}
            data={startAddressCategory}
            defaultItem={"Select"}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const collectionCategory = Array.from(
        new Set(
            PLCAddressEditStore.plcMemoryMap.map((p) => (p.Collection ? p.Collection : ""))
        )
    );
    const Collection_CategoryFillter = React.useCallback((props) => (
        <DropdownFilterCell
            {...props}
            data={collectionCategory}
            defaultItem={"Select"}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);

    const dataTypeCategory = Array.from(
        new Set(
            PLCAddressEditStore.plcMemoryMap.map((p) => (p.DataType ? p.DataType : ""))
        )
    );
    const DataType_CategoryFillter = React.useCallback((props) => (
        <DropdownFilterCell
            {...props}
            data={dataTypeCategory}
            defaultItem={"Select"}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);

    const formulaCategory = Array.from(
        new Set(
            PLCAddressEditStore.plcMemoryMap.map((p) => (p.FormulaType ? p.FormulaType : ""))
        )
    );
    const isReceipeCategory = Array.from(
        new Set(
            PLCAddressEditStore.plcMemoryMap.map((p) => (p.IsRecipe ? p.IsRecipe : ""))
        )
    );
    const isFlexibleIpCategory = Array.from(
        new Set(
            PLCAddressEditStore.plcMemoryMap.map((p) => (p.IsFlexibleIp ? p.IsFlexibleIp : ""))
        )
    );
    const FormulaType_CategoryFilter = React.useCallback((props) => (
        <DropdownFilterCell
            {...props}
            data={formulaCategory}
            defaultItem={"Select"}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const IsFlexibleIp_CategoryFilter = React.useCallback((props) => (
        <DropdownFilterCell
            {...props}
            data={isFlexibleIpCategory}
            defaultItem={"Select"}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const IsRecipe_CategoryFilter = React.useCallback((props) => (
        <DropdownFilterCell
            {...props}
            data={isReceipeCategory}
            defaultItem={"Select"}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const formulaType_DropDownCell = React.useCallback((td, props) => (
        <FormulaType_DropDown
            originalProps={props}
            td={td}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const boolType_DropDownCell = React.useCallback((td, props) => (
        <BoolType_DropDown
            originalProps={props}
            td={td}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const dataType_DropDownCell = React.useCallback((td, props) => (
        <DataType_DropDown
            onChangeDataType={onChangeDataType}
            originalProps={props}
            td={td}
            
        />
    ), [PLCAddressEditStore.plcMemoryMap]);
    const onChangeDataType = (selectItem) =>{
        props.onChangeDataType(selectItem);        
    };
    const selectPLCAddress_DropDownCell = React.useCallback((td, props) => (
        <SelectPLCAddress_DropDown
            originalProps={props}
            td={td}

        />
    ), [PLCAddressEditStore.plcMemoryMap]);

    const valueCell = React.useCallback((td, props) => (
        <ValueCell
            originalProps={props}
            td={td}
        />
    ), [PLCAddressEditStore.plcMemoryMap]);



    const cols = [];
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[0]} field={PLCAddressEditStore.plcMemoryMpaHeader[0]} width={'auto'} headerCell={CustomHeaderCell} editable={false} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[1]} field={PLCAddressEditStore.plcMemoryMpaHeader[1]} width={'auto'} headerCell={CustomHeaderCell} editable={false} filterCell={Collection_CategoryFillter} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[2]} field={PLCAddressEditStore.plcMemoryMpaHeader[2]} width={'auto'} headerCell={CustomHeaderCell} editable={false} filterCell={StartAddress_CategoryFillter} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[3]} field={PLCAddressEditStore.plcMemoryMpaHeader[3]} width={'auto'} headerCell={CustomHeaderCell} editable={true} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[4]} field={PLCAddressEditStore.plcMemoryMpaHeader[4]} width={'auto'} headerCell={CustomHeaderCell} editable={false} cell={dataType_DropDownCell} filterCell={DataType_CategoryFillter} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[5]} field={PLCAddressEditStore.plcMemoryMpaHeader[5]} width={'auto'} headerCell={CustomHeaderCell} cell={selectPLCAddress_DropDownCell} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[6]} field={PLCAddressEditStore.plcMemoryMpaHeader[6]} width={'auto'} headerCell={CustomHeaderCell} cell={formulaType_DropDownCell} filterCell={FormulaType_CategoryFilter} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[7]} field={PLCAddressEditStore.plcMemoryMpaHeader[7]} width={'auto'} headerCell={CustomHeaderCell} cell={selectPLCAddress_DropDownCell} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[8]} field={PLCAddressEditStore.plcMemoryMpaHeader[8]} width={'auto'} headerCell={CustomHeaderCell} editable={true} editor="numeric"  filterable={false}/>);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[9]} field={PLCAddressEditStore.plcMemoryMpaHeader[9]} width={'auto'} headerCell={CustomHeaderCell} editable={true} editor="numeric"  filterable={false}/>);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[10]} field={PLCAddressEditStore.plcMemoryMpaHeader[10]} width={'auto'} headerCell={CustomHeaderCell} editable={true} editor="numeric" filterable={false} />);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[11]} field={PLCAddressEditStore.plcMemoryMpaHeader[11]} width={'auto'} headerCell={CustomHeaderCell} editor="numeric" filterable={false} />);
    
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[16]} field={PLCAddressEditStore.plcMemoryMpaHeader[16]} width={'auto'} headerCell={CustomHeaderCell} filterable={false} cell={boolType_DropDownCell} filterCell={IsRecipe_CategoryFilter}/>);
    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[17]} field={PLCAddressEditStore.plcMemoryMpaHeader[17]} width={'auto'} headerCell={CustomHeaderCell} filterable={false} cell={boolType_DropDownCell} filterCell={IsFlexibleIp_CategoryFilter}/>);

    cols.push(<GridColumn key={PLCAddressEditStore.plcMemoryMpaHeader[12]} field={PLCAddressEditStore.plcMemoryMpaHeader[12]} width={'auto'} headerCell={CustomHeaderCell} cell={valueCell} editable={false} filterable={false} />);

    return cols;

}
