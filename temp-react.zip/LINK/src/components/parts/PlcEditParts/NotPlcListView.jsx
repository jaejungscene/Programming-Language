import React from 'react'

function NotPlcListView(props) {
    const moveToPLCAddPage = () => {
        props.moveToPLCAddPage();
    }
    return (
        <div>
            <h1 className='ComponentAlignCenter' style={{display : 'flex', justifyContent : 'center', textAlign : 'center'}}>
            등록된 PLC가 없습니다.

        </h1>
            <h1 className='ComponentAlignCenter' style={{display : 'flex', justifyContent : 'center', textAlign : 'center'}}>
                먼저 PLC를 입력해주세요.
            </h1>
            <br></br>
            <p className='ComponentAlignCenter'>
                <button style={{ backgroundColor: '#0d6efd', height: '300px', width: '500px', fontSize: '30px' }} onClick={() => { moveToPLCAddPage()}}>
                    PLC Add Page
                </button>
            </p>
        </div>
    )
}

export default NotPlcListView
