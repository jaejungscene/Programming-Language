import * as React from "react";
import { useState, useEffect, useRef, memo } from 'react'
import i18n from "i18next";
export const CustomHeaderCell = memo((props) => {
    // 향후 다국어 관련 개선 필요. hr.kwon98
    let replaceField = props.field;
    let appendTo = "";
    switch (replaceField) {
        case "PLCAddress" :
            replaceField = "LAN_PLC_ADDRESS";
            break;

        case "Collection" :
            replaceField = "LAN_COLLECTION";
            break;
        
        case "StartAddress" :
            replaceField = "LAN_START_ADDRESS";
            break;

        case "ParameterName" :
            replaceField = "LAN_PARAMENTER_NAME";
            break;

        case "DataType" :
            replaceField = "LAN_DATA_TYPE";
            break;

        case "SelectAddress_1" :
            replaceField = "LAN_SELECT_ADDRESS";
            appendTo = " 1";
            break;

        case "FormulaType" :
            replaceField = "LAN_FORMULA_TYPE";
            break;

        case "SelectAddress_2" :
            replaceField = "LAN_SELECT_ADDRESS";
            appendTo = " 2";
            break;

        case "StandardValue" : 
            replaceField = "LAN_STANDARD_VALUE";
            break;

        case "LowerErrorThreshold" :
            replaceField = "LAN_LOWER_ERROR_THRESHOLD";
            break;

        case "UpperErrorThreshold" :
            replaceField = "LAN_UPPER_ERROR_THRESHOLD";
            break;

        case "DigitalLength" : 
            replaceField = "LAN_DIGITAL_LENGTH";
            break;

        case "Value" :
            replaceField = "LAN_VALUE";
            break;

        default:
        break;
    };
    return (
        <td
            style={{
                textAlign: 'center',
                width: 'auto'
            }}
        >
            {/* {props.field} */}
            {i18n.t(replaceField)}{appendTo}
        </td>
    );
});
export const ValueCell = (props) => {    
    return (
        <td
            style={{
                textAlign: 'center',
                width: 'auto'
            }}
        >
            {props.td.dataItem.Value}
        </td>
    );
};
export const CellRender = memo((props) => {
    const dataItem = props.originalProps.dataItem;
    const cellField = props.originalProps.field;
    const inEditField = dataItem[props.editField || ""];
    let clickCheck = false;
    const additionalProps =
        cellField && cellField === inEditField
            ? {
                ref: (td) => {
                    const input = td && td.querySelector("input");
                    const activeElement = document.activeElement;
                    if (
                        !input ||
                        !activeElement ||
                        input === activeElement ||
                        !activeElement.contains(input)
                    ) {
                        return;
                    }
                    if (input.type === "checkbox") {
                        input.focus();
                    } else {
                        input.select();
                    }
                },
            }
            : {
                onClick: (event) => {
                    //double click
                    // if(event.detail === 2){
                    //     clickCheck = !clickCheck;
                    //     props.enterEdit(dataItem, cellField);

                    // }
                },
                style: {
                    textAlign: 'center',
                }
            };

    const clonedProps = {
        ...props.td.props,
        ...additionalProps,
    };
    return React.cloneElement(props.td, clonedProps, props.td.props.children);
});
export const RowRender = memo((props) => {
    const trProps = {
        ...props.tr.props,
        onClick: (e) => {
            props.rowclick(props.originalProps.dataItem);
        },
        // onBlur: () => {
        //     props.exitEdit(props.originalProps.dataItem);
        // },

    };
    return React.cloneElement(
        props.tr,
        {
            ...trProps,
        },
        props.tr.props.children
    );
});