import React from 'react';
//import {useEffect} from 'react';
import ShopItem from './ShopItem';
import useStore from '../../stores/useStore';
//import axios from "axios";

const items = [
  {
    name: '생수',
    price: 850,
  },
  {
    name: '신라면',
    price: 900,
  },
  {
    name: '포카칩',
    price: 1500,
  },
  {
    name: '새우깡',
    price: 1000,
  },
];

/*
var items2 = undefined

async function getData(){
  await axios.get("/httpApi/test2").then((res) => {
    items2 = res;
  });
}
*/

const ShopItemList = () => {

  //getData();

  const { marketStore } = useStore();
  const itemList = items.map(item => <ShopItem {...item} key={item.name} onPut={ () => { marketStore.put(item.name, item.price) }} />);
  return <div>{itemList}</div>;
};

export default ShopItemList;