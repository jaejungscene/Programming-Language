import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { useObserver } from 'mobx-react';
import ConnectCondition from './Common/ConnectCondition';
import {useState} from 'react';
import { useTranslation } from 'react-i18next';

function ProtocolView({ stores }) {

    const [dbConnectionStatus, setDBConnectionStatus] = useState(null);
    const [mqttConnectionStatus, setMQTTConnectionStatus] = useState(null);
    const [mesConnectionStatus, setMESConnectionStatus] = useState(null);

    const { t } = useTranslation();

    const OnProtocolTest = async (name) => {

        await stores.OnProtocolTest(name)

        switch (name) {
            case 'DB':
                setDBConnectionStatus(true);
                break;
            case 'MQTT':
                setMQTTConnectionStatus(true);
                break;
            case 'MES':
                setMESConnectionStatus(true);
                break;
            default:
                setDBConnectionStatus(false);
                setMQTTConnectionStatus(false);
                setMESConnectionStatus(false);
        }   
    }

    return useObserver(() => (
        <div style={{ margin: '10px', width: '80%', backgroundColor: 'white' }}>
            <Row xs="auto" style={{display:'flex', alignItems:'center'}}>
                <Col xs={2}>{t('LAN_DB_ADDRESS')}</Col>
                <Col>
                    <Form.Control type="text" placeholder="IP" defaultValue={stores.dbIP} onChange={(e) => stores.onChangeDbIp(e.target.value)} readOnly/>
                </Col>
                <Col>
                    <h4>:</h4>
                </Col>
                <Col>
                    <Form.Control type="text" placeholder="Port" defaultValue={stores.dbPort} onChange={(e) => stores.onChangeDbPort(e.target.value)} readOnly/>
                </Col>
                <Col>
                    <Button name='DB' variant="primary" onClick={(e) => { OnProtocolTest(e.target.name); }}>{t('LAN_TEST')}</Button>
                </Col>
                    <ConnectCondition visible={dbConnectionStatus} value={stores.dbConnectionStatus}/>
            </Row>
            <hr />
            <Row xs="auto" style={{display:'flex', alignItems:'center'}}>
                <Col xs={2}>{t('LAN_MQTT_ADDRESS')}</Col>
                <Col>
                    <Form.Control type="text" placeholder="IP" defaultValue={stores.mqttIP} onChange={(e) => stores.onChangeMqttIp(e.target.value)} readOnly/>
                </Col>
                <Col>
                    <h4>:</h4>
                </Col>
                <Col>
                    <Form.Control type="text" placeholder="Port" defaultValue={stores.mqttPort} onChange={(e) => stores.onChangeMqttPort(e.target.value)} readOnly/>
                </Col>
                <Col>
                    <Button name='MQTT' variant="primary" onClick={(e) => { OnProtocolTest(e.target.name); }}>{t('LAN_TEST')}</Button>
                </Col>
                    <ConnectCondition visible={mqttConnectionStatus} value={stores.mqttConnectionStatus}/>
            </Row>
            <hr />
            <Row xs="auto" style={{display:'flex', alignItems:'center'}}>
                <Col xs={2}>{t('LAN_MES_ADDRESS')}</Col>
                <Col>
                    <Form.Control type="text" placeholder="IP" defaultValue={stores.mesIP} onChange={(e) => stores.onChangeMesIp(e.target.value)} readOnly />
                </Col>
                <Col>
                    <h4>:</h4>
                </Col>
                <Col>
                    <Form.Control type="text" placeholder="Port" defaultValue={stores.mesPort} onChange={(e) => stores.onChangeMesPort(e.target.value)} readOnly />
                </Col>
                <Col>
                    <Button name='MES' variant="primary" onClick={(e) => { OnProtocolTest(e.target.name); }} disabled="True">{t('LAN_TEST')}</Button>
                </Col>
                    <ConnectCondition visible={mesConnectionStatus} value={stores.mesConnectionStatus} />
            </Row>
        </div>
    ));
}

export default ProtocolView;