import { Link } from "react-router-dom";
import userImage from '../../public/images/user.png';
import { useRef } from 'react';
import { useEffect, useState } from "react";
import useStore from "../../stores/useStore";
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AiFillAlert } from "react-icons/ai";
import { AiOutlineGlobal } from "react-icons/ai";
import { AiOutlineLogout } from "react-icons/ai";
import { IoIosSettings } from "react-icons/io";
import { BsChevronUp } from "react-icons/bs";
import { BsChevronDown } from "react-icons/bs";
import AlertModal from "./Common/AlertModal"
import { useObserver } from 'mobx-react';
import UserInformationCardView from '../views/UserInformationCardView'
import styled, { keyframes } from 'styled-components';
import Tooltip from "react-bootstrap/esm/Tooltip";
import Overlay from 'react-bootstrap/Overlay';
import swal from 'sweetalert2';
import LoadingSpinner from './Common/Spinner';
import DropDownList from "./Common/DropDownList";

function HeaderView(props) {
    const { mainViewStore, headerViewStore, dashBoardStore, ipDashBoardStore } = useStore();
    const languageRef = useRef(null);
    const loginRef = useRef(null);
    const loginUser = useRef(null);
    const languageLabel = useRef(null);
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [alertPageShow, setalertPageShow] = useState(false);
    const [userInformationShow, setUserInformationShow] = useState(false);
    const { alertHistoryStore } = useStore();
    const alertRef = useRef(null);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedItem, setSelectedItem] = useState(0);

    useEffect(() => {
        if (mainViewStore.loginUser) {
            loginUser.current.innerText = mainViewStore.loginUser.UserName;
            languageLabelChange(mainViewStore.selectedLanguage);
        }
        else {
            loginUser.current.innerText = 'Unknown';
        }
        headerInitialize();
    }, [mainViewStore, headerViewStore]);

    const getHeaderDropDownDataList = async () =>{
        if(selectedItem === 0){
            await headerViewStore.headerViewInitialize();
        }
    };
    
    const headerInitialize = async () => {
        if (!alertHistoryStore.webSocket){
            await alertHistoryStore.initialize(mainViewStore.getWebsocket());
        }

        loadRecentAlertsInfo();
        await getHeaderDropDownDataList();
        dashBoardStore.setSelectedEquipmentId(headerViewStore.selectedEquipmentId);
        ipDashBoardStore.setSelectedEquipmentId(headerViewStore.selectedEquipmentId);
    };

    function languageClickEvent() {
        languageRef.current.children[0].focus();
        languageRef.current.classList.toggle('on');
    }

    function languageLabelChange(lan) {
        switch (lan) {
            case 'en':
                languageLabel.current.innerText = t('LAN_ENG');
                break;
            case 'ko':
                languageLabel.current.innerText = t('LAN_KOR');
                break;
            /*
            case 'cn':
                console.log('cn selected');
                languageLabel.current.innerText = 'Chinese'
                break;
            */
            default:
                languageLabel.current.innerText = t('LAN_ENG');
        }
    }

    function languageChangedEvent(event) {
        let selectedLanguage = event.target.id;
        mainViewStore.onChangeLanguage(selectedLanguage);
        languageLabelChange(selectedLanguage);
        languageRef.current.classList.toggle('on');
    }

    async function logoutClickEvent() {
        let result = await mainViewStore.onLogout();
        //navigate using is react component and react hooks
        if (result) {
            navigate('/login');
        }
    }

    async function settingClickEvent() {
        navigate('/system/setting');

        // let datas = [];
        // let data = {
        //     EquipmentID: '1',
        //     PLCAddress: 'D1000',
        //     Value:'100',
        //     AlarmType:'1',
        //     CreDate:new Date(),
        //     WarningThreshold:'80',
        //     ErrorThreshold:'90',
        //     AlarmMessage:'테스트알람발생',
        //     CollectionInfoID : 'ROLL_FRONT',
        //     BlockInfoID : 'FRONT_NIPROLL_PRESSURE',
        //     ParameterName : '임시파라미터네임',
        // }
        // datas.push(data);
        // alertHistoryStore.addAlertList(datas);
        // alertHistoryStore.setAlarmListDataByParts(datas);

    }

    async function handleCloseAlertHistory() {
        alertHistoryStore.isExistNewAlert = false;
        setalertPageShow(false);
        await alertHistoryStore.initAlertList();
    }

    async function handleShowAlertHistory() {
        //loadRecentAlertsInfo();

        //const datas = await Fetcher('get', '/getRecentAlertsInfoList/');
        
        //setIsLoading(true);
        //await alertHistoryStore.getAlertList();

        // 알람 페이지 미사용
        // alertHistoryStore.isExistNewAlert = false;
        // setalertPageShow(true);
        // setIsLoading(false);
        
        //navigate('/alarmHistory')
        
    }

    async function loadRecentAlertsInfo() {
        //const datas = await Fetcher('get', 'http://localhost:3001/getRecentAlertsInfoList/');
        
        await alertHistoryStore.initAlertList();
    }

    function showUserInformation() {
        setUserInformationShow(true);
    }

    //Clear기능 임시 제외
    function clearAlertList(){
        if(alertHistoryStore.getAlertCount() === 0){
            swal.fire({
                title: t('MSG_NO_ALERT'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });

            return;
        }else{
            alertHistoryStore.initAlertList();

            swal.fire({
                title: t('MSG_CLEAR_ALERT'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
    }

    function getAlertCount(){
        if(mainViewStore.isDateChanged){
            alertHistoryStore.alertCount = 0;
            alertHistoryStore.isExistNewAlert = false;
            mainViewStore.isDateChanged = false;            
        }
        return alertHistoryStore.alertCount;
    }

    const handleSelect = (e) => {
        let equipmentId = e.target.value;
        setSelectedItem(equipmentId);
        headerViewStore.onChangeEquipmentId(equipmentId);
        dashBoardStore.setSelectedEquipmentId(equipmentId);
        ipDashBoardStore.setSelectedEquipmentId(equipmentId);
    }


    function blinkingEffect() {
        return keyframes`
        50% {
          opacity: 0;
        }
      `;
    }

    /*
    const AnimatedComponent = styled.div`
        animation: ${blinkingEffect} 1s linear infinite;
      `
    */

    return useObserver(() =>
        <header>
            { isLoading && <LoadingSpinner /> }
            {/*AlertModal show={alertPageShow} clearList={clearAlertList} handleClose={handleCloseAlertHistory} datas={alertHistoryStore.alertList}></AlertModal>*/}
            <div className="pg_nm">
                <i className="logo_white"></i>
                <Link className='navbar-brand' to='/dashboard/trendMonitoring'>{t('LAN_PROGRAM_TITLE')}</Link>
            </div>
            <div className="user_info">
                <div style={{ display: 'flex', alignItems:'center' }}>
                    <DropDownList options={headerViewStore.dropdownItemList} label={t('LAN_EQUIPMENT_LIST')} width={'300px'} onSelect={(e) => {handleSelect(e); props.equipmentChangeEvent();}} />
                </div>
                <span className="split"></span>
                <div onClick={showUserInformation} className="header-user-title" style={{cursor:'pointer'}}>
                    <img src={userImage} />
                    <span className="name" ref={loginUser}></span>
                </div>
                <span className="split"></span>
                <div style={{cursor:'pointer'}}>
                    <a onClick={handleShowAlertHistory}>
                        <AiFillAlert className={getAlertCount() > 0 ? "active-header-symbol header-symbol" : "header-symbol"}></AiFillAlert>
                        <label ref={alertRef}className={getAlertCount() > 0 ? "active-header-symbol" : ""}>&nbsp; {getAlertCount()}&nbsp;{t('LAN_COUNT')}</label>
                        {!alertPageShow && <Overlay target={alertRef.current} show={alertHistoryStore.isExistNewAlert} placement="bottom">
                            <Tooltip>
                                {t('LAN_NEW_ALARM')}
                            </Tooltip>
                        </Overlay>
                        }
                    </a>
                </div>
                <span className="split"></span>
                <div style={{cursor:'pointer'}}>
                    <a id="select_lang" href="#" onClick={settingClickEvent}>
                        <IoIosSettings className="header-symbol"></IoIosSettings>
                        <label>{t('LAN_SETTING')}</label>
                    </a>
                </div>
                <span className="split"></span>
                <div className="lang_grp" ref={languageRef} style={{cursor:'pointer', marginRight: '15px'}}>
                    <a id="select_lang" href="#" onClick={languageClickEvent}>
                        <AiOutlineGlobal className="header-symbol"></AiOutlineGlobal>
                        <label ref={languageLabel}></label>
                        &nbsp;
                        <BsChevronUp className="header-symbol-up"></BsChevronUp>
                        <BsChevronDown className="header-symbol-down"></BsChevronDown>
                    </a>
                    <div className="lang_popup">
                        <div id='en' onClick={languageChangedEvent}>{t('LAN_ENG')}</div>
                        <div id='ko' onClick={languageChangedEvent}>{t('LAN_KOR')}</div>
                        {/*<div id='cn' onClick={languageChangedEvent}>Chinese</div>*/}
                    </div>
                </div>
                <span className="split"></span>
                <div style={{cursor:'pointer'}}>
                    <a href="#" onClick={logoutClickEvent}>
                        <AiOutlineLogout className="header-symbol"></AiOutlineLogout>
                        <label ref={loginRef}>{t('LAN_LOGOUT')}</label>
                    </a>
                </div>
            </div>
            <UserInformationCardView user={mainViewStore.loginUser} show={userInformationShow} onHide={() => { setUserInformationShow(false); }} />
        </header>
    );
}

export default HeaderView;