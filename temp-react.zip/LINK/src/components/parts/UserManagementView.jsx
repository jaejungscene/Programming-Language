import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import UserManagementListView from './UserManagementListView';
import UserInformationView from './UserInformationView';
import CurrentTimer from './Common/CurrentTimer';
import React, { useEffect, useState } from "react";
import useStore from '../../stores/useStore';
import Button from 'react-bootstrap/esm/Button';
import swal from 'sweetalert2';
import { useTranslation } from 'react-i18next';
import { useRef } from 'react';

function UserManagementView() {

    const { userManagementStore, currentTimerStore, userManagementListStore } = useStore();
    const [showDeleteButton, setShowDeleteButton] = useState(false);
    const { t } = useTranslation();    
    const userListViewRef = useRef();

    useEffect(() => {
        
        currentTimerStore.initialize();
        userManagementListInitialize();
        
    }, [currentTimerStore, userManagementListStore,userListViewRef]);

    async function userManagementListInitialize() {
        await userManagementListStore.initializeUserManagementListStore();
    }

    async function onSaveUserInfo(){
        
        let result = await userManagementStore.onSaveUserInfo(userListViewRef.current.children);

        if (result.result) {

            swal.fire({
                title: t('MSG_USER_INFO_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
            userManagementListInitialize();
            clearUserList();
        }
        else {
            swal.fire({
                title: t('MSG_USER_INFO_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    async function deleteUserInfo(){
        let result = await userManagementStore.deleteUserInfo();
        if (result) {
            userManagementListInitialize();
            clearUserList();
            setShowDeleteButton(false);
        }
       
    }

    function clearUserList(){
        for (let item of userListViewRef.current.children) {
            if (item.className === 'table-active') {
                item.classList.remove('table-active');                
            }      
        }        
    }

    return (
        <div class="page-inner-container">
            <Row>
                <Col> 
                    <h4>
                    {t('LAN_USER_LIST')}
                    </h4>
                </Col>
            </Row>
            <Row>
                <Col>
                    <UserManagementListView ref={userListViewRef} stores={userManagementListStore} userList={userManagementListStore.userList} onRowClicked={
                            (item) => {userManagementStore.onChangeSelectedUserInfo(item);
                                if(item !== undefined){
                                    setShowDeleteButton(true);
                                }
                                else{
                                    setShowDeleteButton(false);
                                }
                        }}/>
                </Col>
            </Row>
            <br />
            <Row>
                <Col>
                    <h4>
                    {t('LAN_USER_INFORMATION_EDIT')}
                    </h4>
                </Col>
            </Row>
            <Row>
               <Col>
                    <UserInformationView stores={userManagementStore} userListStores={userManagementListStore}/>
               </Col>
            </Row>
            <Row>
                <Col>
                    <div className="d-flex justify-content-end">
                        <Button variant="primary" onClick={() => onSaveUserInfo()}>{t('LAN_SAVE')}</Button>
                        {showDeleteButton && <Button variant="primary" onClick={() => deleteUserInfo()}>{t('LAN_DELETE')}</Button>} 
                    </div>
                </Col>
            </Row>
            <Row>
                <Col>
                    <div className="d-flex justify-content-end">
                        <CurrentTimer stores={currentTimerStore} />
                    </div>
                </Col>
            </Row>
        </div>
    );
}

export default UserManagementView;