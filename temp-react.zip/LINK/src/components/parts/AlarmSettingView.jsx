import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Table from 'react-bootstrap/Table';
import React, { useEffect, useState, useRef } from "react";
import useStore from '../../stores/useStore';
import Button from 'react-bootstrap/esm/Button';
import {format} from 'date-fns';
import swal from 'sweetalert2';
import { useTranslation } from 'react-i18next';
import EquipmentClassificationCombo from './Common/EquipmentClassificationCombo';
import LoadingSpinner from './Common/Spinner';

function AlarmSettingView(props) {
  const formRef = useRef();
  const {t} = useTranslation();
  const { alarmSettingStore } = useStore();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    initialize();
  }, []);

  const initialize = async () => {
    await searchAlarmInfo(formRef.current);
    setIsLoading(false);
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    await searchAlarmInfo(e.target);
  }

  const searchAlarmInfo = async (form) => {
    try {
      setIsLoading(true);

      const formData = new FormData(form);
      alarmSettingStore.collection_info_id = formData.get("collection_info_id");
      alarmSettingStore.block_info_id = formData.get("block_info_id");
      alarmSettingStore.plc_address_info_id = formData.get("plc_address_info_id");
      alarmSettingStore.keyword = formData.get("keyword");

      await alarmSettingStore.searchAlarmInfo();

      setIsLoading(false);
    }catch(err) {
      console.log(err);
      setIsLoading(false);
    }
  }
 
  return (
    <div class="page-inner-container">
      { isLoading === true && <LoadingSpinner /> }
        <Row>
            <Col> 
                <h4 className='page-title'>
                {t('LAN_ALARM_INFO')}
                </h4>
            </Col>
        </Row>

        <Row>
          <Col>
            <Card>
              <Card.Header>{t("LAN_SEARCH_KEY")}</Card.Header>
              <Card.Body>
                <form 
                  class="common-form flex-form"
                  onSubmit={onSubmit}
                  ref={formRef}
                >
                  <span class="label">
                    {t('LAN_EQUIPMENT_CATEGORY')}
                  </span>
                  <EquipmentClassificationCombo />

                  <span class="null"></span>

                  <label for="alarm_keyword">
                    {t("LAN_KEYWORD")}
                  </label>
                  <input type='text' id='alarm_keyword' name='keyword' />

                  <button type="submit">
                    {t('LAN_SEARCH')}
                  </button>
                </form>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <br />

        <Row>
          <Col>
            <Card>
              <Card.Header>{t('LAN_ALARM_INFO_LIST')}</Card.Header>

              <Card.Body className="setting-scroll-body scrollbar">
                <Table>
                  <thead>
                    <tr>
                      <th>{t('LAN_NO')}</th>
                      <th>{t('LAN_SERVICE')}</th>
                      <th>{t('LAN_ALARM_CODE')}</th>
                      <th>{t('LAN_ALARM_NAME')}</th>
                      <th>{t('LAN_MAJOR_CLASSIFICATION')}</th>
                      <th>{t('LAN_MEDIUM_CLASSIFICATION')}</th>
                      <th>{t('LAN_SUB_CLASSIFICATION')}</th>
                      <th>{t('LAN_CREATE_DATE')}</th>
                    </tr>
                  </thead>

                  <tbody>
                    {
                      alarmSettingStore.alarmInfoList.map((item) => {
                        return <tr>
                          <td>
                            {item.alarm_standard_info_seq_id}
                          </td>
                          <td>
                            {item.service_name}
                          </td>
                          <td>
                            {item.alarm_code}
                          </td>
                          <td>
                            {item.alarm_name}
                          </td>
                          <td>
                            {item.collection_name}
                          </td>
                          <td>
                            {item.block_name}
                          </td>
                          <td>
                            {item.plc_address_info_name}
                          </td>
                          <td>
                            {format(item.create_date, "yyyy-MM-dd HH:mm:ss")}
                          </td>
                          <td>
                            {item.block}
                          </td>
                        </tr>
                      })
                    }
                  </tbody>
                </Table>
              </Card.Body>
            </Card>
          </Col>
        </Row>
    </div>
  )
}

export default AlarmSettingView