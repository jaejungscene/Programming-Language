import DashBoard from './TrendMonitoringView';
import React, { useState } from "react";


const DashBoardView = () => {
    const [currentTab, setCurrentTab] = useState("dashBoard");

    return (
        <div style={{margin: '10px', backgroundColor:'white'}}>
            <DashBoard />
            {}
        </div>
    );
}

export default DashBoardView;