import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import DateTimePicker from './Common/DateTimePicker';
import DropDownList from './Common/DropDownList';
import LineChart from './Common/Chart/LineChart';
import Table from './Common/Table'
import {useState, useEffect} from 'react';
import Fetcher from './Common/Fetcher'
import {startOfWeek, subDays} from 'date-fns'
import useStore from '../../stores/useStore'
import { useObserver } from 'mobx-react';
import moment from 'moment';
import Accordion from 'react-bootstrap/Accordion';
import { useTranslation } from 'react-i18next';
import LoadingSpinner from './Common/Spinner';
import styled from 'styled-components';
import DryDetail from './Common/DryDetail';

var orgModuleList = [];
var styles = styled.div`
${``/*.table {
    height: 370px;
    width: 100%;
    tbody {
        height: 340px;
        table-layout: fixed;
        display: block;
        overflow-y: auto;
        overflow-x: hidden;
    }

    thead, tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
    }
}
*/}
height: 370px;
overflow-y: scroll;
`

function DryingFurnaceView(){
    const [isLoading, setIsLoading] = useState(false);
    const {t} = useTranslation();
    const [selectedItem, setSelectedItem] = useState(0);
    const [options, setOptions] = useState([{value: 0, name: 'ZONE1'}]);
    const [selectedLocItem, setSelectedLocItem] = useState(0);
    const [locOptions, setLocOptions] = useState([{value: 0, name: 'A면'}])
    const [fromDate, setFromDate] = useState(subDays(new Date(), 7));
    const [toDate, setToDate] = useState(new Date());
    const { headerViewStore } = useStore();
    const [trendData, setTrendData] = useState([]);


    const tableColumns = [
        {
            accessor: 'No',
            Header: t("LAN_TABLE_NO"),
            width: 50
        },
        {
            accessor: 'Name',
            Header: t("LAN_TABLE_NAME"),
            width: 100
        },
        {
            accessor: 'CreDate',
            Header: t("LAN_TABLE_DATE"),
            width: 200
        },
        {
            accessor: 'AlarmType',
            Header: t("LAN_TABLE_TYPE"),
            width: 100
        },
        {
            accessor: 'Value',
            Header: t("LAN_TABLE_VALUE"),
            width: 100
        },
        {
            accessor: 'Message',
            Header: t("LAN_TABLE_MESSAGE"),
            width: 300
        },
    ];
    const [historyTableData, setHistoryTableData] = useState([]);
    
    useEffect(()=> {
        initializeComponentDatas();
    }, []);

    useEffect(()=> {
        if(options.length != 1){
            refreshAnalysisData();
        }
    }, [options, headerViewStore.selectedEquipmentId]);

    const initializeComponentDatas = async() => {
        let tmpOptions = [];
        let params = {
            moduleType: "DRYZONE"
        }
        try {
            setIsLoading(true);
            const datas = await Fetcher('get', '/getAllModuleInfoList/', {params});
            for (let data of datas) {                
                tmpOptions.push({value:data.SeqId, name:data.ModuleName});
            }
            setOptions(tmpOptions);
            setSelectedItem(tmpOptions[0].value);
            setIsLoading(false);
        } catch(err) {
            setIsLoading(false);
            console.log(err.message);
        }
    }

    const handleDateTimePicker = (type, date) => {
        if(type == 'from') {
            setFromDate(date);
        }
        else {
            setToDate(date);
        }
    }

    const handleLocSelect = (e) => {
        setSelectedLocItem(e.target.value);
        let startNo = parseInt(orgModuleList[0].value.slice(3, 6));
        let tmpOptions = [];
        setOptions(tmpOptions);
        for (let data of orgModuleList) {
            let num = parseInt(data.value.slice(3, 6));
            if (parseInt(e.target.value) == Math.floor(num / (12+ startNo))) {
                tmpOptions.push({value:data.value, name:data.name});
            }
        }
        if (tmpOptions.length <= 0)
            return;

        setOptions(tmpOptions);
        setSelectedItem(tmpOptions[0].value);
    }

    const handleSelect = (e) => {
        setSelectedItem(e.target.value);
    }

    const handleRowSelect = (row) => {
        
    }

    const refreshAnalysisData = async (e) => {
        try {
            setIsLoading(true);
            const datas = await getDryZoneAnalysisData();
            let newTableData = [];

            datas.alarmHistory.forEach((data, index)=>{
                newTableData.push({
                    No: index+1,
                    Name: data.Name,
                    CreDate: moment(data.CreDate).format("YYYY-MM-DD HH:mm:ss"),
                    AlarmType: data.AlarmType,
                    Value: data.DetailInfo.value,
                    Message: data.AlarmMessage
                });
    
            });
            setHistoryTableData(newTableData);

            let newTrendData = [];

            let newDiffPressure = [];
            let newPlateTemperature = [];
            let newRoomTemperature = [];
            let newSupplyWindSpeed = [];
            let newExhaustWindSpeed = [];
            let name = '';
            let unit = '';
            datas.trendData.forEach((blkDatas)=>{
                blkDatas.forEach((detailInfo)=>{
                    switch(detailInfo.blockID){
                        case 'ZONE1_DIFF_PRESSURE':
                        case 'ZONE2_DIFF_PRESSURE':
                        case 'ZONE3_DIFF_PRESSURE':
                        case 'ZONE4_DIFF_PRESSURE':
                        case 'ZONE5_DIFF_PRESSURE':
                        case 'ZONE6_DIFF_PRESSURE':
                            name = t('LAN_' + detailInfo.BlockName);
                            unit = 'MPa';
                            newDiffPressure.push({
                                name:name,
                                unit:unit,
                                avg:detailInfo.avg,
                                max:detailInfo.max,
                                parameterName:detailInfo.ParameterName,
                                chartData:makeLineChartOption(name, unit, detailInfo.ParameterName, datas.timeStamp, detailInfo.data)

                            });
                            break;
                        case 'ZONE1_PLATE_TEMPERATURE':
                        case 'ZONE2_PLATE_TEMPERATURE':
                        case 'ZONE3_PLATE_TEMPERATURE':
                        case 'ZONE4_PLATE_TEMPERATURE':
                        case 'ZONE5_PLATE_TEMPERATURE':
                        case 'ZONE6_PLATE_TEMPERATURE':
                            name = t('LAN_' + detailInfo.BlockName);
                            unit = '℃';
                            newPlateTemperature.push({
                                name:name,
                                unit:unit,
                                avg:detailInfo.avg,
                                max:detailInfo.max,
                                parameterName:detailInfo.ParameterName,
                                chartData:makeLineChartOption(name, unit, detailInfo.ParameterName, datas.timeStamp, detailInfo.data)
                            });
                            break;
                        case 'ZONE1_ROOM_TEMPERATURE':
                        case 'ZONE2_ROOM_TEMPERATURE':
                        case 'ZONE3_ROOM_TEMPERATURE':
                        case 'ZONE4_ROOM_TEMPERATURE':
                        case 'ZONE5_ROOM_TEMPERATURE':
                        case 'ZONE6_ROOM_TEMPERATURE':
                            name = t('LAN_' + detailInfo.BlockName);
                            unit = '℃';
                            newRoomTemperature.push({
                                name:name,
                                unit:unit,
                                avg:detailInfo.avg,
                                max:detailInfo.max,
                                parameterName:detailInfo.ParameterName,
                                chartData:makeLineChartOption(name, unit, detailInfo.ParameterName, datas.timeStamp, detailInfo.data)
                            });
                            break;
                        case 'ZONE1_SUPPLY_WIND_SPEED':
                        case 'ZONE2_SUPPLY_WIND_SPEED':
                        case 'ZONE3_SUPPLY_WIND_SPEED':
                        case 'ZONE4_SUPPLY_WIND_SPEED':
                        case 'ZONE5_SUPPLY_WIND_SPEED':
                        case 'ZONE6_SUPPLY_WIND_SPEED':
                            name = t('LAN_' + detailInfo.BlockName);
                            unit = 'RPM';
                            newSupplyWindSpeed.push({
                                name:name,
                                unit:unit,
                                avg:detailInfo.avg,
                                max:detailInfo.max,
                                parameterName:detailInfo.ParameterName,
                                chartData:makeLineChartOption(name, unit, detailInfo.ParameterName, datas.timeStamp, detailInfo.data)
                            });
                            break;
                        case 'ZONE1_EXHAUST_WIND_SPEED':
                        case 'ZONE2_EXHAUST_WIND_SPEED':
                        case 'ZONE3_EXHAUST_WIND_SPEED':
                        case 'ZONE4_EXHAUST_WIND_SPEED':
                        case 'ZONE5_EXHAUST_WIND_SPEED':
                        case 'ZONE6_EXHAUST_WIND_SPEED':
                            name = t('LAN_' + detailInfo.BlockName);
                            unit = 'RPM';
                            newExhaustWindSpeed.push({
                                name:name,
                                unit:unit,
                                avg:detailInfo.avg,
                                max:detailInfo.max,
                                parameterName:detailInfo.ParameterName,
                                chartData:makeLineChartOption(name, unit, detailInfo.ParameterName, datas.timeStamp, detailInfo.data)
                            });
                            break;
                    }
                });

            });

            if(newDiffPressure.length != 0) newTrendData.push(newDiffPressure);
            if(newPlateTemperature.length != 0) newTrendData.push(newPlateTemperature);
            if(newRoomTemperature.length != 0) newTrendData.push(newRoomTemperature);
            if(newSupplyWindSpeed.length != 0) newTrendData.push(newSupplyWindSpeed);
            if(newExhaustWindSpeed.length != 0) newTrendData.push(newExhaustWindSpeed);
            setTrendData(newTrendData);
            setIsLoading(false);
        } catch(err) {
            setIsLoading(false);
            console.log(err.message);
        }
    }

    const makeLineChartOption = (name, unit, parameterName, timestamp, detailData) =>{

        let trendData = {};

        trendData.title = {
            //text: parameterName + ' ('+ unit +')',
            textStyle: {
                fontSize: 15,
              },
            padding: [0, 0, 0, 0], // 상단, 우측, 하단, 좌측 간격
        }

        trendData.xAxis = {
            name :'Time',
            boundaryGap: false,
            axisLabel: {
                formatter: (function(value){
                    return moment(value).format('HH:mm:ss');
                })
            },
            data : timestamp
        }
        trendData.yAxis = {
            type : 'value',
            //name: parameterName + ' ('+ unit +')',            
            name:' ('+ unit +')',
                max: function (value) {
                    return (value.max*1.1).toFixed(1)
                },
                min: function (value) {
                    return (value.min*0.9).toFixed(1)
                },
        }
        trendData.series = [];

        trendData.series.push({
            //name: name,
            type: 'line',
            smooth: true,
            data: detailData,
        });

        trendData.tooltip = {
            trigger: 'axis',
            formatter: function(params, ticket, callback) {
                var newDate = new Date(params[0].name);
                var res = moment(newDate).format("YYYY-MM-DD HH:mm:ss");
                for (var i = 0, l = params.length; i < l; i++) {
                    res += '<br/>' + params[i].seriesName + ': ' + params[i].value + ' MPa';
                } 
                setTimeout(function() {
                    callback(ticket, res);
                }, 100)
                return 'loading';
            }
        };
        trendData.dataZoom = {
            show: true,
            start: 0,
            end: 100
        };
        trendData.grid = {
            left: '6%',
            right: '6%',
            top: 25,
            bottom: 70,
            width: 'auto',
            height: 'auto'
        };
        trendData.legend = {
            //data: [name]
        };

        return trendData;
    }

    const getDryZoneAnalysisData = async () => {
        let idx = Number(selectedItem) -1;
        let params = {
            moduleType: 'DRYZONE',
            fromDate : fromDate,
            toDate : toDate,
            selectedItemLst : [options[idx].name],
            selectedZone : [options[idx].name],
            equipmentID : headerViewStore.selectedEquipmentId
        }
        //return await Fetcher('get', 'http://localhost:3001/getAnalysisData', {params});
        return await Fetcher('get', '/getAnalysisData', {params});
    }

    return useObserver(()=>(
        <Container fluid>
            { isLoading && <LoadingSpinner /> }
            <Row id='body' style={{padding:'20px 10px'}}>
                <Col>
                    <Card>
                        <Card.Header>{t("LAN_SEARCH_KEY")}</Card.Header>
                        <Card.Body>
                            <Stack direction="horizontal" gap={4}>
                                <DateTimePicker from={fromDate} to={toDate} onChangeDate={handleDateTimePicker} />
                                <div className='vr'/>
                                <DropDownList options={locOptions} label={t("LAN_LOCATION")} width={'150px'} onSelect={handleLocSelect} />
                                <div className='vr'/>
                                <DropDownList options={options} label={t("LAN_DRY_ZONE")} width={'200px'} onSelect={handleSelect} />
                                <button title='Search' onClick={refreshAnalysisData}>{t("LAN_SEARCH")}</button>
                            </Stack>
                        </Card.Body>
                    </Card>
                    {
                        <DryDetail viewInfo={trendData} chartData={trendData} />
                    }
                    <Card style={{marginTop: '40px', height: '440px'}}>
                        <Card.Header>{t("LAN_ALARM_HISTORY")}</Card.Header>
                        <Card.Body>
                            {<Table columns={tableColumns} data={historyTableData} onSelectBatch={handleRowSelect} Styles={styles}/>}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            <Row id='footer'>
            </Row>
        </Container>
    ));

}

export default DryingFurnaceView;