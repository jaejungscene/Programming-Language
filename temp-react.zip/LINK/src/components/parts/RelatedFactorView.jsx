import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import { useTranslation } from 'react-i18next';
import { TbDeviceDesktopAnalytics } from "react-icons/tb";
import React, { useEffect, useState, useRef } from "react";
import RelatedBlockCart from './Common/RelatedBlockCart';
import LineChart from './Common/Chart/LineChart';
import moment from 'moment';
import BlockRealTimeChart from './Common/BlockRealTimeChart';

function RelatedFactorView(props) {
    const { t } = useTranslation();
    return (
        <div>
            <Row>
                <div style={{ width: '280px', lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft: "30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '5px 5px 0px 0px', margin: '10px 15px 0 35px' }}>
                    <TbDeviceDesktopAnalytics style={{ marginTop: '-5px' }} />
                    &nbsp;&nbsp;&nbsp;{t('LAN_RELATED_FACTOR')}
                </div>
            </Row>


            <Row style={{ margin: '0px 10px 0 10px' }}>
                <Col>
                    <Card style={{ height: '480px', width: '1648px', overflowY: 'auto' }}>
                        <Card.Body style={{ paddingTop: '20px', paddingLeft: '80px' }}>
                            <Stack direction="vertical" gap={0}>
                                {MakeRow(props.viewData)}
                            </Stack>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </div>
    )
}

function MakeRow(viewData)
{
    if(viewData == null){
        return;
    }

    let array = [];
    let keys = Object.keys(viewData);

    for (let i = 0; i < keys.length; i+=2){

        array.push(
            <Row>
                <Col>
                <RelatedBlockCart chartWidth={'750px'} chartHeight={'240px'} viewData={viewData[keys[i]]}> </RelatedBlockCart>
                </Col>
                {viewData[keys[i+1]] !== undefined ? (
                    <Col>
                    <RelatedBlockCart chartWidth={'750px'} chartHeight={'240px'} viewData={viewData[keys[i+1]]}> </RelatedBlockCart>
                    </Col>
                ) : (
                    <Col></Col>
                )}

            </Row>
        );
    }

    return array;
}



export default RelatedFactorView
