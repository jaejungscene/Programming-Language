import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Observer } from 'mobx-react';
import React, { useEffect, useState, useRef } from "react";
import useStore from '../../stores/useStore';
import PLCListView from './PLCListView';
import PLCInformationView from './PLCInformationView';

function PLCView(props) {

    const { plcManagementStore } = useStore();
    const plcListViewRef = useRef();
    const [plcListStatus, setPlcListStatus] = useState(false);

    const plcInitialize = async () => {
        //props.plcChanged();
        await plcManagementStore.initializePlcManagementListStore();
        setPlcListStatus(true);
    }

    useEffect(() => {
        plcInitialize();
    },);

        
    function clearPlcList(){
        for (let item of plcListViewRef.current.children) {
            if (item.className === 'table-active') {
                item.classList.remove('table-active');                
            }      
        }        
    }
    
    return (
        <Observer>
        {() => (
            <div className='page-inner-container'>
                <Row>
                    <Col sm={8}>
                        {plcListStatus && <PLCListView ref={plcListViewRef} stores={plcManagementStore} 
                        onRowClicked={ (item) => { plcManagementStore.onChangeSelectedPlcInfo(item); }} />}
                    </Col>
                    <Col sm={4}>
                        {<PLCInformationView ref={plcListViewRef} stores={plcManagementStore} initialize={() => {plcInitialize(); clearPlcList();}} />}
                    </Col>
                </Row>
            </div>
        )}
        </Observer>
    );
}


export default PLCView;