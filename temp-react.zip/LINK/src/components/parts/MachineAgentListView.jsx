import { Observer } from 'mobx-react';
import { useRef } from 'react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import swal from 'sweetalert2';
import MachineAgentRunTypeDropDown from './Common/MachineAgentRunTypeDropDown';
import StartStopButton from './Common/StartStopButton';
import { useTranslation } from 'react-i18next';

function MachineAgentListView(props) {

    const tableBodyRef = useRef(null);
    const { t } = useTranslation();

    function onRowClicked(e, item) {
        let temp = item;
        for (let item of tableBodyRef.current.children) {
            if (e.currentTarget.id === item.id) {
                if (e.currentTarget.className === 'table-active') {
                    temp = undefined;
                }
                item.classList.toggle('table-active');
            }
            else {
                item.classList.remove('table-active');
            }
        }

        props.onChangeMachineAgent(temp);
    }

    async function onMachineAgentAllStart(){
        let result = await props.stores.onMachineAgentAllStart();

        if (result) {
            swal.fire({
                title: t('MSG_MA_ALL_START'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else {
            swal.fire({
                title: t('MSG_MA_PROBLEM'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }

    }

    async function onMachineAgentAllStop(){
        let result = await props.stores.onMachineAgentAllStop();

        if (result) {
            swal.fire({
                title: t('MSG_MA_ALL_STOP'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else {
            swal.fire({
                title: t('MSG_MA_PROBLEM'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    return (
        <Observer>
            {() => (
            <div>
                <Row>
                    <Row>
                        <Col style={{ margin: '5px', padding: '0 20px', textAlign: 'right' }}>
                            <Button style={{ margin: '5px' }} onClick={() => onMachineAgentAllStart()}>{t('LAN_START')}</Button>
                            <Button style={{ margin: '5px' }} onClick={() => onMachineAgentAllStop()}>{t('LAN_STOP')}</Button>
                        </Col>
                    </Row>
                    <Row>
                        <Col className="scrollbar" style={{  maxHeight: '400px' }}>
                            <Table>
                                <thead>
                                    <tr>
                                        <th>{t('LAN_NO')}</th>
                                        <th>{t('LAN_EQUIPMENT_TYPE')}</th>
                                        <th>{t('LAN_EQUIPMENT_NAME')}</th>
                                        <th>{t('LAN_EQUIPMENT_PLC_TYPE')}</th>
                                        <th>{t('LAN_EQUIPMENT_PLC_ADDRESS')}</th>
                                        <th>{t('LAN_RUN_TYPE')}</th>
                                        <th>{t('LAN_RUN')}</th>
                                    </tr>
                                </thead>
                                <tbody ref={tableBodyRef}>
                                    {props.stores.equipmentList.map((item, index) =>
                                        <tr key={index + 1} id={item.EquipmentId} /*className={item.Enabled === true ? '' : 'table-active'} title={item.Enabled.toString()}*/ onClick={(e, index) => onRowClicked(e, item)} >
                                            <td>{index + 1}</td>
                                            <td>
                                                {item.EquipmentType}
                                            </td>
                                            <td>{item.EquipmentName}</td>
                                            <td>
                                                {item.EquipmentProtocolType}
                                            </td>
                                            <td>
                                                {item.PlcIp}
                                            </td>
                                            <td>
                                                <div style={{ display: 'inline-block' }}>
                                                    <MachineAgentRunTypeDropDown value={item.RunMode} isDisabled={!item.Enabled} onchange={(e) => { props.stores.onChangeMachineAgentMode(item.EquipmentId, e.target.value) }} />
                                                </div>

                                            </td>
                                            <td>
                                                <StartStopButton value={item.isRunning} isDisabled={!item.Enabled} onClick={(e) => { props.stores.changeRunningStatus(item.EquipmentId) }} />
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </Col>
                    </Row>
                </Row>
            </div>
            )}
        </Observer>
    );
}

export default MachineAgentListView;