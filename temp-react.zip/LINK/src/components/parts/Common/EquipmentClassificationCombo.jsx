import React from 'react';
import Form from 'react-bootstrap/Form'
import DropDownList from './DropDownList';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import { Observer } from 'mobx-react';
import useStore from '../../../stores/useStore';
import { AiFillCaretRight } from "react-icons/ai";
import Fetcher from './Fetcher';

function EquipmentClassificationCombo(props) {
    const [collections, setCollections] = useState([]);
    const [blocks, setBlocks] = useState([]);
    const [plcAddressInfos, setPlcAddressInfos] = useState([]);
    const [selectedEquipmentId, selectEquipmentId] = useState("001001");

    useEffect(() => {
        initialize();
    }, []);

    const initialize = async () => {
        let params = {
            equipment_id: selectedEquipmentId
        }
        
        let tmp = [];
        let collection_data = await Fetcher('post', '/httpAPI/getCollectionInfoByEquipmentId', params);
        if (collection_data !== false) {
            collection_data.map((item) => {
                tmp.push({
                    value: item.CollectionInfoId,
                    name: item.CollectionName
                });
            });
        }

        setCollections(tmp);
    }

    const onChangeCollection = async (e) => {
        setPlcAddressInfos([]);
        let params = {
            collection_info_id: e.target.value
        }

        let tmp = [];
        let block_data = await Fetcher('post', '/httpAPI/getBlockInfoByCollectionInfoId', params);
        if (block_data !== false) {
            block_data.map((item) => {
                tmp.push({
                    value: item.BlockInfoId,
                    name: item.BlockName
                });
            });
        }

        setBlocks(tmp);
    }

    const onChangeBlock = async (e) => {
        let params = {
            block_info_id: e.target.value
        }

        let tmp = [];
        let plc_address_data = await Fetcher('post', '/httpAPI/getPlcAddressInfoByBlockId', params);
        if (plc_address_data !== false) {
            plc_address_data.map((item) => {
                tmp.push({
                    value: item.PLCAddressInfoId,
                    name: item.ParameterName
                });
            });
        }

        setPlcAddressInfos(tmp);
    }


    return <Observer>
        {() => (
            <div class="equipment-classification">
                <select name="collection_info_id" onChange={onChangeCollection}>
                    <option value="0">전체</option>
                    { collections.map((option) => (
                        <option key={option.value} value={option.value}>{option.name}</option> 
                    ))}
                </select>
                { props.noIcon !== true && <AiFillCaretRight className="ico" /> }
                <select name='block_info_id' onChange={onChangeBlock}>
                    <option value="0">전체</option>
                    { blocks.map((option) => (
                        <option key={option.value} value={option.value}>{option.name}</option> 
                    ))}
                </select>
                { props.noIcon !== true && <AiFillCaretRight className="ico" /> }
                <select name="plc_address_info_id">
                    <option value="0">전체</option>
                    { plcAddressInfos.map((option) => (
                        <option key={option.value} value={option.value}>{option.name}</option> 
                    ))}
                </select>
            </div>
        )}
    </Observer>
}

export default EquipmentClassificationCombo