import axios from 'axios';

const Fetcher = async(method, url, ...rest) => {
    try {

        //for dev
        //const res = await axios[method]('http://localhost:3001'+url, ...rest);
        //for release
        const res = await axios[method](url, ...rest);
        //token refresh case
        if(res.headers.authorization){
            let token = res.headers.authorization.split(' ');
            axios.defaults.headers.common['Authorization'] = 'Bearer' + ' ' + token[1];
            let sessionStorage = window.sessionStorage;
            sessionStorage.setItem('authorizeToken', token[1]);
        }
        
        return res.data;    
    } catch (e) {
        console.log(e.message);
        return Promise.reject(e);
    }
};


export default Fetcher;