import { Observer } from 'mobx-react';
import React from "react";

function TextArea({...props}, ref) {
    return (
        <Observer>
            {() => (
                <textarea
                    ref={ref}
                    rows= {props.row}
                    style={{ resize: props.resize, width: props.width, height: props.height }}
                    //value={props.textValue}
                    onChange={(e) => props.onChange(e)}
                    readOnly
                ></textarea>
            )}
        </Observer>
    );
}

export default React.forwardRef(TextArea);