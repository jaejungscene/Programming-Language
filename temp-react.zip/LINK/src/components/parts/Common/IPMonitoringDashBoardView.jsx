
import { useTranslation } from 'react-i18next';
import React, { useEffect, useState, useRef } from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Checkbox from './Common/Checkbox';
import useStore from '../../stores/useStore';
import NewCoaterLayout from './NewCoaterLayout';
import { Observer } from 'mobx-react';
import { useObserver } from 'mobx-react';
import DashBoardHeader from './Common/DashBoardHeader';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { TbDeviceDesktopAnalytics } from "react-icons/tb";
import { AiOutlineLineChart } from "react-icons/ai"
import DashBoardRealTimeChart from './Common/DashBoardRealTimeChart';
import ToastContainer from 'react-bootstrap/ToastContainer';
import Toast from 'react-bootstrap/Toast';
import SixChartMatrix from './SixChartMatrix'


function IPMonitoringDashBoardView(props) {

    const navigate = useNavigate();
    const { dashBoardStore } = useStore();
    const { mainViewStore } = useStore();    
    const { alertHistoryStore } = useStore();
    const { t } = useTranslation();
    const [dashboardInitialize, setDashboardInitialize] = useState(null);
    const errorText = useRef();
    const [equipmentChanged, setEquipmentChanged] = useOutletContext().equipmentChanged;
    const sessionStorage = window.sessionStorage;    
    const [isLoading, setIsLoading] = useState(false);
    const [modalShow, setModalShow] = useState(false);


    useEffect(() => {
        dashInitialize();

    }, [dashBoardStore, errorText
    ]);

    const dashInitialize = async () => {
        if (!dashBoardStore.webSocket)
            //await dashBoardStore.initialize(mainViewStore.webSocket);
            await dashBoardStore.initialize(mainViewStore.getWebsocket());
        setDashboardInitialize(true);
        dashBoardStore.errorList = [];
    };

    function coaterImageClick(e) {
        handleShowAlertHistory(e);
    }

    async function handleShowAlertHistory(e) {        
        /*
        setIsLoading(true);
        alertHistoryStore.selectedModule = e;
        alertHistoryStore.modalOpenTime = new Date();
        await alertHistoryStore.getNoneCheckedAlertListByPLCAddressId(e);
        setModalShow(true);
        setIsLoading(false);
        */
    }

    async function handleCloseAlertHistory() {
        await alertHistoryStore.updateCheckedAlarmListByModuleId();
        setModalShow(false);        
        await alertHistoryStore.initAlertList();
    }

    function toNavigate(route) {
        sessionStorage.setItem('sidebarToggle', true);
        navigate(route);
    }

    function closeToast(id) {
        const findIndex = dashBoardStore.errorList.findIndex(element => element.id == id);
        dashBoardStore.errorList.splice(findIndex, 1);
    }

    function onTrendChartShow() {        
        navigate('/dashboard2');
    }



    return useObserver(() => (
        <Observer>
            {() => (
                <div style={{ margin: '5px', backgroundColor: 'white' }}>
                    {/*<Row style={{ margin: "10px" }}>
                        <Col>
                            <TextArea ref={errorText} defaultValue={''} width={'1660px'} height={'120px'} resize={'none'} row={'5'} />
                        </Col>
                    </Row> */ }

                    {
                    <>
                        {dashboardInitialize && <ToastContainer className="p-3" position={'top-end'} style={{ zIndex: '1', marginTop : '50px'}}>
                        {dashBoardStore.errorList.map((data) => {
                            if (!data) {
                                return null;
                            }
                            return (
                                <Toast
                                    key={data.id}
                                    autohide={true}
                                    delay={3000}
                                    animation = {true}
                                    onClose={() => {
                                        closeToast(data.id);
                                    }}
                                >
                                    <Toast.Header closeButton={true}>
                                        <strong className="me-auto">{data.moduleType}</strong>
                                        <small>{data.name}</small>
                                    </Toast.Header>
                                    <Toast.Body>{t("LAN_OUT_OF_THRESHOLD")}</Toast.Body>
                                </Toast>
                            );
                        })}
                        </ToastContainer>
                        }
                    </>
                    }

                    <Row>
                        <Col sm={2}>
                            <div style={{ width: '280px', lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft: "30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '5px 5px 0px 0px', margin: '5px 15px 0 22px' }}>
                                <TbDeviceDesktopAnalytics style={{ marginTop: '-5px' }} />
                                &nbsp;&nbsp;&nbsp;{t('LAN_WORKING_INFO')}
                            </div>
                        </Col>

                        <Col sm={8}></Col>

                        <Col sm={2} style={{ display: 'flex', verticalAlign: 'center' }}>
                            <div style={{ marginTop: '5px' }}>
                                <Row>
                                    <Col sm={2}>
                                        <Checkbox onChange={() => { onTrendChartShow() }} />
                                    </Col>
                                    <Col sm={10}>
                                        {t('LAN_SHOW_TREND_CHART')}
                                    </Col>
                                </Row>
                            </div>

                        </Col>

                    </Row>

                    <Row style={{ margin: '0px 10px 0 10px', position: 'relative', zIndex: '0' }}>
                        <Col>
                            <DashBoardHeader
                                title={[t('LAN_TABLE_RECIPE_ID'), t('LAN_START_TIME'), t('LAN_PRODUCT_TIME'), t('LAN_PRODUCT_DISTANCE'), t('LAN_PRODUCT_SPEED')]}
                                viewData={dashBoardStore.dashBoardHeaderData}
                            >
                            </DashBoardHeader>
                        </Col>
                    </Row>                    
                        
                    <Row style={{ margin: "10px 10px 0px 30px" }}>
                        <Col sm={1}></Col>
                        <Col sm={10}>
                            <NewCoaterLayout onClick={(e) => coaterImageClick(e)} />
                        </Col>
                        <Col sm={1}></Col>
                    </Row>
                    
                    
                    <SixChartMatrix />
          
                                        
                </div>
            )}
        </Observer>
    ));

}

export default IPMonitoringDashBoardView;