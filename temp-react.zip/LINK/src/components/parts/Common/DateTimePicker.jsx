import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Form from 'react-bootstrap/Form';
import { useTranslation } from 'react-i18next';
import {useState} from 'react';
import Stack from 'react-bootstrap/Stack'
import {subDays} from 'date-fns'
import styled from 'styled-components';

const DateTimePicker = (props) => {
    const [t] = useTranslation();
    const [startDate, setStartDate] = useState(props.from);
    const [endDate, setEndDate] = useState(props.to);
    const [minDate, setMinDate] = useState(props.minDate);

    const handleOnChange = (type, date) =>{
        if (type == 'from') {
            props.onChangeDate('from', date);
            setStartDate(date);
        }
        else {
            props.onChangeDate('to', date);
            setEndDate(date);
        }
    }

    return (
        <div className={props.className + " horisontal"}>
            <Stack direction="horizontal" gap={4}>
                <Form.Label className="form-label">{t("LAN_FROM")}</Form.Label>
                <CustomDatePikcer 
                    id='dateFrom'
                    selected={startDate} 
                    onChange={(date) => handleOnChange('from', date)}
                    dateFormat='yyyy-MM-dd' 
                    minDate={typeof minDate != "object" ? subDays(new Date(), 90) : minDate}
                    maxDate={endDate}
                />
                <div className='vr'></div>
                <Form.Label className="form-label">{t("LAN_TO")}</Form.Label>
                <CustomDatePikcer
                    id='dateTo' 
                    selected={endDate} 
                    onChange={(date) => handleOnChange('to', date)}
                    dateFormat='yyyy-MM-dd' 
                    className='custom-date-picker'
                    minDate={startDate}
                    maxDate={new Date()}
                />
            </Stack>
        </div>
    );
}

const CustomDatePikcer = styled(DatePicker)`
    width: 260px;
    height: 38px;
    box-sizing: border-box;
    padding: 8px 20px;
    border-radius: 5px;
    border: 1px solid lightGray;
`;

export default DateTimePicker;