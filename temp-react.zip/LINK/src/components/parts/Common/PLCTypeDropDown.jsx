
import Form from 'react-bootstrap/Form';
import { Observer } from 'mobx-react';



function PLCTypeDropDown(props) {

    const onchange = (e) => {
        props.onChange(e);
    }

    return (
        <Observer>
            {() => (
                 // 0: Mitubishi, 1: siemens, 2: Omron ...
                <Form.Select size="sm" style={{ width: '200px' }} value={props.value} onChange={onchange}>
                    <option value="0">Mitubishi</option>
                    <option value="1">Siemens</option>
                    <option value="2">Omron</option>
                </Form.Select>
            )}
        </Observer>
    );
}

export default PLCTypeDropDown;