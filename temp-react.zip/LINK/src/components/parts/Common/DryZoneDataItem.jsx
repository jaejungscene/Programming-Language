import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Toast from 'react-bootstrap/Toast';
import ToastContainer from 'react-bootstrap/ToastContainer';
import InputGroup from 'react-bootstrap/InputGroup';
import Form from 'react-bootstrap/Form';

function isError(color) {
    if (color === 'Black') {
        return false;
    } else {
        return true;
    }
}


function DryZoneDataItem(props) {

    return (
        <Observer>
            {() => (
                <div
                    aria-live="polite"
                    aria-atomic="true"
                    style={{ minHeight: '200px' }}
                >
                    <ToastContainer className="p-3" style={{margin : '0 auto'}}>
                        <Toast style={{ width: '356px' }}>
                            <Toast.Header onClick={props.onClick} closeButton={false} style={{ fontSize: '1.1em', color: 'white', backgroundColor: 'rgb(52,58,64)'}}>
                                <label className="me-auto" style={{ cursor: 'pointer' }}>{props.defaultTitle}</label>
                                <small>{props.viewData.moduleName === undefined ? '' : props.viewData.moduleName}</small>
                            </Toast.Header>

                            <Toast.Body>
                                <Row xs="auto">
                                    <Col style={{ fontSize: '13px', color: 'gray' }}>
                                        {props.title[0]}(Rpm)
                                    </Col>
                                </Row>
                                <Row xs="auto">
                                    <Col style={{ marginTop: '5px' }}>
                                        <InputGroup className="dryzone-margin-bottom">
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>{props.inputTitle[1]}1</InputGroup.Text>
                                            {isError(props.viewData.label1Color) ?
                                                (
                                                    <Form.Control style={{ color: props.viewData.label1Color, fontWeight : 'bold', backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label1 === undefined ? ' ' : (props.viewData.label1 < 0 ? '-' : props.viewData.label1)} disabled/>
                                                ) : 
                                                (
                                                    <Form.Control style={{ color: props.viewData.label1Color, backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label1 === undefined ? ' ' : (props.viewData.label1 < 0 ? '-' : props.viewData.label1)} disabled/>
                                                )
                                            }
                                            
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>{props.inputTitle[1]}2</InputGroup.Text>
                                            {isError(props.viewData.label2Color) ?
                                                (
                                                    <Form.Control style={{ color: props.viewData.label2Color, fontWeight : 'bold', backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label2 === undefined ? ' ' : (props.viewData.label2 < 0 ? '-' : props.viewData.label2)} disabled/>
                                                ) : 
                                                (
                                                    <Form.Control style={{ color: props.viewData.label2Color, backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label2 === undefined ? ' ' : (props.viewData.label2 < 0 ? '-' : props.viewData.label2)} disabled/>
                                                )
                                            }
                                        </InputGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col>
                                        <InputGroup className="dryzone-margin-bottom">
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>{props.inputTitle[0]}&nbsp;</InputGroup.Text>
                                            {isError(props.viewData.labelColor) ?
                                                (
                                                    <Form.Control style={{ color: props.viewData.labelColor, fontWeight : 'bold', backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label === undefined ? ' ' : (props.viewData.label < 0 ? '-' : props.viewData.label)} disabled/>
                                                ) : 
                                                (
                                                    <Form.Control style={{ color: props.viewData.labelColor, backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label === undefined ? ' ' : (props.viewData.label < 0 ? '-' : props.viewData.label)} disabled/>
                                                )
                                            }
                                        </InputGroup>
                                    </Col>
                                </Row>
                                <Row xs="auto">
                                    <Col style={{ fontSize: '13px', color: 'gray' }}>
                                        {props.title[1]}(A)
                                    </Col>
                                </Row>
                                <Row xs="auto">
                                    <Col style={{ marginTop: '5px' }}>
                                        <InputGroup className="dryzone-margin-bottom">
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>{props.inputTitle[1]}1</InputGroup.Text>
                                            <Form.Control
                                                style={{ backgroundColor : 'white' }}
                                                placeholder="A"
                                                value={props.viewData.label4 === undefined ? '' : (props.viewData.label4 < 0 ? '-' : props.viewData.label4)}
                                                disabled
                                            />
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>{props.inputTitle[1]}2</InputGroup.Text>
                                            <Form.Control
                                                style={{ backgroundColor : 'white' }}
                                                placeholder="A"
                                                value={props.viewData.label5 === undefined ? '' : (props.viewData.label5 < 0 ? '-' : props.viewData.label5)}
                                                disabled
                                            />
                                        </InputGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col>
                                        <InputGroup className="dryzone-margin-bottom">
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>{props.inputTitle[0]}&nbsp;</InputGroup.Text>
                                            <Form.Control
                                                style={{ backgroundColor : 'white' }}
                                                placeholder="A"
                                                value={props.viewData.label3 === undefined ? '' : (props.viewData.label3 < 0 ? '-' : props.viewData.label3)}
                                                disabled
                                            />
                                        </InputGroup>
                                    </Col>
                                </Row>
                                <Row xs="auto">
                                    <Col style={{ fontSize: '13px', color: 'gray' }}>
                                        {props.title[2]}(Kpa)
                                    </Col>
                                </Row>
                                <Row>
                                    <Col style={{ marginTop: '5px' }}>
                                        <InputGroup className="dryzone-margin-bottom">
                                            <InputGroup.Text id="basic-addon1" style={{ fontSize: '13px' }}>&nbsp;&nbsp;{props.inputTitle[2]}&nbsp;&nbsp;</InputGroup.Text>
                                            {isError(props.viewData.label6Color) ?
                                                (
                                                    <Form.Control style={{ color: props.viewData.label6Color, fontWeight : 'bold', backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label6 === undefined ? ' ' : (props.viewData.label6 < 0 ? '-' : props.viewData.label6)} disabled/>
                                                ) : 
                                                (
                                                    <Form.Control style={{ color: props.viewData.label6Color, backgroundColor : 'white' }} placeholder="Rpm" value={props.viewData.label6 === undefined ? ' ' : (props.viewData.label6 < 0 ? '-' : props.viewData.label6)} disabled/>
                                                )
                                            }
                                        </InputGroup>
                                    </Col>
                                </Row>
                            </Toast.Body>
                        </Toast>
                    </ToastContainer>
                </div>
            )}
        </Observer>
    )
}

export default DryZoneDataItem;