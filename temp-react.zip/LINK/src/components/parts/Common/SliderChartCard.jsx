import { Observer } from 'mobx-react';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import Carousel from 'react-bootstrap/Carousel';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleLeft } from '@fortawesome/free-solid-svg-icons';
import { faCircleRight } from '@fortawesome/free-solid-svg-icons';
import LineChart from './Chart/LineChart';


function SliderChartCard(props) {
    return (
        <Observer>
            {() => (
                <Card>
                    <Card.Header onClick={props.onClick}>{props.title}</Card.Header>
                    <Card.Body>
                        <div>
                            {props.dataType}
                        </div>
                        <div>
                            <Carousel
                                variant='dark'
                                interval={props.interval}
                                indicators={false}
                                prevIcon={<FontAwesomeIcon color='black' size='2x' icon={faCircleLeft} />}
                                nextIcon={<FontAwesomeIcon color='black' size='2x' icon={faCircleRight} />}
                            >
                                {props.viewData.map((data) => {
                                    return (
                                        <Carousel.Item>
                                            <h3 style={{ color: data.labelColor, textAlign: 'center' }}>
                                                {data.label}
                                            </h3>
                                            <div>
                                                <LineChart options={new Object(data.chart)} width={props.width === undefined? '360px' : props.width} height='110px' gridHeight='130px'></LineChart>
                                            </div>
                                        </Carousel.Item>
                                    )
                                })}
                            </Carousel>
                        </div>
                    </Card.Body>
                </Card>
            )}
        </Observer>
    )
}

export default SliderChartCard;