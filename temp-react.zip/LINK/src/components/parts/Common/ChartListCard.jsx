import { useTranslation } from 'react-i18next';
import React, { useEffect, useState, useRef } from 'react';
import Card from 'react-bootstrap/Card';
import LineChartForTime from './Chart/LineChartForTime';
import { Observer } from 'mobx-react';
import { IoMdArrowRoundUp, IoMdArrowRoundDown } from "react-icons/io";

function ChartListCard (props) {
    let maxWidth = props.width | 760;
    const { t } = useTranslation();

    return (
        <Observer>
        {() => (
            <Card className="dark-card graph-list-card" id={props.id}>
                <Card.Header>
                    {props.title}
                </Card.Header>

                <Card.Body className="graph-list scrollbar">
                    {
                        props.viewData && 
                        Object.keys(props.viewData).map((key) => {
                            let block = props.viewData[key];

                            return <div>
                            {
                                block.map((item) => (
                                    <div>
                                        <div class="graph-list-title">
                                            <div>
                                                {
                                                    item.IsFlexibleIp === true &&
                                                    props.visibleIp === true &&
                                                    <span>
                                                        [{t("LAN_FLEXIBLE_IP")}] 
                                                        &nbsp;
                                                    </span>
                                                }
                                                {item.ParameterName}
                                            </div>
                                            <div class="graph-list-value">
                                                <span>
                                                    {t("LAN_VALUE")} 
                                                    &nbsp;
                                                    <b>{item.dataArray.length > 0 ? item.dataArray[item.dataArray.length - 1][0].value : 0}</b>
                                                </span>
                                            </div>
                                        </div>

                                        <LineChartForTime 
                                            width={maxWidth/block.length} 
                                            height={140} 
                                            name={item.ParameterName} 
                                            viewData={item.dataArray} 
                                            splitX={4/block.length} 
                                            upperThreshold={item.UpperErrorThreshold}
                                            lowerThreshold={item.LowerErrorThreshold}
                                            />
                                    </div>
                                ))
                            }
                            </div>
                        })
                    }
                    {
                        props.fixedIpData &&
                        props.fixedIpData.map((item) => {
                            let settingValue = 0;
                            let value = 0;

                            if (item.dataArray.length > 0) {
                                item.dataArray[item.dataArray.length - 1].map((lastItem) => {
                                    if (lastItem.name === "value") {
                                        value = lastItem.value;
                                    }
                                    if (lastItem.name === "setting value") {
                                        settingValue = lastItem.value;
                                    }
                                });
                            }

                            return <div>
                                <div>
                                    <div class="graph-list-title">
                                        <div>[{t("LAN_FIXED_IP")}] {item.fixed_ip_info_name}</div>
                                        {
                                            item.dataArray.length > 0 &&
                                            <div class="graph-list-value">
                                                <span>
                                                    {t("LAN_SETTING_VALUE")} <b>{settingValue.toFixed(2)}</b>
                                                </span>

                                                <span>
                                                    {t("LAN_PROCESS_VALUE")} <b>{value.toFixed(2)}</b>
                                                </span>

                                                <span>
                                                    {t("LAN_DEVIATION")} 
                                                    
                                                    <b>
                                                        {
                                                            value === settingValue ? "" :
                                                            value > settingValue ? <IoMdArrowRoundUp className="text red" /> : <IoMdArrowRoundDown className="text blue" />
                                                        }
                                                        &nbsp;
                                                        {(value - settingValue).toFixed(2)}
                                                    </b>
                                                </span>
                                                
                                            </div>
                                        }
                                    </div>

                                    <LineChartForTime width={maxWidth} height={140} name={item.ParameterName} viewData={item.dataArray} splitX={4/props.fixedIpData.length} />
                                </div>
                            </div>
                        })
                    }

                </Card.Body>
            </Card>
        )}
        </Observer>
    )
}


export default ChartListCard