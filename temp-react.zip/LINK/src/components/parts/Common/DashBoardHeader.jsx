import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Form from 'react-bootstrap/Form';
import Switch from './Switch';
import ModuleIcons from './ModuleIcons';
import { IoIosInformationCircle } from "react-icons/io";
import { FaPlay, FaStop } from "react-icons/fa";
import React, { useEffect, useState, useRef } from "react";
import { useTranslation } from 'react-i18next';


function DashBoardHeader(props) {
    const [selectType, setSelectType] = useState(props.selectedType !== "text" ? true : false);
    const [selectAuto, setSelectAuto] = useState(props.selectedAuto !== true ? true : false);
    const [selectModule, setSelectModule] = useState([0,1]);
    const { t } = useTranslation();

    useEffect(() => {
        setSelectModule(Array.from({ length: props.process.length }, (_, index) => index));
    }, [props.process]);

    useEffect(() => {
        if (selectType === true && props.onChangeType) {
            props.onChangeType("graph");
        }
        else if (selectType === false && props.onChangeType) {
            props.onChangeType("text");
        }
    },[selectType]);

    useEffect(() => {
        if (typeof props.onChangeModule !== "undefined")  {
            props.onChangeModule(selectModule);
        }
    }, [selectModule]);

    useEffect(() => {
        if (typeof props.onChangeAuto !== "undefined") {
            props.onChangeAuto(selectAuto);
        }
    }, [selectAuto])

    const clickModule = (index, selected) => {
        setSelectModule((prevState) => {
            if (selected === true) {
                prevState = prevState.filter(item => item !== index);
            }
            else {
                prevState.push(index);
            }
            prevState.sort();

            return [...prevState];
        });
    }

    return (
        <Observer>
            {() => (
                <div class="dashboard-header">
                    <div class="dashboard-title">
                        <div class="title-card">
                            <IoIosInformationCircle />
                            &nbsp;
                            {t('LAN_WORKING_INFO')}

                            {
                                props.viewData.isRunning === true ?
                                <span class="title-status running">
                                    <FaPlay />
                                    &nbsp;
                                    {t('LAN_RUNNING')}
                                </span>
                                :
                                <span class="title-status stop">
                                    <FaStop />
                                    &nbsp;
                                    {t('LAN_STOPPING')}
                                </span>
                            }
                        </div>

                        {
                            typeof props.selectedType !== "undefined" &&
                            <div class="common-form flex-form">
                                {
                                    selectType === true &&
                                    <div class="common-form flex-form">
                                        <Switch value={selectAuto} onChange={() => setSelectAuto(!selectAuto)} id="select_auto_mode" />  
                                        <span onClick={() => setSelectAuto(!selectAuto)}>
                                            {t("LAN_AUTO_SLIDE")}
                                        </span>
                                        &nbsp;&nbsp;&nbsp;
                                    </div>
                                }

                                <input 
                                    id="select_type_text"
                                    type="radio" 
                                    name="selectType" 
                                    checked={selectType === false} 
                                    onChange={() => setSelectType(!selectType)} />
                                <label for="select_type_text">
                                    {t("LAN_TEXT")}
                                </label>

                                <input 
                                    id="select_type_graph"
                                    type="radio" 
                                    name="selectType" 
                                    checked={selectType === true} 
                                    onChange={() => setSelectType(!selectType)} />
                                <label for="select_type_graph">
                                {t("LAN_GRAPH")}
                                </label>
                            </div>
                        }
                        {
                            typeof props.selectedType === "undefined" &&
                            selectType === true &&
                            <div class="common-form flex-form">
                                <Switch value={selectAuto} onChange={() => setSelectAuto(!selectAuto)} />  
                                {t("LAN_AUTO_SLIDE")}
                                &nbsp;&nbsp;&nbsp;
                            </div>
                        }
                    </div>
                    <Card>
                        <Card.Body>
                            <div class="common-form flex-form space-between">
                                <span class="label">
                                    {props.title[0]}
                                </span>
                                <Form.Control style={{ width: '200px' }} type="text" value={props.viewData.recipeId === undefined ? '-' : props.viewData.recipeId} readOnly />
                                <span class="null"></span>

                                <span class="label">
                                    {props.title[1]}
                                </span>
                                <Form.Control style={{ width: '200px' }} type="text" value={props.viewData.distance === undefined ? '-' : props.viewData.batchId} readOnly />
                                
                                <span class="null"></span>
                            
                                <span class="label">
                                    {props.title[2]}
                                </span>
                                <Form.Control style={{ width: '120px' }} type="text" value={props.viewData.startTime === undefined ? '-' : props.viewData.startTime} readOnly />
                                <span class="null"></span>

                                <span class="label">
                                    {props.title[3]}
                                </span>
                                
                                <Form.Control style={{ width: '120px' }} type="text" value={props.viewData.workingTime === undefined ? '-' : props.viewData.workingTime} readOnly />
                                <span class="null"></span>

                                <span class="label">
                                    {props.title[4]}
                                </span>
                                <Form.Control style={{ width: '120px' }} type="text" value={props.viewData.lineSpeed === undefined ? '-' : props.viewData.lineSpeed + 'm/min'} readOnly />
                            </div>
                        </Card.Body>
                    </Card>


                    <div class="dashboard-header-cards">
                        {
                            props.selectedType !== "text" &&
                            props.process &&
                            props.process.map((item, index) =>
                                <div onClick={(e) => clickModule(index, selectModule.includes(index))} class={selectModule.includes(index) ? "active" : ""}>
                                    {
                                        <ModuleIcons type={item.CollectionInfoId} />
                                    }
                                    <div>{item.CollectionName}</div>
                                </div>
                            )
                        }
                    </div>
                </div>
            )}
        </Observer>
    )
}

export default DashBoardHeader;