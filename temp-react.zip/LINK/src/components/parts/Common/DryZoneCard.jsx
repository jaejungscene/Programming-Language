import { useTranslation } from 'react-i18next';
import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Carousel from 'react-bootstrap/Carousel';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Badge from 'react-bootstrap/Badge';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import styled, { keyframes } from 'styled-components';
import DashBoardRealTimeChart from './DashBoardRealTimeChart';
import BlockRealTimeCard from './BlockRealTimeCard';

function isError(color) {
    if (color === 'Black') {
        return false;
    } else {
        return true;
    }
}

const styles = {
    badge: {
        float: 'right',
        fontSize: '0.9rem',
        cursor: 'pointer'
    }
};

function DryZoneCard(props) {
    const { t } = useTranslation();

    return (
        <Observer>
            {() => (
                <Carousel
                    variant="dark"
                    indicators={false}
                    prevIcon={<FontAwesomeIcon color='black' size='1x' icon={faChevronLeft} />}
                    nextIcon={<FontAwesomeIcon color='black' size='1x' icon={faChevronRight} />}
                    interval={10000}
                >
                    {Object.entries(props.viewInfo).map(([key, info], index) => {
                        return (
                            <Carousel.Item
                                aria-live="polite"
                                aria-atomic="true"
                                interval={props.interval}
                                style={{ minHeight: '130px', paddingLeft: '7px', paddingRight: '7px' }}
                            >

                                <Card style={{ height: props.height }}>
                                    <Card.Header>
                                        <strong className="me-auto" style={{ whiteSpace: 'nowrap' }}>{key}</strong>
                                        {/*<Badge bg="secondary" style={styles.badge}>{key}</Badge>*/}
                                    </Card.Header>

                                    <Card.Body>
                                        
                                        <Stack direction='vertical' gap={1}>
                                            {Object.entries(info).map(([blkKey, blkInfo], blkIndex) => {
                                                let data = [] 
                                                if (blkKey in props.viewData) {
                                                    data = props.viewData[blkKey];
                                                }
                                                return (
                                                    <Row className="dry-data-cards">
                                                        <BlockRealTimeCard viewInfo={blkInfo} viewData={data} height={'790px'} />
                                                    </Row>
                                                );
                                            })}
                                      
                                        </Stack>

                                    </Card.Body>
                                </Card>
                            </Carousel.Item>
                        )
                    })}
                </Carousel>
            )}
        </Observer>
    )
}

export default DryZoneCard;