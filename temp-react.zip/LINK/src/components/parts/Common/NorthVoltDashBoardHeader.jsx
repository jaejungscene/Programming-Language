import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Form from 'react-bootstrap/Form';
import { TbDeviceDesktopAnalytics } from "react-icons/tb"



const coatingQualityStyle = {
    color: 'white',
    fontSize: '1.2em',
    verticalAlign: 'center',
    textAlign: 'center',
    borderRight: "2px solid white", marginTop: "0px"
}

const coatingQualityDataStyle = {
    color: '#ABF200',
    fontSize: '1.2em',
    verticalAlign: 'center',
    textAlign: 'center',
    borderRight: "2px solid white", marginTop: "0px"
}


function NorthVoltDashBoardHeader(props) {

    return (
        <Observer>
            {() => (

                <Card style={{ height: '130px', maxHeight: '150px', width: '1650px' }}>
                    <Card.Body style={{ paddingTop: '10px' }}>
                        <Stack direction="vertical" gap={4}>
                            <Row>
                                <Col>
                                    <div style={{ lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft:"30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '16px', margin: '0 15px 0 17px' }}>
                                        <TbDeviceDesktopAnalytics style={{ marginTop: '-5px' }} />
                                        &nbsp;&nbsp;&nbsp;{props.title[0]}
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '120px', textAlign: 'right' }}>{props.title[2]}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '10px' }}>
                                        <Form.Control style={{ width: '160px' }} type="text" value={props.viewData.batchId === undefined ? '-' : props.viewData.batchId} readOnly />
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '120px', textAlign: 'right' }}>{props.title[3]}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '10px' }}>
                                        <Form.Control style={{ width: '170px' }} type="text" value={props.viewData.recipeId === undefined ? '-' : props.viewData.recipeId} readOnly />
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '110px', textAlign: 'right' }}>{props.title[4]}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '10px' }}>
                                        <Form.Control style={{ width: '180px' }} type="text" value={props.viewData.startDate === undefined ? '-' : props.viewData.startDate} readOnly />
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '126px', textAlign: 'right' }}>{props.title[5]}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '8px' }}>
                                        <Form.Control style={{ width: '170px' }} type="text" value={props.viewData.productTime === undefined ? '-' : props.viewData.productTime} readOnly />
                                    </div>
                                </Col>
                            </Row>


                            <Row>
                                <Col>
                                    <div style={{ lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft:"30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '16px', margin: '0 15px 0 17px' }}>
                                        <TbDeviceDesktopAnalytics style={{ marginTop: '-5px' }} />
                                        &nbsp;&nbsp;&nbsp;{props.title[1]}
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '120px', textAlign: 'right' }}>{props.title[6]}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '10px' }}>
                                        <Form.Control style={{ width: '160px', height: '35px' }} type="text" value={props.viewData.coatingLengthAvg === undefined ? '-' : (props.viewData.coatingLengthAvg < 0 ? '-' : props.viewData.coatingLengthAvg.toFixed(2) + 'mm')} readOnly />
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '120px', textAlign: 'right' }}>{props.title[7]}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '10px' }}>
                                        <Form.Control style={{ width: '170px' }} type="text" value={props.viewData.nonCoatingLengthAvg === undefined ? '-' : (props.viewData.nonCoatingLengthAvg < 0 ? '-' : props.viewData.nonCoatingLengthAvg.toFixed(2) + 'mm')} readOnly />
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '110px', textAlign: 'right' }}>Cp</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '10px' }}>
                                        <Form.Control style={{ width: '180px' }} type="text" value={props.viewData.cp === undefined ? '-' : props.viewData.cp.toFixed(2)} readOnly />
                                    </div>
                                </Col>
                                <Col style={{paddingTop:"5px"}}>
                                    <div style={{ float: 'left', paddingTop:"3px" }}>
                                        <h5 style={{ width: '126px', textAlign: 'right' }}>Cpk</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '8px' }}>
                                        <Form.Control style={{ width: '170px' }} type="text" value={props.viewData.cpk === undefined ? '-' : props.viewData.cpk.toFixed(2)} readOnly />
                                    </div>
                                </Col>
                            </Row>

                        </Stack>                        

                    </Card.Body>
                </Card>
            )}

        </Observer>
    )
}

export default NorthVoltDashBoardHeader;