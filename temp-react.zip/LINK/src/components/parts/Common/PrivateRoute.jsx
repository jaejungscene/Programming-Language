import { useEffect } from "react";
import { useNavigate } from 'react-router-dom';



const PrivateRoute = ({ store, children, temp }) => {
    //login 기능 disabled
    //return children;
    console.log("privateroute");
    console.log(store, children, temp);
    const navigate = useNavigate(); 

    useEffect(() => {
        if (store.loginUser === undefined) {
            navigate('/login', {replace:true});
            return;
        }
    }, []);

    return children;
};


export default PrivateRoute;