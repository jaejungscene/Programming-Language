import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import { useState, useEffect } from 'react';
import { useObserver } from 'mobx-react';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import Badge from 'react-bootstrap/Badge';
import LineChart from './Chart/LineChart';

const styles = styled.div`
${``}
height: 370px;
overflow-y: scroll;
`

function MainFactorCard(props) {
    const { t } = useTranslation();    

    const styles = {
        badge: {
            float: 'right',
            fontSize: '0.9rem',
            cursor: 'pointer'
        }
    };


    return useObserver(() => (        
            <Row style={{ padding : '10px', fontWeight : 'bold' }}>
                <div>
                    <Card style={{ height: '350px', overflowY: 'auto' }}>
                        <Card.Header>{t("LAN_MAIN_FACTOR")}</Card.Header>
                            <Card.Body>
                                
                            </Card.Body>
                    </Card>
                </div>
            </Row>        
    ));
}

export default MainFactorCard;