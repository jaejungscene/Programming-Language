import React, { useEffect, useState } from 'react';
import { FaScroll, FaSocks, FaSprayCan } from "react-icons/fa";
import { FiWind } from "react-icons/fi";
import { MdOutlineCompress, MdOutlineRedo, MdOutlineUndo } from "react-icons/md";
import { IoMdExit } from "react-icons/io";

function ModuleIcons(props) {
    let iconType = "";
    useEffect(() => {

    }, []);

    switch (props.type) {
        case "UNWINDER":
        case "COATER":
        case "VACUUMROLL":
        case "OUTFEED":
        case "REWINDER":
            iconType = props.type
        break;

        case "DRYER_1ZONE":
        case "DRYER_2ZONE":
        case "DRYER_3ZONE":
        case "DRYER_4ZONE":
            iconType = "DRYER"
        break;
    }


    return (
        <div class="module-icons">
            {
                iconType === "UNWINDER" ? 
                    <span class="winder">
                        <MdOutlineRedo />
                        <FaScroll />
                    </span>
                : iconType === "COATER" ?
                    <span>
                        <FaSprayCan />
                    </span>
                : iconType === "DRYER" ?
                    <span>
                        <FiWind  />
                    </span>
                : iconType === "VACUUMROLL" ?
                    <span>
                        <MdOutlineCompress />
                    </span>
                : iconType === "OUTFEED" ?
                    <span>
                        <IoMdExit />
                    </span>
                : iconType === "REWINDER" ? 
                    <span class="winder">
                        <MdOutlineRedo />
                        <FaScroll className="flip" />
                    </span>
                : ""
            }
        </div>
    );
}

export default ModuleIcons;