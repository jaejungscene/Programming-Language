import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlayCircle } from '@fortawesome/free-solid-svg-icons'
import { faStopCircle } from '@fortawesome/free-solid-svg-icons'

function StartStopButton(props) {
    function onClick(e){
        if(!props.isDisabled){
            props.onClick(e);
        }
    }

    if (props.value === false) {
        return (
            <>
                <FontAwesomeIcon color='green' size='2x' icon={faPlayCircle} onClick={(e) => {onClick(e)}} />
            </>
        );
    }

    return (
        <>
            <FontAwesomeIcon color='red' size='2x' icon={faStopCircle} onClick={(e) => {onClick(e)}} />
        </>
    );
    
}

export default StartStopButton;