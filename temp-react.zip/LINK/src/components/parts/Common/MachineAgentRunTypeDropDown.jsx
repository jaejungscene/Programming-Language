
import Form from 'react-bootstrap/Form';
import { Observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';

function MachineAgentRunTypeDropDown(props) {

    const { t } = useTranslation();

    const onchange = (e) => {
        props.onchange(e);
    }

    return (
        <Observer>
            {() => (
                <Form.Select size="sm" style={{ width: '200px' }} value={props.value} onChange={onchange} disabled={props.isDisabled}>
                    <option value="0">{t('LAN_SIMULATION_MODE')}</option>
                    <option value="1">{t('LAN_ACTUAL_MODE')}</option>
                </Form.Select>
            )}
        </Observer>
    );
}

export default MachineAgentRunTypeDropDown;