import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import { useTranslation } from 'react-i18next';
import { TbDeviceDesktopAnalytics } from "react-icons/tb";
import React, { useEffect, useState, useRef } from "react";
import BlockRealTimeCard from './BlockRealTimeCard';


function CoatingQualityCard(props) {
    const { t } = useTranslation();
    return (
        <div>
            <div>
                <div style={{ width: '280px', lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft: "30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '5px 5px 0px 0px', margin: '10px 15px 0 35px' }}>
                    <TbDeviceDesktopAnalytics style={{ marginTop: '-5px' }} />
                    &nbsp;&nbsp;&nbsp;{t('LAN_COATING_QUALITY_INFO')}
                </div>
            </div>


            <div style={{ margin: '0px 35px' }}>
                <Col>
                    <Card style={{ height: '480px'}}>
                        <Card.Body style={{ paddingTop: '10px' }}>
                            <Stack direction="vertical" gap={3}>
                                {MakeCardRow(props)}
                            </Stack>
                        </Card.Body>
                    </Card>
                </Col>
            </div>
        </div>
    )
}

function MakeCardRow(props)
{
    let infoEntries = Object.entries(props.viewInfo);
    let viewInfoEntries = [];
    for (let i = 0; i< infoEntries.length; i++) {
        viewInfoEntries.push(infoEntries[i]);
    }

    // const viewInfoEntries = Object.entries(props.viewInfo);
    const viewDataValues = Object.values(props.viewData);

    let array = [];
    for (let i = 0; i < viewInfoEntries.length; i += 2) {
        let [key, info] = [null,null];
        let [key2, info2] = [null,null]; 

        [key, info] = viewInfoEntries[i];

        if(viewInfoEntries.length-1 !== i)
        {
            [key2, info2] = viewInfoEntries[i+1];
        }
        
        array.push(
            <Row>
                <Col>
                <BlockRealTimeCard viewInfo={info} viewData={props.viewData[key]} title={key} height={'790px'} />
                </Col>
                {info2 !== null ? (
                    <Col>
                    <BlockRealTimeCard viewInfo={info2} viewData={props.viewData[key2]} title={key2} height={'790px'} />
                    </Col>
                ) : (
                    <Col></Col>
                )}

            </Row>
        );
    }
    return array;
}


export default CoatingQualityCard
