import Button from "react-bootstrap/esm/Button";

function SubmitButton(props) {
    return (
        <Button type='submit' style={props.style} variant="primary" >Submit</Button>
    );
}

export default SubmitButton;