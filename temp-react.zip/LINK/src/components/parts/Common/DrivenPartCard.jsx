import { useTranslation } from 'react-i18next';
import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Stack from 'react-bootstrap/Stack';
import BlockRealTimeCard from './BlockRealTimeCard';
import Card from 'react-bootstrap/Card';
function DrivenPartCard(props) {
    const { t } = useTranslation();

    return (
        <Observer>
            {() => (
                <Card style={{ height: props.height }}>
                    <Card.Header>
                        <strong className="me-auto" style={{ whiteSpace: 'nowrap' }}>{props.title}</strong>                                
                    </Card.Header>

                    <Card.Body>
                        <Stack direction='vertical' gap={4}>
                        {
                            Object.entries(props.viewInfo).map(([key, info]) => {
                                const data = props.viewData[key];
                                return (
                                    <Row className="driven-data-cards">
                                        <BlockRealTimeCard cardType='FullSlide' viewInfo={info} viewData={data} interval={3000} height={'790px'} />
                                    </Row>
                                );
                            })
                        }
                        </Stack>
                    </Card.Body>
                </Card>
            )}
        </Observer>
    )
}

export default DrivenPartCard;