import React from 'react';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Stack from 'react-bootstrap/Stack'
import DropDownList from '../Common/DropDownList';
import Card from 'react-bootstrap/Card';
import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import useStore from '../../../stores/useStore';
import EquipmentClassificationCombo from '../Common/EquipmentClassificationCombo'
import { format } from "date-fns";
import swal from 'sweetalert2';
import Button from 'react-bootstrap/esm/Button';


function AddFixedIpInfoModal(props) {
    const { t } = useTranslation();
    const { ipSettingStore } = useStore();
    const [isChanged, setIsChanged] = useState(false);
    const formRef = useRef();

    useEffect(() =>{
        console.log("init poup");
    },[props.show])

    const onClose = () => {
        props.onClose();
    }

    const onSubmit = async () =>{
        const formData = new FormData(formRef.current);
        ipSettingStore.fixed_ip_info_name = formData.get("fixed_ip_info_name");
        ipSettingStore.unit = formData.get("unit");
        ipSettingStore.collection_info_id = formData.get("collection_info_id");
        ipSettingStore.block_info_id = formData.get("block_info_id");
        ipSettingStore.plc_address_info_id = formData.get("plc_address_info_id");

        if (ipSettingStore.fixed_ip_info_name === "") {
            swal.fire({
                title: t('MSG_ENTER_IP_NAME'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
            return;
        }

        if (ipSettingStore.unit === "") {
            swal.fire({
                title: t('MSG_ENTER_UNIT'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
            return;
        }

        if (ipSettingStore.collection_info_id === 0 || 
            ipSettingStore.collection_info_id === "0") {
            swal.fire({
                title: t('MSG_SELECT_EQUIPMENT_CATEGORY'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
            return;
        }

        let result = await ipSettingStore.insertFixedIpInfo();

        if(result){
            swal.fire({
                title: t('LAN_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            }).then(() => {
                onClose();
            });
            
        }else{
            swal.fire({
                title: t('LAN_FAILED'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    return ((
        <div>

            <Modal.Body>
                <div class="modal-content">
                    <form 
                        class="common-form"
                        ref={formRef}>

                        <div class="flex-form fixed">
                            <label for="fixed_ip_info_name">
                                {t('LAN_IP_NAME')}
                            </label>

                            <input type='text' id='fixed_ip_info_name' name='fixed_ip_info_name' />
                        </div>

                        <div class="flex-form fixed">
                            <label for="fixed_ip_info_unit">
                            {t('LAN_UNIT')}
                            </label>

                            <input type='text' id='fixed_ip_info_unit' name="unit" />
                        </div>

                        <div class="flex-form fixed">
                            <span class="label">
                            {t('LAN_EQUIPMENT_CATEGORY')}
                            </span>
                            <EquipmentClassificationCombo />
                        </div>
                    </form>
                </div>
            </Modal.Body>

            <div class="modal-footer-full">
                <button onClick={onClose}>
                    {t('LAN_CLOSE')}
                </button>

                <button onClick={onSubmit} class="hanwha">
                {t('LAN_SAVE')}
                </button>
            </div>
        </div>

    ));
}

export default AddFixedIpInfoModal