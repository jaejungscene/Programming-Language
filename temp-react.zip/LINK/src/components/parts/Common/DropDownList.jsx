import Form from 'react-bootstrap/Form'
import Stack from 'react-bootstrap/Stack'
const DropDownList = ({value, options, label, width, onSelect}) => {

    return (
        <div class="drop-down-list">
            {label && <Form.Label className="form-label">{label}</Form.Label>}
            <Form.Select style={{width:width}} onChange={(e)=> onSelect(e)} value={value}>
                { options.map((option) => (
                    <option key={option.value} value={option.value}>{option.name}</option> 
                ))}
            </Form.Select>
        </div>
    );
}

export default DropDownList;