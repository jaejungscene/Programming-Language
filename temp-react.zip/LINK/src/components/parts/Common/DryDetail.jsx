import { useTranslation } from 'react-i18next';
import { Observer } from 'mobx-react';
import Stack from 'react-bootstrap/Stack';
import BlockRealTimeCard from './BlockRealTimeCard';
import Card from 'react-bootstrap/Card';
import Accordion from 'react-bootstrap/Accordion';
import LineChart from './Chart/LineChart';
import Carousel from 'react-bootstrap/Carousel';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

const makeAccordionActiveKey = (viewInfo) => {
    return Object.keys(viewInfo);
}

function DryDetail(props) {
    const { t } = useTranslation();

    return (
        
        <Accordion defaultActiveKey={['0','1','2','3','4']} alwaysOpen style={{marginTop: '40px'}}>
        {
            Object.entries(props.viewInfo).map(([key, info],index) => { //TrendData
                return (

                    <Accordion.Item eventKey={key} style={{}}>
                        <Accordion.Button style={{margin:0}}>{t(info[0].name)}</Accordion.Button>
                        <Accordion.Body>
                            <Carousel
                                variant="dark"
                                indicators={false}
                                prevIcon={<FontAwesomeIcon color={info.length > 1 ? 'black' : 'white'} size='1x' icon={faChevronLeft} />}
                                nextIcon={<FontAwesomeIcon color={info.length > 1 ? 'black' : 'white'}  size='1x' icon={faChevronRight} />}
                                style={{  marginTop: '-5px'}}
                                interval={3000}
                            >
                            {

                                Object.entries(info).map(([blockKey, blockInfo], blockIndex) => {    //Block기준
                                
                                return (
                                    <Carousel.Item
                                    aria-live="polite"
                                    aria-atomic="true"
                                    interval={3000}
                                    style={{  paddingLeft: '15px', paddingRight: '15px' }}
                                    >
                                        <Stack direction="horizontal" gap={4} style={{marginTop: '17px'}}>
                                        
                                            <Card style={{ width: '18%', height: '12rem'}}>
                                                <Card.Body>
                                                <Card.Title>{t('LAN_AVERAGE_VALUE')}</Card.Title>
                                                    <Stack direction='horizontal' gap={2}>
                                                        <Card.Text style={{ fontSize: '56px', textAlign: 'center'}}>
                                                            { blockInfo.avg.toFixed(1) } 
                                                        </Card.Text>
                                                        <Card.Text style={{ fontSize: '26px', textAlign: 'center'}}>{blockInfo.unit}</Card.Text>
                                                    </Stack>
                                                </Card.Body>
                                            </Card>
                                            <Card style={{ width: '18%', height: '12rem'}}>
                                            <Card.Body>
                                            <Card.Title>{t('LAN_PEAK_VALUE')}</Card.Title>
                                                <Stack direction='horizontal' gap={2}>
                                                    <Card.Text style={{ fontSize: '56px', textAlign: 'center'}}>
                                                        { blockInfo.max.toFixed(1) } 
                                                    </Card.Text>
                                                    <Card.Text style={{ fontSize: '26px', textAlign: 'center'}}>{blockInfo.unit}</Card.Text>
                                                </Stack>
                                            </Card.Body>
                                            </Card>

                                            <div className='vr'></div>
                                            <Card style={{ height: '12rem'}}>
                                                <Card.Body>
                                                    <LineChart options={blockInfo.chartData} width='940px' height='176px'></LineChart>
                                                </Card.Body>
                                            </Card>          
                                            
                                        </Stack>
                                    </Carousel.Item>
                                );
                                })
                            }
                            </Carousel>
                        </Accordion.Body>
                    </Accordion.Item>
                );
            })
        }
        </Accordion>
    )
}

export default DryDetail;