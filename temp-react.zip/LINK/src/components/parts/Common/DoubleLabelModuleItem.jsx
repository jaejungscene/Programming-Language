import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Carousel from 'react-bootstrap/Carousel';
import Toast from 'react-bootstrap/Toast';
import ToastContainer from 'react-bootstrap/ToastContainer';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import styled, { keyframes } from 'styled-components';

function isError(color) {
    if (color === 'Black') {
        return false;
    } else {
        return true;
    }
}

function blinkingEffect() {
    return keyframes`
    50% {
      opacity: 0;
    }
  `;
}

const AnimatedComponent = styled.div`
    animation: ${blinkingEffect} 1s linear infinite;
  `



function DoubleLabelModuleItem(props) {

    return (
        <Observer>
            {() => (
                <Carousel
                    variant="dark"
                    indicators={false}
                    prevIcon={<FontAwesomeIcon color='black' size='1x' icon={faChevronLeft} />}
                    nextIcon={<FontAwesomeIcon color='black' size='1x' icon={faChevronRight} />}
                >
                    {props.viewData.map((data) => {
                        return (
                            <Carousel.Item
                                aria-live="polite"
                                aria-atomic="true"
                                interval={props.interval}
                                style={{ minHeight: '130px' }}
                            >

                                <ToastContainer className="p-3" position={'top-start'}>
                                    <Toast style={{height : '110px'}}>
                                        <Toast.Header onClick={props.onClick} closeButton={false} style={{ fontSize: '1.1em', color: 'white', backgroundColor: 'rgb(52,58,64)' }}>
                                            <label className="me-auto" style={{ cursor: 'pointer', whiteSpace : 'nowrap' }}>{props.title}</label>
                                            <small style={{marginLeft : '5px'}}>{data.moduleName == undefined ? '' : data.moduleName}</small>
                                        </Toast.Header>

                                        <Toast.Body>
                                            <Row>
                                                {isError(data.label1Color) ?
                                                    (
                                                        <Row>
                                                            <Col style={{ textAlign: 'center', fontSize: '15px' }}>{props.dataType[0]}</Col>
                                                            <Col style={{ fontSize: '15px', color: data.label1Color, fontWeight: 'bold' }}>{data.label1 < 0 ? '-' : data.label1}</Col>
                                                        </Row>
                                                    ) :
                                                    (<Row>
                                                        <Col style={{ textAlign: 'center', fontSize: '15px' }}>{props.dataType[0]}</Col>
                                                        <Col style={{ fontSize: '15px' }}>{data.label1 < 0 ? '-' : data.label1}</Col>
                                                    </Row>)}
                                            </Row>

                                            <Row style={{ marginTop: '5px' }}>
                                                {isError(data.label2Color) ?
                                                    (
                                                        <Row>
                                                            <Col style={{ textAlign: 'center', fontSize: '15px' }}>{props.dataType[1]}</Col>
                                                            <Col style={{ fontSize: '15px', color: data.label2Color, fontWeight: 'bold' }}>{data.label2 < 0 ? '-' : data.label2}</Col>
                                                        </Row>
                                                    ) :
                                                    (<Row>
                                                        <Col style={{ textAlign: 'center', fontSize: '15px' }}>{props.dataType[1]}</Col>
                                                        <Col style={{ fontSize: '15px' }}>{data.label2 < 0 ? '-' : data.label2}</Col>
                                                    </Row>)}
                                            </Row>
                                        </Toast.Body>
                                    </Toast>
                                </ToastContainer>

                            </Carousel.Item>
                        )
                    })}
                </Carousel>
            )}
        </Observer>
    )
}

export default DoubleLabelModuleItem;