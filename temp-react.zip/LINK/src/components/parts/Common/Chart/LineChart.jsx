//import { LineChart, Line, CartesianGrid, XAxis, YAxis } from 'recharts';
import ECharts from 'echarts-for-react'


const RenderLineChart = (props) => {
    return (
        <ECharts option={props.options} style={{ height : props.height === undefined ? '300px': props.height}} notMerge='true' opts={{ renderer: 'svg', width: props.width, height: props.height }} />
    );
}

export default RenderLineChart;