//import { LineChart, Line, CartesianGrid, XAxis, YAxis } from 'recharts';
import ECharts from 'echarts-for-react'
import { format } from 'date-fns';

const LineChartForTime = (props) => {
    let seriesArray = [];
    let valueArray = [];
    let splitX = typeof props.splitX !== "undefined" ? props.splitX : 8;
    let option = {};

    if (props.viewData) {
        props.viewData.map((data) => {
            // Fixed IP 용도
            if (props.viewData.length >= 1 && props.viewData[0].length > 1) {
                data.map((item, index) => {
                    if (typeof seriesArray[index] === "undefined") {
                        seriesArray[index] = 
                            {
                                name: item.name,
                                type: 'line',
                                // showSymbol: false,
                                data: [[new Date(item.date), item.value]]
                            };
                    }
                    else {
                        seriesArray[index].data.push([
                            new Date(item.date), 
                            item.value
                        ])
                    }
                })

            }
            // 단일 value
            else {
                data.map((item) => {
                    valueArray.push([
                        new Date(item.date),
                        item.value
                    ]);
                })

                // 상한 하한값이 있는 경우
                if (typeof props.upperThreshold !== "undefined" || typeof props.lowerThreshold !== "undefined") {
                    seriesArray = [
                        {
                            name: props.name,
                            type: 'line',
                            showSymbol: false,
                            data: valueArray,
                            markLine: {
                                data: [
                                    {
                                        yAxis: parseFloat(props.upperThreshold), 
                                        label: { 
                                            formatter(param) {
                                                return `${param.data.value}`;
                                            },
                                        },
                                        lineStyle: {
                                            color: '#ff4d4f'
                                        }
                                    },
                                    {
                                        yAxis: parseFloat(props.lowerThreshold), 
                                        label: { 
                                            formatter(param) {
                                                return `${param.data.value}`;
                                            },
                                        },
                                        lineStyle: {
                                            color: '#005fb8'
                                        }
                                    },
                                ]
                            },

                        }
                    ];
                }
                else {
                    seriesArray = [
                        {
                            name: props.name,
                            type: 'line',
                            showSymbol: false,
                            data: valueArray
                        }
                    ];
                }
            }
        });
    }

    option = {
        grid: {
            top:20,
            bottom: 30
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross'
            },
        },
        xAxis: {
            type: 'category',
            splitLine: {
                show: false
            },
            splitNumber: splitX,
            axisLabel: {
                formatter: function (value) {
                    return format(new Date(value), "HH:mm:ss");
                }
            }
        },
        yAxis: {
            type: 'value',
            boundaryGap: true,
            max: function (data) {
                let max = data.max;
                if (typeof props.upperThreshold !== "undefined" && data.max < props.upperThreshold) {
                    max = parseInt(props.upperThreshold);
                }

                max += Math.abs(data.min < 0 ? data.max + data.min : data.max - data.min) / 2;

                if (max < 1) {
                    return Math.ceil(max) + 1;
                }
                else {
                    return Math.ceil(max);
                }
            },
            min: function (data) {
                let min = data.min;
                if (typeof props.lowerThreshold !== "undefined" && data.min > props.lowerThreshold) {
                    min = parseInt(props.lowerThreshold);
                }

                min -= Math.abs(data.min < 0 ? data.max + data.min : data.max - data.min) / 2;

                return Math.floor(min) ;
            },
            axisLabel: {
                showMaxLabel: true,
                showMaxLabel: false,
            },
            splitNumber: 5
        },
        animation: false,
        series: seriesArray
    };

    if (typeof props.upperThreshold !== "undefined" && typeof props.lowerThreshold !== "undefined") {
        option.visualMap = {
            show:false,
            pieces: [
                {
                    max: parseFloat(props.lowerThreshold),
                    color: '#ff4d4f'
                },
                {
                    min: parseFloat(props.lowerThreshold),
                    max: parseFloat(props.upperThreshold),
                    color: '#7fb800'
                },
                {
                    min: parseFloat(props.upperThreshold),
                    color: '#ff4d4f'
                },
            ],
            outOfRange: {
                color: '#999'
            }
        };
    }

    if (props.viewData && props.viewData.length === 0) {
        option = {
            title: {
                show: true,
                textStyle: {
                    color: '#0d6efd',
                    fontSize: '30px'
                },
                text: `No Data`,
                left: 'center',
                top: 'center'
            },
        }
    }

    return (
        <ECharts option={option} style={{ height : props.height === undefined ? '300px': props.height}} notMerge='true' opts={{ renderer: 'svg', width: props.width, height: props.height }} />
    );
}

export default LineChartForTime;