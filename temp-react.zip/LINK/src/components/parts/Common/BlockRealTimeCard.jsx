import { useTranslation } from 'react-i18next';
import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Carousel from 'react-bootstrap/Carousel';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React, { useState } from 'react';
import Badge from 'react-bootstrap/Badge';
import BlockRealTimeChart from './BlockRealTimeChart';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';


function BlockRealTimeCard(props) {

    const { t } = useTranslation();
    const titleTranslate = t("LAN_" + props.title);

    return (
        <Observer>
        {() => {
            let renderedComponent;

            if (props.title !== undefined) {
                renderedComponent = renderTitleCard(titleTranslate, props.viewInfo, props.viewData, 10000);
            } else if (props.cardType === 'FullSlide') {
                renderedComponent = renderFullSlideCard(props.viewInfo, props.viewData, 10000);
            } else {
                renderedComponent = renderSlideCard(t, props.viewInfo, props.viewData, 10000);
            }

            return renderedComponent;
        }}
        </Observer>
    )
}


const renderTitleCard = (title, viewInfo, viewData, interval = 10000) => {
    const styles = {
        badge: {
            minWidth: '70px',
            display: 'inline-block',
            fontSize: '0.9rem',
            cursor: 'pointer',
            marginRight: '5px'
        },
        cardrow: {
            margin:'0',
            padding: '0'
        }
    };

    return (
        <div>
            <Row style={{ margin: '0'}} className="coating-quality-card">
                <Row style={styles.cardrow}>
                <Card style={{ height: '40px', padding:'0'}}>
                    <Card.Header style={{ whiteSpace: 'nowrap', overflow: 'hidden'}}>
                        {title}  [ {viewInfo[0].Unit} ]
                        <span style={{ float: 'right'}}>
                            {
                                viewInfo.map((info, index) => {
                                return (
                                    <Badge bg="secondary" style={styles.badge} className={"color-type-" + index}>
                                        {/* {info.ParameterName} :  */}
                                        {viewData?.[viewData.length-1]?.[index]?.Value || 0}
                                    </Badge>
                                )})
                            }
                        </span>
                    </Card.Header>
                </Card>

                </Row>
                <Row style={styles.cardrow}>
                    <Card style={{ height: '100px' }}>
                        {<BlockRealTimeChart chartWidth={'749px'} chartHeight={'100px'} viewInfo={viewInfo} viewData={viewData}> </BlockRealTimeChart>}
                    </Card>
                </Row>
            </Row>
        </div>
    )
}


const renderFullSlideCard = (viewInfo, viewData, interval = 3000) => {
    return (
        <div>
            <Row>
                <Carousel
                    variant="dark"
                    indicators={false}
                    prevIcon={<FontAwesomeIcon color={viewInfo.length > 1 ? 'black' : 'white'} size='1x' icon={faChevronLeft} />}
                    nextIcon={<FontAwesomeIcon color={viewInfo.length > 1 ? 'black' : 'white'}  size='1x' icon={faChevronRight} />}
                >
                {
                viewInfo.map((info, index) => {
                return(
                    <Carousel.Item
                        aria-live="polite"
                        aria-atomic="true"
                        interval={interval}
                        style={{ minHeight: '130px', paddingLeft: '7px', paddingRight: '7px' }}
                    >
                        <Row>
                        <Col sm={4}>
                        <Card style={{ height: '135px' }}>
                            <Card.Body>
                                <OverlayTrigger
                                placement="top"
                                overlay={<Tooltip id="tooltip">{info.ParameterName}</Tooltip>}
                                >
                                    <Card.Title style={{ whiteSpace: 'nowrap', overflow: 'hidden'}}>{info.ParameterName}</Card.Title>

                                </OverlayTrigger>
                                <Stack direction='horizontal' gap={2}>
                                    <Card.Text style={{ fontSize: '36px', textAlign: 'center' }}>
                                        {viewData?.[viewData.length-1]?.[index]?.Value || 0}
                                    </Card.Text>
                                    <Card.Text style={{ fontSize: '20px', textAlign: 'center' }}>{info.Unit}</Card.Text>
                                </Stack>
                                
                            </Card.Body>
                        </Card>
                        </Col>
                    
                    
                        <Col sm={8}>
                        <Card style={{ height: '135px' }}>
                            {<BlockRealTimeChart chartWidth={'500px'} chartHeight={'180px'} viewInfo={viewInfo} viewData={viewData} dataIdx={index}> </BlockRealTimeChart>}
                        </Card>
                        </Col>
                        </Row>
                    </Carousel.Item>
                )
                })}
                </Carousel>
            </Row>
        </div>
    )
}

const renderSlideCard = (t, viewInfo, viewData, interval = 3000) => {
    const styles = {
        badge: {
            minWidth: '70px',
            display: 'inline-block',
            fontSize: '0.9rem',
            cursor: 'pointer',
            marginRight: '5px'
        },
        cardrow: {
            margin:'0',
            padding: '0'
        }
    };

    return (
        <div>
            <Row>
                <Row style={styles.cardrow}>
                <Card style={{ height: '40px', padding:'0'}}>
                    <Card.Header style={{ whiteSpace: 'nowrap', overflow: 'hidden'}}>
                        {t("LAN_" + viewInfo[0].BlockName)} [ {viewInfo[0].Unit} ]
                        <span style={{ float: 'right'}}>
                            {
                                viewInfo.map((info, index) => {
                                return (
                                    <Badge bg="secondary" style={styles.badge} className={"color-type-" + index}>
                                        {viewData?.[viewData.length-1]?.[index]?.Value || 0}
                                    </Badge>
                                )})
                            }
                        </span>
                    </Card.Header>
                </Card>
                </Row>
                <Row style={styles.cardrow}>
                    <Card style={{ height: '122px', padding: '0' }}>
                        {<BlockRealTimeChart chartWidth={'740px'} chartHeight={'120px'} viewInfo={viewInfo} viewData={viewData}> </BlockRealTimeChart>}
                    </Card>
                </Row>
            </Row>
        </div>
        
    )
}


/*
{() => {
        for (let info in viewInfo) {
            return (
                <Carousel.Item
                aria-live="polite"
                aria-atomic="true"
                interval={interval}
                style={{  paddingLeft: '15px', paddingRight: '15px' }}
                >
                <Card.Title style={{ fontSize: '20px'}}>{t(info.ParameterName)}</Card.Title>
                <Stack direction='horizontal' gap={2}>
                    <Card.Text style={{ fontSize: '20px', textAlign: 'center' }}>
                        {viewData?.[info.BlockInfoID]?.Value || 0}
                    </Card.Text>
                    <Card.Text style={{ fontSize: '20px', textAlign: 'center' }}>um</Card.Text>
                    <Card.Text style={{ fontSize: '20px', textAlign: 'center' }}></Card.Text>
                </Stack>

                </Carousel.Item>
                    );
        }
    }
    
}
*/
export default BlockRealTimeCard;