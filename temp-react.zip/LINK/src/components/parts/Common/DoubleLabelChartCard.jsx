import React, { useEffect, useState, useRef, useCallback } from 'react'
import useStore from '../../../stores/useStore';
import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Carousel from 'react-bootstrap/Carousel';
import Card from 'react-bootstrap/Card';
import Badge from 'react-bootstrap/Badge';
import Stack from 'react-bootstrap/Stack';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import styled, { keyframes } from 'styled-components';
import DashBoardRealTimeChart from './DashBoardRealTimeChart';


function isError(color) {
    if (color === 'Black') {
        return false;
    } else {
        return true;
    }
}

const styles = {
    badge: {
        float: 'right',
        fontSize: '0.9rem',
        cursor: 'pointer'
    }
};

function DoubleLabelChartCard(props) {

    useEffect(() => {
        console.log("호출되었습니다.");

    }, []);

    return (
        <Observer>
            {() => (
                <Carousel
                    variant="dark"
                    indicators={false}
                    prevIcon={<FontAwesomeIcon color='black' size='1x' icon={faChevronLeft} />}
                    nextIcon={<FontAwesomeIcon color='black' size='1x' icon={faChevronRight} />}
                >
                    {props.viewData.map((data) => {
                        return (
                            <Carousel.Item
                                aria-live="polite"
                                aria-atomic="true"
                                interval={props.interval}
                                style={{ minHeight: '130px', paddingLeft: '7px', paddingRight: '7px' }}
                            >

                                <Card style={{ height: props.height }}>
                                    <Card.Header>
                                        <strong className="me-auto" style={{ whiteSpace: 'nowrap' }}>{props.title}</strong>
                                        <Badge bg="secondary" style={styles.badge}>{data.moduleName}</Badge>
                                    </Card.Header>

                                    <Card.Body>
                                        <Stack direction="vertical" gap={2}>
                                            <Row>
                                                <Col sm={4}>
                                                    <Card style={{ height: '135px' }}>
                                                        <Card.Body>
                                                            <Card.Title>{props.cardHeader[0]}</Card.Title>
                                                            <Stack direction='horizontal' gap={2}>
                                                                <Card.Text style={{ fontSize: '36px', textAlign: 'center' }}>
                                                                    {data.osValue[0]}
                                                                </Card.Text>
                                                                <Card.Text style={{ fontSize: '20px', textAlign: 'center' }}>Mpa</Card.Text>
                                                            </Stack>
                                                        </Card.Body>
                                                    </Card>
                                                </Col >

                                                <Col sm={8}>
                                                    <Card style={{ height: '135px' }}>
                                                        {<DashBoardRealTimeChart chartWidth={'500px'} chartHeight={'180px'} chartValue={data.osValue} legends = {data.legends}></DashBoardRealTimeChart>}
                                                    </Card>
                                                </Col>

                                            </Row>

                                            <Row>
                                                <Col sm={4}>
                                                    <Card style={{ height: '135px' }}>
                                                        <Card.Body>
                                                            <Card.Title>{props.cardHeader[1]}</Card.Title>
                                                            <Stack direction='horizontal' gap={2}>
                                                                <Card.Text style={{ fontSize: '36px', textAlign: 'center' }}>
                                                                    {data.dsValue[0]}
                                                                </Card.Text>
                                                                <Card.Text style={{ fontSize: '20px', textAlign: 'center' }}>Mpa</Card.Text>
                                                            </Stack>
                                                        </Card.Body>
                                                    </Card>
                                                </Col >

                                                <Col sm={8}>
                                                    <Card style={{ height: '135px' }}>
                                                        {<DashBoardRealTimeChart chartWidth={'500px'} chartHeight={'180px'} chartValue={data.dsValue} legends = {data.legends}></DashBoardRealTimeChart>}
                                                    </Card>
                                                </Col>

                                            </Row>

                                        </Stack>

                                    </Card.Body>
                                </Card>
                            </Carousel.Item>
                        )
                    })}
                </Carousel>
            )}
        </Observer>
    )
}

export default DoubleLabelChartCard;