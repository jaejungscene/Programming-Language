import React from 'react';
import {useTable, useRowSelect, useBlockLayout} from 'react-table';
import BTable from 'react-bootstrap/Table';
import '../../../public/bootstrap/dist/css/bootstrap.min.css';

const Table = ({columns, data, onSelectBatch, Styles}) => {
    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow} = useTable({columns, data}, useRowSelect);
    return ( 
        <Styles>
            <BTable striped bordered hover size="sm" {...getTableProps()} defaultPageSize={20} >
                <thead>
                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps()} >
                            {headerGroup.headers.map((column)=>(
                                <th {...column.getHeaderProps()}>{column.render('Header')} </th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()} >
                    {rows.map((row) => {
                        prepareRow(row);
                        return(
                            <tr {...row.getRowProps()} onClick={()=> onSelectBatch(row)}>
                                {row.cells.map((cell)=>(
                                    <td style= {{textAlign:'center'}} {...cell.getCellProps()}>{cell.render('Cell')} </td>
                                ))}
                            </tr>
                        )
                    })}
                </tbody>
            </BTable>
        </Styles>
    );
}

export default Table