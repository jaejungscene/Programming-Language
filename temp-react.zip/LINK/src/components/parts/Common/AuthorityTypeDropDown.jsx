
import Form from 'react-bootstrap/Form';
import { Observer } from 'mobx-react';
import { useTranslation } from 'react-i18next';

function AuthorityTypeDropDown(props) {

    const { t } = useTranslation();
    const onchange = (e) => {
        props.onChange(e);
    }

    return (
        <Observer>
            {() => (
                <Form.Select size="sm" style={{ width: '200px' }} value={props.value} onChange={onchange}>
                    <option value="1">{t('LAN_OPERATOR')}</option>
                    <option value="2">{t('LAN_SERVICE_ENGINEER')}</option>
                    <option value="3">{t('LAN_DEVELOPER')}</option>
                    <option value="4">{t('LAN_ADMINISTRATOR')}</option>
                </Form.Select>
            )}
        </Observer>
    );
}

export default AuthorityTypeDropDown;