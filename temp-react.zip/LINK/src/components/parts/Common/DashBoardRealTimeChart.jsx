import React, { useEffect, useState, useRef } from 'react'
import LineChart from '../../parts/Common/Chart/LineChart';

function DashBoardRealTimeChart(props) {
    let values = [];
    let legends = [];
    let markLines = {};

    const [xData, setXData] = useState([]);
    const [yData, setYData] = useState([]);

    const addData = (x, y) => {
        if (yData.length > 600) {
            /** 
                eChart-for-react라이브러리에서 1초당 1건의 데이터를 누적하고
                600초 경과 시 최초 데이터를 1건씩 제거하고 재누적하여 데이터의 양을 600개로 유지하였음
                그 결과 대시보드에 6개의 차트를 동시에 표시한 후 약 25~30분 경과 시 크롬 브라우저에서 Out of Memory 발생

                => 차트 데이터 600개 초과 시 최초 데이터를 2개씩 제거한 후 Memory Leak 현상 사라짐
            */
            shiftFirstElements(yData, 2);
            shiftFirstElements(xData, 2);
            
            setYData(yData);
            setXData(xData);
        }
        setYData(prev => [...prev, y]);
        setXData(prev => [...prev, x]);
    }

    const [chartOptions, setChartOptions] = useState({
        title: {
            show: true,
            textStyle: {
                color: '#0d6efd',
                fontSize: '30px'
            },
            text: `No Data`,
            left: 'center',
            top: 'center'
        },
    });

    useEffect(() => {
        if (props.chartValue !== undefined) {
            values = [];
            legends = [];
            markLines = {};

            legends = props.legends.map(value => value || '');
            markLines = props.markLines;

            for (let i = 0; i < props.chartValue.length; i++) {
                values.push(props.chartValue[i]);
            }

            addData(new Date().toLocaleTimeString().replace(/^\D*/, ""), values);
            setChartOptions(getRealTimeOption('ppllcc', xData, yData, legends, markLines));
        }
    }, [props.chartValue]);

    function shiftFirstElements(arr, cnt){
        if(cnt === 0){
            return arr;
        }else{
            arr.shift();
            return shiftFirstElements(arr, cnt -1);
        }
    }

    const getRealTimeOption = (plcInfo, xSeriesData, ySeriesData, legends, markLines) => {
        let seriesDatas = [];
        let markline = {
            animation: false,
            data: [{
                symbol: 'none',
                name: 'Upper Limit',
                yAxis: markLines.upper == undefined ? 0 : markLines.upper,
                label: { show: true, position: 'end' },
                lineStyle: {
                    color: 'red'
                }
            },
            {
                symbol: 'none',
                name: 'Lower Limit',
                yAxis: markLines.lower == undefined ? 0 : markLines.lower,
                label: { show: true, position: 'end' },
                lineStyle: {
                    color: 'red'
                }
            }],
        }
        for (let i = 0; i < legends.length; i++) {
            seriesDatas.push([]);
        }

        for (let i = 0; i < ySeriesData.length; i++) {
            for (let j = 0; j < legends.length; j++) {
                seriesDatas[j].push(ySeriesData[i][j]);
            }
        }
        const seriesData = seriesDatas.map((data, i) => ({
            name: legends[i],
            type: "line",
            data: data,
            markLine: markline
        }));

        let option = {
            title: {
                text: ''
            },
            tooltip: {
                trigger: "axis",
                axisPointer: {
                    type: "cross",
                    label: {
                        backgroundColor: "#283b56"
                    }
                }
            },
            legend: {
                data: legends
            },
            toolbox: {
                show: false,
                feature: {
                    dataView: { readOnly: false },
                    restore: {},
                    saveAsImage: {}
                }
            },
            grid: {
                top: '10%'
            },
            xAxis: [
                {
                    type: "category",
                    boundaryGap: true,
                    markPoint: {
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff"
                                }
                            }
                        },
                    },
                    data: xSeriesData,
                }
            ],
            yAxis: [
                {
                    type: "value",
                    scale: true,
                    max: function (value) {
                        return value.max + 5
                    },
                    min: function (value) {
                        return value.min - 5
                    },

                }
            ],
            series: seriesData
        };
        return option;
    };

    return (
        <div style={{ display: 'flex' }}>
            <LineChart options={chartOptions} width={props.chartWidth} height={props.chartHeight}></LineChart>
        </div>
    )
}

export default DashBoardRealTimeChart