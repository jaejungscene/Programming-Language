import React from 'react';
import Modal from 'react-bootstrap/Modal';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useObserver } from 'mobx-react';

import { AiOutlineClose, AiFillTool } from "react-icons/ai";
import { FaBook } from "react-icons/fa";



function WebModal(props) {
    const { t } = useTranslation();

    useEffect(() => {
        if(props.show){

        }
    }, [props.show])
    

    const onSave = async () => {
        props.onClose("");
    }

    const onClose = () => {
        props.onClose();
    }

    return useObserver(() => (
        <Modal
            show={props.show}
            onHide={props.handleClose}
            backdrop="static"
            keyboard={false}
            size="xl"
            dialogClassName="web-modal"
        >
            <Modal.Header>
                <Modal.Title>
                    {
                        props.iconTitle === "guide" &&
                        <FaBook />
                    }
                    {
                        props.iconTitle === "maintenance" &&
                        <AiFillTool />
                    }
                    {
                        props.iconTitle &&
                        <span>
                            &nbsp;&nbsp;
                        </span>
                    }
                
                    
                    {props.title}
                </Modal.Title>

                <span class="modal-header-close" onClick={onClose}>
                    <AiOutlineClose />
                </span>
            </Modal.Header>

            { props.children }

        </Modal>
    ));

}

export default WebModal