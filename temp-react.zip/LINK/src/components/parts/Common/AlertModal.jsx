import React from 'react';
import Modal from 'react-bootstrap/Modal';
import Table from './Table'
import styled from 'styled-components';
import Button from 'react-bootstrap/Button';
import { useTranslation } from 'react-i18next';

const styles = styled.div`
${``/*.table {
    height: 370px;
    width: 100%;
    tbody {
        height: 340px;
        table-layout: fixed;
        display: block;
        overflow-y: auto;
        overflow-x: hidden;
    }

    thead, tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
    }
}
*/}
height: 370px;
overflow-y: scroll;
`

function AlertModal(props) {
    const {t} = useTranslation();
    const tableColumns = {columns: [
        {
            accessor: "",
            Cell: (row) => {
                return <div>{Number(row.row.id) + 1}</div>;
            },
            Header: "#",
            width: '9%'
        },
        {
            accessor: 'ModuleInfoId',
            Header: t("LAN_TABLE_MODULE"),
            width: '10%'
        },
        {
            accessor: 'Name',
            Header: t("LAN_TABLE_NAME"),
            width: '10%'
        },
        {
            accessor: 'CreDate',
            Header: t("LAN_TABLE_DATE"),
            width: '18%'
        },
        {
            accessor: 'AlarmType',
            Header: t("LAN_TABLE_TYPE"),
            width: '8%'
        },
        {
            accessor: 'AlarmMessage',
            Header: t("LAN_TABLE_MESSAGE"),
            width: '35%'
        },
    ], data: []}
    const handleRowSelect = (row) => {
        
    }

    return (
        <Modal
            show={props.show}
            onHide={props.handleClose}
            backdrop="static"
            keyboard={false}
            size="xl"
            dialogClassName="modal-90w"
        >
            <Modal.Header closeButton>
                <Modal.Title>{t("LAN_RECENT_ALERT")} &nbsp;{t('LAN_COUNT')}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Table columns={tableColumns.columns} data={props.datas} onSelectBatch={handleRowSelect} Styles={styles}/>
            </Modal.Body>
            <Modal.Footer>
                {/*<Button onClick={props.clearList}>Clear</Button>*/}
                <Button variant="danger" onClick={props.handleClose}>{t('LAN_CLOSE')}</Button>
            </Modal.Footer>
        </Modal>
    );
}

export default AlertModal