import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';

function Checkbox(props) {
    const [checkStatus, setcheckStatus] = useState(false);

    const toggleSwitch = (e) => {
        setcheckStatus(!checkStatus);
        props.onChange(e);
    }

    return (
        <Form.Check type="checkbox" id={props.pid} onClick={toggleSwitch} label={props.label} defaultChecked={props.value} />
    );
}

export default Checkbox;