import { Observer } from 'mobx-react';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import Carousel from 'react-bootstrap/Carousel';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleLeft } from '@fortawesome/free-solid-svg-icons';
import { faCircleRight } from '@fortawesome/free-solid-svg-icons';
import LineChart from './Chart/LineChart';


function SliderLabelCard(props) {
    return (
        <Observer>
            {() => (
                <Card>
                    <Card.Header onClick={props.onClick}>{props.title}</Card.Header>
                    <Card.Body>
                        <div>
                            {props.dataType}
                        </div>
                        <div style={{ marginTop: "10px" }}>
                            <Carousel
                                variant='dark'
                                interval={props.interval}
                                indicators={false}
                                prevIcon={<FontAwesomeIcon color='black' size='2x' icon={faCircleLeft} />}
                                nextIcon={<FontAwesomeIcon color='black' size='2x' icon={faCircleRight} />}
                            >
                                {props.viewData.map((data) => {
                                    return (
                                        <Carousel.Item>
                                            <h5 style={{ color: data.label1Color, textAlign: 'center', width: props.width }}>
                                                {props.labelName[0] === undefined ? '' : props.labelName[0]}
                                                {props.labelName[0] === undefined ? '' : ':'}
                                                {data.label1 === undefined ? '' : data.label1}
                                            </h5>
                                            <h5 style={{ color: data.label2Color, textAlign: 'center', width: props.width }}>
                                                {props.labelName[1] === undefined ? '' : props.labelName[1]}
                                                {props.labelName[1] === undefined ? '' : ':'}
                                                {data.label2 === undefined ? '' : data.label2}
                                            </h5>
                                            <h5 style={{ color: data.label3Color, textAlign: 'center', width: props.width }}>
                                                {props.labelName[2] === undefined ? '' : props.labelName[2]}
                                                {props.labelName[2] === undefined ? '' : ':'}
                                                {data.label3 === undefined ? '' : data.label3}
                                            </h5>
                                        </Carousel.Item>
                                    )
                                })}
                            </Carousel>
                        </div>
                    </Card.Body>
                </Card>
            )}
        </Observer>
    )
}

export default SliderLabelCard;