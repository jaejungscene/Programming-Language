import React, { useEffect, useState, useRef } from 'react'
import LineChart from './Chart/LineChart';
var moment = require('moment');

function BlockRealTimeChart(props) {
    let values = [];
    let dateValues = [];
    let legends = [];
    let chartData = {};

    const [chartOptions, setChartOptions] = useState({
        title: {
            show: true,
            textStyle: {
                color: '#0d6efd',
                fontSize: '30px'
            },
            text: `No Data`,
            left: 'center',
            top: 'center'
        },
    });

    useEffect(() => {
        if (props.viewData !== undefined) {
            legends = [];
            values = [];
            dateValues = [];
            chartData = {};


            //console.log(props.viewData);
            
            for(let viewData of props.viewData)
            {
                if (!chartData[viewData.PLCAddressId]) {
                    chartData[viewData.PLCAddressId] = [];
                }
                chartData[viewData.PLCAddressId].push(viewData);


                if (!legends.includes(viewData)) {
                    legends.push(viewData);
                }
            }

            setChartOptions(getTrendOption(chartData));
        }
    }, [props.viewData, props.viewInfo]);

    
    const getTrendOption = (chartOption) => {
        let seriesDatas = [];

        const optionKeys = Object.keys(chartOption);
        let legends = []; 
        const xSeriesData = [];
        const blockName = chartOption[optionKeys[0]][0].BlockInfoID;
        let unitName = chartOption[optionKeys[0]][0].Unit;

        if (unitName !== "") {
            unitName = "[ " + unitName + " ]";
        }

        for (let i = 0; i < optionKeys.length; i++) {
            const key = optionKeys[i];
            seriesDatas.push([]);
            
            for(let data of chartOption[key]){
                seriesDatas[i].push(data.Value);

                if( i === 0){
                    xSeriesData.push(moment(data.CreDate).format("YYYY-MM-DD HH:mm:ss"));
                }

                if (!legends.includes(data.ParameterName)) {
                    legends.push(data.ParameterName);
                }

            }

        }

        const seriesData = seriesDatas.map((data, i) => ({
            name: legends[i],
            type: "line",
            showSymbol: false,
            data: data,
        }));

        if (legends.length <= 1) {
            legends = [];
        }

        let option = {
            title: {
                text: blockName + " " + unitName,
                textStyle: {
                    fontSize: 13,
                  },
                padding: [0, 0, 0, 0], // 상단, 우측, 하단, 좌측 간격
            },
            tooltip: {
                trigger: "axis",
                axisPointer: {
                    type: "cross",
                    label: {
                        backgroundColor: "#283b56"
                    }
                }
            },
            legend: {
                icon: 'rect',
                itemWidth:12,
                itemHeight:12,
                data: legends,
                top: 20, // 범례의 상단 간격 조정
                left: 70,
                textStyle: {
                    align:'left', 
                    fontSize: 12
                }
            },
            toolbox: {
                show: false,
                feature: {
                    dataView: { readOnly: false },
                    restore: {},
                    saveAsImage: {}
                }
            },
            grid: {
                top: '20%'
            },
            xAxis: [
                {
                    type: "category",
                    boundaryGap: true,
                    markPoint: {
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff"
                                }
                            }
                        },
                    },
                    data: xSeriesData,
                }
            ],
            yAxis: [
                {
                    type: "value",
                    scale: true,
                    max: function (value) {
                        return value.max + 5
                    },
                    min: function (value) {
                        return value.min - 5
                    },

                }
            ],
            animation: false,
            series: seriesData
        };
        return option;
    };

    return (
        <div style={{ display: 'flex' }}>
            <LineChart options={chartOptions} width={props.chartWidth} height={props.chartHeight}></LineChart>
        </div>
    )
}

export default BlockRealTimeChart