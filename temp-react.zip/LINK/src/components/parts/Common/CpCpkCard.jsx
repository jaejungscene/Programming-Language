import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import { useState, useEffect } from 'react';
import { useObserver } from 'mobx-react';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import Badge from 'react-bootstrap/Badge';
import LineChart from './Chart/LineChart';

const styles = styled.div`
${``/*.table {
    height: 370px;
    width: 100%;
    tbody {
        height: 340px;
        table-layout: fixed;
        display: block;
        overflow-y: auto;
        overflow-x: hidden;
    }

    thead, tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
    }
}
*/}
height: 370px;
overflow-y: scroll;
`

function CpCpkCard(props) {
    const { t } = useTranslation();    

    const styles = {
        badge: {
            float: 'right',
            fontSize: '0.9rem',
            cursor: 'pointer'
        }
    };


    return useObserver(() => (
        <Container fluid>
            <Row id='body' style={{ padding: '9px' }}>
                <Col>
                    <Card>
                        <Card.Header>
                            <strong className="me-auto" style={{ whiteSpace: 'nowrap' }}>{props.datas.ParameterName}</strong>                                                        
                        </Card.Header>
                        <Card.Body>
                            <Stack direction="horizontal" gap={4}>
                                <Card style={{ width: '18rem', height: '12rem' }}>
                                    <Card.Body>
                                        <Card.Title>{props.title}</Card.Title>
                                        <Stack direction='horizontal' gap={2}>
                                            <Card.Text style={{ fontSize: '56px', textAlign: 'center' }}>
                                                {props.datas.standardSpec}
                                            </Card.Text>
                                            <Card.Text style={{ fontSize: '26px', textAlign: 'center' }}> ± {props.datas.deviation + props.unit}</Card.Text>
                                        </Stack>
                                    </Card.Body>
                                </Card>
                                <Stack direction='vertical' gap={2} style={{ flex: 'none' }}>
                                    <Card style={{ width: '17rem', height: '6rem' }}>
                                        <Card.Body>
                                            <Card.Title>{t("LAN_AVERAGE_VALUE")}</Card.Title>
                                            <Stack direction = 'horizontal' gap={1} style={{float : 'right'}}>
                                                <Card.Text style={{ fontSize: '28px', textAlign: 'right', marginRight: "5px" }}>
                                                    {props.datas.avg.toFixed(2)}
                                                </Card.Text>
                                                <Card.Text style={{ fontSize: '20px', textAlign: 'right' }}>{props.unit}</Card.Text>
                                            </Stack>
                                            
                                        </Card.Body>
                                    </Card>
                                    <Card style={{ width: '17rem', height: '6rem' }}>
                                        <Card.Body>
                                            <Card.Title>{t("LAN_STANDARD_DEVIATION")}</Card.Title>
                                            <Stack direction = 'horizontal' gap={1} style={{float : 'right'}}>
                                                <Card.Text style={{ fontSize: '28px', textAlign: 'right', marginRight: "5px" }}>
                                                    {props.datas.stdDev.toFixed(2)}
                                                </Card.Text>
                                                <Card.Text style={{ fontSize: '20px', textAlign: 'right'}}>{props.unit}</Card.Text>
                                            </Stack>
                                        </Card.Body>
                                    </Card>
                                </Stack>
                                <Stack direction='vertical' gap={2} style={{ flex: 'none' }}>
                                    <Card style={{ width: '17rem', height: '6rem' }}>
                                        <Card.Body>
                                            <Card.Title>Cp</Card.Title>
                                            <Card.Text style={{ fontSize: '28px', textAlign: 'right', marginRight: "0px" }}>
                                                {props.datas.cp.toFixed(3)}
                                            </Card.Text>
                                        </Card.Body>
                                    </Card>
                                    <Card style={{ width: '17rem', height: '6rem' }}>
                                        <Card.Body>
                                            <Card.Title>Cpk</Card.Title>
                                            <Card.Text style={{ fontSize: '28px', textAlign: 'right', marginRight: "0px" }}>
                                            {props.datas.cpk.toFixed(3)}
                                            </Card.Text>
                                        </Card.Body>
                                    </Card>
                                </Stack>
                                <div className='vr' />
                                <Card style={{ height: '12rem', width : '690px' }}>
                                    <Card.Body>
                                        <LineChart options={props.datas.histogramData} width='650px' height='220px'></LineChart>
                                    </Card.Body>
                                </Card>
                            </Stack>
                            <Card style={{ height: '12em', width: '1620px', marginTop: '10px' }}>
                                <Card.Body>
                                    <LineChart options={props.datas.trendData} width='1580px' height='176px'></LineChart>
                                </Card.Body>
                            </Card>
                        </Card.Body>

                    </Card>

                </Col>
            </Row>

        </Container>
    ));
}

export default CpCpkCard;