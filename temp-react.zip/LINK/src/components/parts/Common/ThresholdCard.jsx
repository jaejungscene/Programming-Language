import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import Form from 'react-bootstrap/Form'
import Switch from './Switch'
import React from 'react';
import { useTranslation } from 'react-i18next';

function ThresholdCard (props) {
    const {t} = useTranslation();
    return (
        <Card>
            <Card.Header>{props.dataObj.SubType}</Card.Header>
            <Card.Body>

                    <Stack direction="horizontal" gap={2}>
                        <Form.Label style={{fontSize: '14px', textAlign: 'center'}}>{t('LAN_LOWER_LIMIT')}</Form.Label>
                        <Form.Control id={props.dataObj.SubType + '_' + 'lowerLimit'} type='Number' step="0.1" style={{fontSize: '34px', width:'130px'}} className="me-auto" 
                                    defaultValue={props.dataObj.LowerLimit} placeholder={props.unit} onChange={props.onChange} />
                        <Form.Label style={{fontSize: '14px', textAlign: 'center'}}>{t('LAN_UPPER_LIMIT')}</Form.Label>
                        <Form.Control id={props.dataObj.SubType + '_' + 'upperLimit'} type='Number' step="0.1" style={{fontSize: '34px', width:'130px'}} className="me-auto" 
                                    defaultValue={props.dataObj.UpperLimit} placeholder={props.unit} onChange={props.onChange} />
                        <Form.Label style={{fontSize: '14px', textAlign: 'center'}}>{t('LAN_WARN_LEVEL')}</Form.Label>
                        <Form.Control id={props.dataObj.SubType + '_' + 'warningLevel'} type='Number' style={{fontSize: '34px', width:'130px'}} className="me-auto" 
                                    defaultValue={props.dataObj.WarningLevel} placeholder='%' onChange={props.onChange} />
                        <div className="vr" />
                        <Switch pid={props.dataObj.SubType + '_' + 'enabled'} value={props.dataObj.Enabled} onChange={props.onChange} />
                    </Stack>

            </Card.Body>
        </Card>
    )
}
export default ThresholdCard;