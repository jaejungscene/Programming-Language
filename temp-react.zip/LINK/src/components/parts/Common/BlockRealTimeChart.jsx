import React, { useEffect, useState } from 'react'
import LineChart from './Chart/LineChart';
import { useTranslation } from 'react-i18next';

function BlockRealTimeChart(props) {
    let values = [];
    let legends = [];

    const { t } = useTranslation();
    const [xData, setXData] = useState([]);
    const [yData, setYData] = useState([]);

    const addData = (x, y) => {
        if (yData.length > 600) {

            shiftFirstElements(yData, 2);
            shiftFirstElements(xData, 2);
            
            setYData(yData);
            setXData(xData);
        }
        setYData(prev => [...prev, y]);
        setXData(prev => [...prev, x]);
    }

    const [chartOptions, setChartOptions] = useState({
        title: {
            show: true,
            textStyle: {
                color: '#0d6efd',
                fontSize: '30px'
            },
            text: `No Data`,
            left: 'center',
            top: 'center'
        },
    });

    
    useEffect(() => {
        setXData([]);
        setYData([]);
        legends = props.viewInfo.map(info => info.ParameterName);
        setChartOptions(getRealTimeOption(xData, yData, legends));
    }, [props.viewInfo]);

    useEffect(() => {
        if (props.viewData !== undefined) {
            legends = [];
            values = [];
            legends = props.viewInfo.map(info => info.ParameterName);

            for(var totalData of props.viewData)
            {
                values = totalData.map(data => data.Value);
                addData(new Date(totalData[0].CreDate).toLocaleTimeString().replace(/^\D*/, ""), values);
            }
            setChartOptions(getRealTimeOption(xData, yData, legends));
        }
    }, [props.viewData]);

    function shiftFirstElements(arr, cnt){
        if(cnt === 0){
            return arr;
        }else{
            arr.shift();
            return shiftFirstElements(arr, cnt -1);
        }
    }

    const getRealTimeOption = (xSeriesData, ySeriesData, legends) => {
        let seriesDatas = [];

        for (let i = 0; i < legends.length; i++) {
            seriesDatas.push([]);
        }

        for (let i = 0; i < ySeriesData.length; i++) {
            for (let j = 0; j < legends.length; j++) {
                seriesDatas[j].push(ySeriesData[i][j]);
            }
        }
        const seriesData = seriesDatas.map((data, i) => ({
            name: legends[i],
            type: "line",
            showSymbol: false,
            data: data,
        }));

        if (legends.length <= 1) {
            legends = [];
        }

        let option = {
            title: {
                text: '',
                textStyle: {
                    fontSize: 15,
                  },
                padding: [0, 0, 0, 0], // 상단, 우측, 하단, 좌측 간격
            },
            tooltip: {
                trigger: "axis",
                axisPointer: {
                    type: "cross",
                    label: {
                        backgroundColor: "#283b56"
                    }
                }
            },
            legend: {
                icon: 'rect',
                itemWidth:12,
                itemHeight:12,
                data: legends,
                top: 2,
                left:70,
                textStyle: {
                    align:'left'
                }
            },
            toolbox: {
                show: false,
                feature: {
                    dataView: { readOnly: false },
                    restore: {},
                    saveAsImage: {}
                }
            },
            grid: {
                // top:(parseInt(props.chartHeight) - 30) + 'px'
                top:25,
                left:70,
                right:65,
                bottom:30,
                width:'auto',
                height:'auto'
            },
            xAxis: [
                {
                    type: "category",
                    name: "[" + t("LAN_TIME")  + "]",
                    boundaryGap: true,
                    markPoint: {
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff"
                                }
                            }
                        },
                    },
                    data: xSeriesData,
                    axisLine: {
                        onZero: false
                    },
                    axisLabel: {
                        showMinLabel: true,
                        showMaxLabel: true,
                        interval: 100
                    }
                }
            ],
            yAxis: [
                {
                    type: "value",
                    scale: true,
                    max: function (value) {
                        // max/min 계산식 관련 형태 조정 진행 정리 필요 hr.kwon98
                        if (typeof value.max !== "undefined") {
                            let numLength = parseInt(value.max - value.min).toString().length;
                            numLength = numLength > 1 ? 10 ** (numLength - 1) : 1;
                            return (value.max + numLength).toFixed(0);
                        }
                        else {
                            return value.max;
                        }
                    },
                    min: function (value) {
                        if (typeof value.min !== "undefined") {
                            let numLength = parseInt(value.max - value.min).toString().length;
                            numLength = numLength > 1 ? 10 ** (numLength - 1) : 1;
                            return (value.min - numLength).toFixed(0);
                        }
                        else {
                            return value.min;
                        }
                    },
                    axisLabel: {
                        showMaxLabel: true,
                        showMinLabel: true,
                    },
                    splitNumber: 3
                }
            ],
            animation: false,
            left : '0',
            series: seriesData
        };
        return option;
    };

    return (
        <div style={{ display: 'block', position:'relative', height:'90px', width:'100%' }}>
            <LineChart options={chartOptions} width={props.chartWidth} height={props.chartHeight}></LineChart>
        </div>
    )
}

export default BlockRealTimeChart