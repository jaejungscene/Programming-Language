import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import DryZoneDataItem from './DryZoneDataItem';
import Carousel from 'react-bootstrap/Carousel';
import { faCircleLeft } from '@fortawesome/free-solid-svg-icons';
import { faCircleRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useTranslation } from 'react-i18next';


function DryZoneItem(props) {

    const { t } = useTranslation();
    
    let viewDataList = [];
    let viewDataItem = [];

    for (let i = 0; i < props.viewData.length; i++) {
        viewDataItem.push(props.viewData[i]);


        if (viewDataItem.length === 4) {
            viewDataList.push(viewDataItem);
            viewDataItem = [];
        }
    }

    if(viewDataItem.length !== 0){        
        viewDataList.push(viewDataItem);
    }
    

    return (
        <Observer>
            {() => (
                <div>
                    <Row>
                        <Col sm={12}>
                            <Carousel
                                variant="dark"
                                indicators={false}
                                interval={props.interval}
                                prevIcon={<FontAwesomeIcon color='black' size='2x' icon={faCircleLeft} />}
                                nextIcon={<FontAwesomeIcon color='black' size='2x' icon={faCircleRight} />}
                            >
                                {viewDataList.map((data) => {
                                    return (
                                        <Carousel.Item>
                                            <Row>
                                                <Col><DryZoneDataItem onClick={props.onClick} viewData={data[0]} title={[t('LAN_FAN_RPM'), t('LAN_ELECTRIC_CURRENT'), t('LAN_PRESSURE')]} inputTitle={[t('LAN_DRY_EXHAUST_FAN'), t('LAN_DRY_SUPPLY_FAN'), t('LAN_PRESSURE')]} defaultTitle={t('LAN_DRY_ZONE')}></DryZoneDataItem></Col>
                                                <Col><DryZoneDataItem onClick={props.onClick} viewData={data[1]} title={[t('LAN_FAN_RPM'), t('LAN_ELECTRIC_CURRENT'), t('LAN_PRESSURE')]} inputTitle={[t('LAN_DRY_EXHAUST_FAN'), t('LAN_DRY_SUPPLY_FAN'), t('LAN_PRESSURE')]} defaultTitle={t('LAN_DRY_ZONE')}></DryZoneDataItem></Col>
                                                <Col><DryZoneDataItem onClick={props.onClick} viewData={data[2]} title={[t('LAN_FAN_RPM'), t('LAN_ELECTRIC_CURRENT'), t('LAN_PRESSURE')]} inputTitle={[t('LAN_DRY_EXHAUST_FAN'), t('LAN_DRY_SUPPLY_FAN'), t('LAN_PRESSURE')]} defaultTitle={t('LAN_DRY_ZONE')}></DryZoneDataItem></Col>
                                                <Col><DryZoneDataItem onClick={props.onClick} viewData={data[3]} title={[t('LAN_FAN_RPM'), t('LAN_ELECTRIC_CURRENT'), t('LAN_PRESSURE')]} inputTitle={[t('LAN_DRY_EXHAUST_FAN'), t('LAN_DRY_SUPPLY_FAN'), t('LAN_PRESSURE')]} defaultTitle={t('LAN_DRY_ZONE')}></DryZoneDataItem></Col>
                                            </Row>
                                        </Carousel.Item>
                                    )

                                })}
                            </Carousel>
                        </Col>

                    </Row>
                </div>

            )}
        </Observer>
    )
}

export default DryZoneItem;
