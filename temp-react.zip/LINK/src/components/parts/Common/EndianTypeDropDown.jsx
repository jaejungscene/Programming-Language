
import Form from 'react-bootstrap/Form';
import { Observer } from 'mobx-react';



function EndianTypeDropDown(props) {

    const onchange = (e) => {
        props.onChange(e);
    }

    return (
        <Observer>
            {() => (
                <Form.Select size="sm" style={{ width: '200px' }} value={props.value} onChange={onchange}>
                    <option value="0">Little</option>
                    <option value="1">Big</option>
                </Form.Select>
            )}
        </Observer>
    );
}

export default EndianTypeDropDown;