
import Form from 'react-bootstrap/Form';
import { Observer } from 'mobx-react';

function EquipmentTypeDropDown(props) {

    const onchange = (e) => {
        props.onChange(e);
    }

    return (
        <Observer>
            {() => (
                <Form.Select size="sm" style={{ width: '220px' }} value={props.value} onChange={onchange}>
                    <option value="001">Coater</option>
                    <option value="002">Roll Press</option>
                    <option value="003">Slitter</option>
                    <option value="004">Drying</option>
                </Form.Select>
            )}
        </Observer>
    );
}

export default EquipmentTypeDropDown;