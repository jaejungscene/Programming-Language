import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleCheck } from '@fortawesome/free-solid-svg-icons'
import { faBan } from '@fortawesome/free-solid-svg-icons'
import Col from 'react-bootstrap/Col';
function ConnectCondition(props) {
    if(props.visible){
        if (props.value) {
            return (
                <>
                    <Col>
                        <FontAwesomeIcon color='green' size='2x' icon={faCircleCheck} />
                    </Col>
                    <Col>
                        {/* Todo Change variable*/}
                        <h5>Success</h5>
                    </Col>
                </>
            );
        }
    
        return (
            <>
                <Col>
                    <FontAwesomeIcon color='red' size='2x' icon={faBan} />
                </Col>
                <Col>
                    {/* Todo Change variable*/}
                    <h5>Failed</h5>
                </Col>
            </>
        );
    }
  
}

export default ConnectCondition;