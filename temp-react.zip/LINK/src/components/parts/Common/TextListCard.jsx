import { useTranslation } from 'react-i18next';
import React, { useEffect, useState, useRef } from 'react';
import Card from 'react-bootstrap/Card';

function TextListCard (props) {
    const { t } = useTranslation();

    const reg = [
        new RegExp(/pressure/ig), 
        new RegExp(/temperature/ig), 
        new RegExp(/fan/ig),
        new RegExp(/servomotor/ig),
        new RegExp(/dancer/ig),
        new RegExp(/pickup/ig)
    ];
    const title = [
        "LAN_PRESSURE", 
        "LAN_TEMPERATURE", 
        "LAN_FAN_RPM",
        "LAN_SERVO_MOTOR",
        "LAN_DANCER_ROLL",
        "LAN_PICKUP_ROLL"
    ];

    const prettyReplace = (str) => {
        switch (str) {
            case "Temperature(Plate)":
                return "LAN_PLATE";

            case "Temperature(Room)":
                return "LAN_ROOM";
            
            case "Diff_Pressure":
                return "LAN_DIFF_PRESSURE";

            case "SupplyFan Air Speed":
                return "LAN_DRY_SUPPLY_FAN";
            
            case "DancerRoll Position":
                return "LAN_POSITION";

            case "PickupRoll Tension":
                return "LAN_TENSION";

            case "ServoMotor_Load":
                return "LAN_LOAD";
            
            case "ServoMotor_Current":
                return "LAN_ELECTRIC_CURRENT";

            case "NipRoll Pressure_OS":
                return "LAN_PRESSURE_OS";
            
            case "NipRoll Pressure_DS":
                return "LAN_PRESSURE_DS";
        }

        return str;
    }

    const checkErrorItem = (item) => {
        let result = false;
        if (item.dataArray.length > 0) {
            for (let i = item.dataArray.length - 1; i > item.dataArray.length - 30; i--) {
                if (
                    typeof item.UpperErrorThreshold === "undefined" || 
                    typeof item.LowerErrorThreshold === "undefined" ||
                    i < 0
                ) {
                    continue;
                }

                if (
                    parseFloat(item.dataArray[i][0].value) > parseFloat(item.UpperErrorThreshold) ||
                    parseFloat(item.dataArray[i][0].value) < parseFloat(item.LowerErrorThreshold)
                ) {
                    result = true;
                }
            }
        }

        return result;
    }

    return (
        <Card className="dark-card text-list-card">
            <Card.Header>
                {props.title}
            </Card.Header>

            <Card.Body className="text-list scrollbar">
                {
                    Object.keys(props.viewData).map((key) => {
                        let block = props.viewData[key];

                        if (props.type === "dryer") {
                            return block.map((item) => 
                                <div>
                                    <div class="text-list-block-title">
                                        <b>
                                            {
                                                reg.map((reg, index) => {
                                                    if (reg.test(item.ParameterName) === true) {
                                                        return t(title[index]) + " (" + item.Unit + ")";
                                                    }
                                                })
                                            }
                                        </b>
                                    </div>
                                    <div class="text-list-block-data">
                                        <div>
                                            {t(prettyReplace(item.ParameterName))}
                                        </div>

                                        <div>
                                            {item.dataArray.length > 0 ? item.dataArray[item.dataArray.length - 1][0].value : 0}
                                        </div>
                                    </div>
                                </div>
                            )
                        }
                        else {
                            return block.map((item) => 
                            <div>
                                    <div class="text-list-block-title">
                                        <b>
                                            {
                                                reg.map((reg, index) => {
                                                    if (reg.test(item.ParameterName) === true) {
                                                        return t(title[index]) + " (" + item.Unit + ")";
                                                    }
                                                })
                                            }
                                        </b>
                                    </div>
                                    <div class='text-list-block-data'>
                                        <div class="smaller">
                                            {t(prettyReplace(item.ParameterName))}
                                        </div>

                                        <div class={checkErrorItem(item) === true ? 'activate' : ''}>
                                            {item.dataArray.length > 0 ? item.dataArray[item.dataArray.length - 1][0].value : 0}
                                        </div>
                                    </div>
                                </div>
                            )
                        }

                    })
                }
            </Card.Body>
        </Card>
    )
}


export default TextListCard