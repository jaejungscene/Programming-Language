import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import { useState, useEffect } from 'react';
import { useObserver } from 'mobx-react';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import Badge from 'react-bootstrap/Badge';
import LineChart from './Chart/LineChart';

const styles = styled.div`
${``/*.table {
    height: 370px;
    width: 100%;
    tbody {
        height: 340px;
        table-layout: fixed;
        display: block;
        overflow-y: auto;
        overflow-x: hidden;
    }

    thead, tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
    }
}
*/}
height: 370px;
overflow-y: scroll;
`

function TrendCard(props) {
    const { t } = useTranslation();    

    const styles = {
        badge: {
            float: 'right',
            fontSize: '0.9rem',
            cursor: 'pointer'
        }
    };


    return useObserver(() => (
        <Container fluid>
            <Row id='body' style={{ padding: '0px' }}>
                <Col>
                <Card style={{marginTop: '30px', height: '300px'}}>
                        <Card.Header>
                            {t("LAN_TREND_ANALYSIS")}
                        <Badge bg="secondary" style={styles.badge}>{props.viewData.statisticValue.ParameterName}</Badge>
                        </Card.Header>
                        <Card.Body>
                            <Stack direction="horizontal" gap={4} style={{marginTop:'10px'}}>
                                <Card style={{ width: '14rem', height: '12rem'}}>
                                    <Card.Body>
                                        <Card.Title>MAX</Card.Title>
                                        <Stack direction='horizontal' gap={2}>
                                            <Card.Text style={{ fontSize: '56px', textAlign: 'center'}}>
                                                {props.viewData.statisticValue.max.toFixed(1)}
                                            </Card.Text>
                                            <Card.Text style={{ fontSize: '26px', textAlign: 'center'}}>{props.unit}</Card.Text>
                                        </Stack>
                                    </Card.Body>
                                </Card>
                                <Card style={{ width: '14rem', height: '12rem'}}>
                                    <Card.Body>
                                    <Card.Title>MIN</Card.Title>
                                    <Stack direction='horizontal' gap={2}>
                                        <Card.Text style={{ fontSize: '56px'}}>
                                            {props.viewData.statisticValue.min.toFixed(1)}
                                        </Card.Text>
                                        <Card.Text style={{ fontSize: '26px'}}>{props.unit}</Card.Text>
                                    </Stack>
                                    </Card.Body>
                                </Card>
                                <Card style={{ width: '14rem', height: '12rem'}}>
                                    <Card.Body>
                                        <Card.Title>AVG</Card.Title>
                                        <Stack direction='horizontal' gap={2}>
                                            <Card.Text style={{ fontSize: '56px', textAlign: 'center'}}>
                                                {props.viewData.statisticValue.avg.toFixed(1)}
                                            </Card.Text>
                                            <Card.Text style={{ fontSize: '26px', textAlign: 'center'}}>{props.unit}</Card.Text>
                                        </Stack>
                                    </Card.Body>
                                </Card>
                                <div className='vr' />
                                <Card style={{ height: '12rem'}}>
                                    <Card.Body>
                                        <LineChart options={props.viewData.chartOption} width='830px' height='180px'></LineChart>
                                    </Card.Body>
                                </Card>                                 
                            </Stack>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

        </Container>
    ));
}

export default TrendCard;