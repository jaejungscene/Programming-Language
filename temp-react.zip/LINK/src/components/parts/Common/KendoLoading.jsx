import React from 'react'
import { Loader } from "@progress/kendo-react-indicators";


//왜 안올라가지 이 파일은 
export default function KendoLoading() {
    return (
        <Loader
            size={"large"}
            style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%,-50%)",
                color: '#0d6efd',
            }}
            type={"converging-spinner"}
        />

    );
}

