import { Observer } from 'mobx-react';

function CurrentTimer({stores}){

    return (
        <Observer>
            {() => (
                <h6>{stores.currentTime}</h6>
            )}
        </Observer>
    );
}

export default CurrentTimer;