import React, { useEffect, useState } from 'react';
import Form from 'react-bootstrap/Form';

function Switch(props) {
    const [switchEnabled, setSwitchEnabled] = useState(false);
    useEffect(() => {
        //setSwitchEnabled(props.value);
    }, []);

    const toggleSwitch = (e) => {
        setSwitchEnabled(!switchEnabled);
        props.onChange(e);
    }

    return (
        <Form.Check 
            type="switch" 
            id={props.pid} 
            onClick={toggleSwitch} 
            defaultChecked={props.value} 
            checked={props.value} 
            disabled={props.disabled}
            />
    );
}

export default Switch;