import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import DateTimePicker from './Common/DateTimePicker';
import DropDownList from './Common/DropDownList';
import LineChart from './Common/Chart/LineChart';
import Table from './Common/Table'
import {useState, useEffect} from 'react';
import Fetcher from './Common/Fetcher'
import {startOfWeek, subDays} from 'date-fns'
import useStore from '../../stores/useStore'
import { useObserver } from 'mobx-react';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import LoadingSpinner from './Common/Spinner';
import styled from 'styled-components';
import TrendCard from './Common/TrendCard';

const styles = styled.div`
${``/*.table {
    height: 370px;
    width: 100%;
    tbody {
        height: 340px;
        table-layout: fixed;
        display: block;
        overflow-y: auto;
        overflow-x: hidden;
    }

    thead, tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
    }
}
*/}
height: 370px;
overflow-y: scroll;
`

function DrivenDetailView(props){
    const [isLoading, setIsLoading] = useState(false);
    const {t} = useTranslation();    
    const [fromDate, setFromDate] = useState(subDays(new Date(), 7));
    const [toDate, setToDate] = useState(new Date());
    const [selectedItem, setSelectedItem] = useState(0);
    const [options, setOptions] = useState([{value: 0, name: 'All'}]);
    const { headerViewStore } = useStore();
    const [trendDatas, setTrendDatas] = useState([

    ])

    const tableColums = [
        {
            accessor: 'No',
            Header: t("LAN_TABLE_NO"),
            width: '10%'
        },
        {
            accessor: 'Name',
            Header: t("LAN_TABLE_NAME"),
            width: '10%'
        },
        {
            accessor: 'CreDate',
            Header: t("LAN_TABLE_DATE"),
            width: '20%'
        },
        {
            accessor: 'AlarmType',
            Header: t("LAN_TABLE_TYPE"),
            width: '10%'
        },
        {
            accessor: 'Value',
            Header: t("LAN_TABLE_VALUE"),
            width: '10%'
        },
        {
            accessor: 'Message',
            Header: t("LAN_TABLE_MESSAGE"),
            width: '40%'
        }
    ];

    const [historyTableData, setHistoryTableData] = useState([]);

    useEffect (() => {
        initializeComponentDatas();        
    }, []);

    useEffect(()=> {     
        if(props.activeKey === props.moduleType){
            refreshAnalysisData();
        }
    }, [props.activeKey, headerViewStore.selectedEquipmentId]);

    const initializeComponentDatas = async() => {
        let tmpOptions = [options[0]];
        let params = {
            moduleType: props.moduleType
        }
        try{
            const datas = await Fetcher('get', '/getAllModuleInfoList/', {params});            
            for (let data of datas) {
                tmpOptions.push({value:data.SeqId, name:data.ModuleName});
            }
            setOptions(tmpOptions);
        } catch(err) {
            setIsLoading(false);
            console.log(err.message);
        }
    }

    const handleSelect = (e) => {
        setSelectedItem(e.target.value);
    }

    const handleDateTimePicker = (type, date) => {
        if(type == 'from') {
            setFromDate(date);
        }
        else {
            setToDate(date);
        }
    }

    const handleRowSelect = (row) => {
        
    }

    const refreshAnalysisData = async (e) => {
        try{
            setIsLoading(true);
            const datas = await getAnalysisData();
            let newTableData = [];
            datas.alarmHistory.forEach((data, index)=>{
                newTableData.push({
                    No: index+1,
                    Name: data.Name,
                    CreDate: moment(data.CreDate).format("YYYY-MM-DD HH:mm:ss"),
                    AlarmType: data.AlarmType,
                    Value: data.DetailInfo.value + ' MPa',
                    Message: data.AlarmMessage
                });         
            });
            let tmpTrendData = [];
            if(datas.trendData.length !== 0){
                for (let itemsArr of datas.trendData) {
                    for(let trendItem of itemsArr){
                        let tmpTrendItem = {};
                        
                        let statisticData = { min: trendItem.min, max: trendItem.max, avg: trendItem.avg, ParameterName : trendItem.ParameterName };
                        let chartData = new Object();
                        chartData.xAxis = {
                            name : 'Time',
                            boundaryGap: false,
                            axisLabel: {
                                formatter: (function (value) {
                                    return moment(value).format('HH:mm:ss');
                                })
                            },
                            data: datas.timeStamp
                        }
                        chartData.yAxis = {
                            name: '(MPa)',
                            type: 'value',
        
                            max: function (value) {
                                return (value.max * 1.1).toFixed(1);
                            },
                            min: function (value) {
                                return (value.min * 0.9).toFixed(1);
                            },
                        }
                        chartData.series = [];
                        
                        chartData.series.push({
                            name: trendItem.ParameterName,
                            type: 'line',
                            smooth: true,
                            data: trendItem.data,
                        });
                        
                        chartData.tooltip = {
                            trigger: 'axis',
                            formatter: function (params, ticket, callback) {
                                var newDate = new Date(params[0].name);
                                var res = moment(newDate).format("YYYY-MM-DD HH:mm:ss");
                                for (var i = 0, l = params.length; i < l; i++) {
                                    res += '<br/>' + params[i].seriesName + ': ' + params[i].value + 'N';
                                }
                                setTimeout(function () {
                                    callback(ticket, res);
                                }, 100)
                                return 'loading';
                            }
                        };
                        chartData.dataZoom = {
                            show: true,
                            start: 90,
                            end: 100
                        };
                        chartData.grid = {
                            left: '6%',
                            right: '6%',
                            top: 35,
                            bottom: 65,
                            width: 'auto',
                            height: 'auto'
                        };
                        chartData.legend = {
                            type: 'scroll',                    
                            top: 0
                        };
                        tmpTrendItem.statisticValue = statisticData;
                        tmpTrendItem.chartOption = chartData;
                        tmpTrendData.push(tmpTrendItem);
                    }
                }
                

            }
            setTrendDatas(tmpTrendData);
            setHistoryTableData(newTableData);
            setIsLoading(false);
        } catch(err) {
            setIsLoading(false);
            console.log(err.message);
        }
    }

    const getAnalysisData = async () => {
        let params = {
            moduleType: props.moduleType,
            fromDate : fromDate,
            toDate : toDate,
            selectedItemLst : [options[selectedItem].name],
            equipmentID : headerViewStore.selectedEquipmentId
        }
        if (selectedItem == 0){
            var tmpArr = [];
            for (let option of options) {
                if (option.name != 'All') {
                    //tmpArr.push(option.value);
                    tmpArr.push(option.name);
                }
            }
            params.selectedItemLst = tmpArr.splice(0);
        }
        return await Fetcher('get', '/getAnalysisData', {params});
    }

    return useObserver(()=> (
        <Container fluid>
        { isLoading && <LoadingSpinner> </LoadingSpinner>}
            <Row id='body' style={{padding:'10px'}}>
                <Col>
                    <Card>
                        <Card.Header>{t("LAN_SEARCH_KEY")}</Card.Header>
                        <Card.Body>
                            <Stack direction="horizontal" gap={4}>
                                <DateTimePicker from={fromDate} to={toDate} onChangeDate={handleDateTimePicker} />
                                <div className='vr'/>
                                <DropDownList options={options} label={t('LAN_TABLE_ITEM')} width={'300px'} onSelect={handleSelect} />
                                <button title='Search' onClick={refreshAnalysisData}>{t("LAN_SEARCH")}</button>
                            </Stack>
                        </Card.Body>
                    </Card>
                    {
                            trendDatas.map((data) => {
                            return (
                                <Row>
                                    <TrendCard viewData={data} unit = {'MPa'}/>                                    
                                </Row>
                            )

                        })
                    }
                    <Card style={{marginTop: '40px', height: '440px'}}>
                        <Card.Header>{t("LAN_ALARM_HISTORY")}</Card.Header>
                        <Card.Body>
                            <Table columns={tableColums} data={historyTableData} onSelectBatch={handleRowSelect} Styles={styles}/>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            <Row id='footer'>
            </Row>
        </Container>
    ));
}

export default DrivenDetailView;