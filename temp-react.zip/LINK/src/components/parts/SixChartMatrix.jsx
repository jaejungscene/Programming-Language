import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import { useTranslation } from 'react-i18next';
import { TbDeviceDesktopAnalytics } from "react-icons/tb";
import React, { useEffect, useState, useRef } from "react";
import useStore from '../../stores/useStore';
import DashBoardRealTimeChart from './Common/DashBoardRealTimeChart';

function SixChartMatrix() {
    const { t } = useTranslation();
    const { dashBoardStore } = useStore();
    return (
        <div>
            <Row>
                <div style={{ width: '280px', lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft: "30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '5px 5px 0px 0px', margin: '10px 15px 0 35px' }}>
                    <TbDeviceDesktopAnalytics style={{ marginTop: '-5px' }} />
                    &nbsp;&nbsp;&nbsp;{t('LAN_COATING_QUALITY_INFO')}
                </div>
            </Row>


            <Row style={{ margin: '0px 10px 0 10px' }}>
                <Col>
                    <Card style={{ height: '524px', width: '1648px' }}>
                        <Card.Body style={{ paddingTop: '10px' }}>
                            <Stack direction="vertical" gap={0}>
                                <Row style={{ height: '170px' }}>
                                    <Col>
                                        <Card style={{ height: '160px', width: '185px' }}>
                                            <Card.Header>{t('LAN_LOADING_LEVEL')}</Card.Header>
                                            <Card.Body style={{ padding: '10px' }}>
                                                <Stack direction="horizontal">
                                                    <Row>
                                                        <Col>
                                                            <Card style={{ height: '95px', width: '160px' }}>
                                                                <Card.Body style={{ padding: '10px' }}>
                                                                    <Card.Title style={{ fontSize: '17px' }}>{t('LAN_THICKNESS')}</Card.Title>
                                                                    <Stack direction='horizontal' gap={2}>
                                                                        <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                            {dashBoardStore.loadingLevelThicknessChartValue.Value[0] == undefined ? 0 : dashBoardStore.loadingLevelThicknessChartValue.Value[0]}
                                                                        </Card.Text>
                                                                        <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                            um
                                                                        </Card.Text>
                                                                    </Stack>
                                                                </Card.Body>


                                                            </Card>
                                                        </Col>

                                                        {/* <Col>
                                                                    <Card style={{ height: '95px', width: '231px' }}>
                                                                        <Card.Body style={{ padding: '10px' }}>
                                                                            <Card.Title style={{ fontSize: '17px' }}>{t('LAN_DENSITY')}</Card.Title>
                                                                            <Stack direction='horizontal' gap={2}>
                                                                                <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                                    {dashBoardStore.loadingLevelDensityChartValue.Value[0]}
                                                                                </Card.Text>
                                                                                <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                                    mg/mm²
                                                                                </Card.Text>
                                                                            </Stack>
                                                                        </Card.Body>
                                                                    </Card>
                                                                </Col> */}
                                                    </Row>

                                                </Stack>
                                            </Card.Body>
                                        </Card>
                                    </Col>

                                    <Col>
                                        <Card style={{ height: '160px', width: '585px' }} >
                                            <Stack direction='horizontal'>
                                                {<DashBoardRealTimeChart chartWidth={'580px'} chartHeight={'190px'} chartValue={dashBoardStore.loadingLevelThicknessChartValue.Value} legends={dashBoardStore.loadingLevelThicknessChartValue.legends} markLines={dashBoardStore.loadingLevelThicknessChartValue.markLines}></DashBoardRealTimeChart>}
                                                {/* {<DashBoardRealTimeChart chartWidth={'500px'} chartHeight={'190px'} chartValue={dashBoardStore.loadingLevelDensityChartValue.Value} legends = {dashBoardStore.loadingLevelDensityChartValue.legends}></DashBoardRealTimeChart>} */}
                                            </Stack>
                                        </Card>
                                    </Col>
                                    {/* kmw */}
                                    <Col>
                                        <Card style={{ height: '160px', width: '185px' }}>
                                            <Card.Header>{t('LAN_LOADING_LEVEL')}</Card.Header>
                                            <Card.Body style={{ padding: '10px' }}>
                                                <Stack direction="horizontal">
                                                    <Row>
                                                        <Col>
                                                            <Card style={{ height: '95px', width: '160px' }}>
                                                                <Card.Body style={{ padding: '10px' }}>
                                                                    <Card.Title style={{ fontSize: '17px' }}>{t('LAN_DENSITY')}</Card.Title>
                                                                    <Stack direction='horizontal' gap={2}>
                                                                        <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                            {dashBoardStore.loadingLevelDensityChartValue.Value[0] == undefined ? 0 : dashBoardStore.loadingLevelDensityChartValue.Value[0]}
                                                                        </Card.Text>
                                                                        <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                            mg/mm²
                                                                        </Card.Text>
                                                                    </Stack>
                                                                </Card.Body>
                                                            </Card>
                                                        </Col>
                                                    </Row>
                                                </Stack>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card style={{ height: '160px', width: '585px' }} >
                                            <Stack direction='horizontal'>
                                                {<DashBoardRealTimeChart chartWidth={'580px'} chartHeight={'190px'} chartValue={dashBoardStore.loadingLevelDensityChartValue.Value} legends={dashBoardStore.loadingLevelDensityChartValue.legends} markLines={dashBoardStore.loadingLevelDensityChartValue.markLines}></DashBoardRealTimeChart>}
                                            </Stack>
                                        </Card>
                                    </Col>
                                    {/* kmw */}
                                </Row>
                                <Row style={{ height: '170px' }}>
                                    <Col>
                                        <Card style={{ height: '160px', width: '185px' }}>
                                            <Card.Header>{t('LAN_COATING_WIDTH')}</Card.Header>
                                            <Card.Body style={{ padding: '10px' }}>
                                                <Stack direction="horizontal">
                                                    <Row>
                                                        <Col>
                                                            <Card style={{ height: '95px', width: '160px' }}>
                                                                <Card.Body style={{ padding: '10px' }}>
                                                                    <Card.Title style={{ fontSize: '17px' }}>{t('LAN_WIDTH')} 1</Card.Title>
                                                                    <Stack direction='horizontal' gap={2}>
                                                                        <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                            {dashBoardStore.coatingWidthChartValue.Value[0] == undefined ? 0 : dashBoardStore.coatingWidthChartValue.Value[0]}
                                                                        </Card.Text>
                                                                        <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                            mm
                                                                        </Card.Text>
                                                                    </Stack>
                                                                </Card.Body>


                                                            </Card>
                                                        </Col>

                                                        {/* <Col>
                                                                    <Card style={{ height: '95px', width: '231px' }}>
                                                                        <Card.Body style={{ padding: '10px' }}>
                                                                            <Card.Title style={{ fontSize: '17px' }}>{t('LAN_WIDTH')} 2</Card.Title>
                                                                            <Stack direction='horizontal' gap={2}>
                                                                                <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                                    {dashBoardStore.coatingWidthChartValue.Value[1]}
                                                                                </Card.Text>
                                                                                <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                                    mm
                                                                                </Card.Text>
                                                                            </Stack>
                                                                        </Card.Body>
                                                                    </Card>
                                                                </Col> */}
                                                    </Row>

                                                </Stack>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card style={{ height: '160px', width: '585px' }} >
                                            {<DashBoardRealTimeChart chartWidth={'580px'} chartHeight={'190px'} chartValue={dashBoardStore.coatingWidthChartValue.Value} legends={dashBoardStore.coatingWidthChartValue.legends} markLines={dashBoardStore.coatingWidthChartValue.markLines}></DashBoardRealTimeChart>}
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card style={{ height: '160px', width: '185px' }}>
                                            <Card.Header>{t('LAN_NON_COATING_WIDTH')}</Card.Header>
                                            <Card.Body style={{ padding: '10px' }}>
                                                <Stack direction="horizontal">
                                                    <Row>
                                                        <Col>
                                                            <Card style={{ height: '95px', width: '160px' }}>
                                                                <Card.Body style={{ padding: '10px' }}>
                                                                    <Card.Title style={{ fontSize: '17px' }}>{t('LAN_WIDTH')} 1</Card.Title>
                                                                    <Stack direction='horizontal' gap={2}>
                                                                        <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                            {dashBoardStore.nonCoatingWidthChartValue.Value[0] == undefined ? 0 : dashBoardStore.nonCoatingWidthChartValue.Value[0]}
                                                                        </Card.Text>
                                                                        <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                            mm
                                                                        </Card.Text>
                                                                    </Stack>
                                                                </Card.Body>


                                                            </Card>
                                                        </Col>

                                                        {/* <Col>
                                                                    <Card style={{ height: '95px', width: '145px' }}>
                                                                        <Card.Body style={{ padding: '10px' }}>
                                                                            <Card.Title style={{ fontSize: '17px' }}>{t('LAN_WIDTH')} 2</Card.Title>
                                                                            <Stack direction='horizontal' gap={2}>
                                                                                <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                                    {dashBoardStore.nonCoatingWidthChartValue.Value[1]}
                                                                                </Card.Text>
                                                                                <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                                    mm
                                                                                </Card.Text>
                                                                            </Stack>
                                                                        </Card.Body>
                                                                    </Card>
                                                                </Col> */}

                                                        {/* <Col>
                                                                    <Card style={{ height: '95px', width: '145px' }}>
                                                                        <Card.Body style={{ padding: '10px' }}>
                                                                            <Card.Title style={{ fontSize: '17px' }}>{t('LAN_WIDTH')} 3</Card.Title>
                                                                            <Stack direction='horizontal' gap={2}>
                                                                                <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                                    {dashBoardStore.nonCoatingWidthChartValue.Value[2]}
                                                                                </Card.Text>
                                                                                <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                                    mm
                                                                                </Card.Text>
                                                                            </Stack>
                                                                        </Card.Body>
                                                                    </Card>
                                                                </Col> */}
                                                    </Row>

                                                </Stack>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card style={{ height: '160px', width: '585px' }} >
                                            {<DashBoardRealTimeChart chartWidth={'580px'} chartHeight={'190px'} chartValue={dashBoardStore.nonCoatingWidthChartValue.Value} legends={dashBoardStore.nonCoatingWidthChartValue.legends} markLines={dashBoardStore.nonCoatingWidthChartValue.markLines}></DashBoardRealTimeChart>}
                                        </Card>
                                    </Col>
                                    {/* kmw */}

                                    {/* kmw */}
                                </Row>
                                <Row style={{ height: '170px' }}>
                                    <Col>
                                        <Card style={{ height: '160px', width: '185px' }}>
                                            <Card.Header>{t('LAN_WRINKLE')}</Card.Header>
                                            <Card.Body style={{ padding: '10px' }}>
                                                <Stack direction="horizontal">
                                                    <Row>
                                                        <Col>
                                                            <Card style={{ height: '95px', width: '160px' }}>
                                                                <Card.Body style={{ padding: '10px' }}>
                                                                    <Card.Title style={{ fontSize: '17px' }}>{t('LAN_WRINKLE')}</Card.Title>
                                                                    <Stack direction='horizontal' gap={2}>
                                                                        <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                            {dashBoardStore.wrinkleChartValue.Value[0] == undefined ? 0 : dashBoardStore.wrinkleChartValue.Value[0]}
                                                                        </Card.Text>
                                                                        <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                            mm
                                                                        </Card.Text>
                                                                    </Stack>
                                                                </Card.Body>
                                                            </Card>
                                                        </Col>


                                                    </Row>

                                                </Stack>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card style={{ height: '160px', width: '585px' }} >
                                            <Stack direction='horizontal'>
                                                {<DashBoardRealTimeChart chartWidth={'580px'} chartHeight={'190px'} chartValue={dashBoardStore.wrinkleChartValue.Value} legends={dashBoardStore.wrinkleChartValue.legends} markLines={dashBoardStore.wrinkleChartValue.markLines}></DashBoardRealTimeChart>}
                                            </Stack>
                                        </Card>
                                    </Col>

                                    {/* kmw */}
                                    <Col>
                                        <Card style={{ height: '160px', width: '185px' }}>
                                            <Card.Header>{t('LAN_AB_GAP')}</Card.Header>
                                            <Card.Body style={{ padding: '10px' }}>
                                                <Stack direction="horizontal">
                                                    <Row>
                                                        <Col>
                                                            <Card style={{ height: '95px', width: '160px' }}>
                                                                <Card.Body style={{ padding: '10px' }}>
                                                                    <Card.Title style={{ fontSize: '17px' }}>{t('LAN_AB_GAP')}</Card.Title>
                                                                    <Stack direction='horizontal' gap={2}>
                                                                        <Card.Text style={{ height: '30px', fontSize: '28px', textAlign: 'center' }}>
                                                                            {dashBoardStore.abGapChartValue.Value[0] == undefined ? 0 : dashBoardStore.abGapChartValue.Value[0]}
                                                                        </Card.Text>
                                                                        <Card.Text style={{ height: '30px', fontSize: '20px', textAlign: 'center', paddingTop: '4px' }}>
                                                                            mm
                                                                        </Card.Text>
                                                                    </Stack>
                                                                </Card.Body>
                                                            </Card>
                                                        </Col>
                                                    </Row>
                                                </Stack>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card style={{ height: '160px', width: '585px' }} >
                                            <Stack direction='horizontal'>
                                                {<DashBoardRealTimeChart chartWidth={'580px'} chartHeight={'190px'} chartValue={dashBoardStore.abGapChartValue.Value} legends={dashBoardStore.abGapChartValue.legends} markLines={dashBoardStore.abGapChartValue.markLines}></DashBoardRealTimeChart>}
                                            </Stack>
                                        </Card>
                                    </Col>
                                    {/* kmw */}
                                </Row>
                            </Stack>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </div>
    )
}

export default SixChartMatrix
