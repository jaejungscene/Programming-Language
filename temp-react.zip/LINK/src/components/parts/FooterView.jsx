function FooterView(){
    return (
        <div>
            푸터입니다.
        </div>
    );
}

export default FooterView;