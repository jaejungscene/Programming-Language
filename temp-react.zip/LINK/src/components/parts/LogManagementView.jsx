
function LogManagementView(){

    return (
        <article className="article_pms">
            로그관리뷰 입니다.
        </article>
    );

}

export default LogManagementView;