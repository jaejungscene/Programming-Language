import React from 'react';
import { useObserver } from 'mobx-react';
import useStore from '../../stores/useStore';


const CounterComponent = () => {

  //hook이라고 하는데 ㅡ.ㅡ...
  const { counterStore } = useStore();

  return useObserver(() => (
    <div>
      <h1>{counterStore.number}</h1>
      <button onClick={() =>counterStore.increase()}>+1</button>
      <button onClick={() => counterStore.decrease()}>-1</button>
      <button onClick={() => counterStore.clear()}>clear</button>
    </div>
  ))


}

export default CounterComponent;