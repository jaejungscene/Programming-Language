import { Link, useLocation } from "react-router-dom";
import { useRef, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { BsSearch } from "react-icons/bs";
import { FiWind } from "react-icons/fi";
import { AiOutlineTool, AiOutlineDashboard } from "react-icons/ai"
import { IoConstructOutline } from "react-icons/io5"
import { BiPlus, BiMinus } from "react-icons/bi";
import { GiRolledCloth, GiRailway, GiBandageRoll } from "react-icons/gi";

import Fetcher from './Common/Fetcher';
import useStore from '../../stores/useStore';

function Sidebar() {

    const sideMenuRef = useRef(null);
    const sessionStorage = window.sessionStorage;
    const [toggle, setToggle] = useState(null);
    const [dashBoardToggle, setdashBoardToggle] = useState(true);
    const { mainViewStore } = useStore();    

    const history = useLocation();
    const { t } = useTranslation();


    const menuChangedEvent = (e) => {

        removeSelectedSidebar();

        e.target.classList.add("on");
    };

    const onClickHifacPas = () => {
        const currentLocation = window.location;
        const pasUrl = `${currentLocation.protocol}//${currentLocation.hostname}:${3100}/dashboard`;
        let param = {};

        mainViewStore.getAuthorizeToken();
        param.loginUser = mainViewStore.loginUser;
        param.authorizeToken = mainViewStore.authorizeToken;

        const expireCookie = new Date();
        expireCookie.setSeconds(expireCookie.getSeconds() + 10);

        let cookieString = "login=";
        cookieString += JSON.stringify(param);
        cookieString += "; ";
        cookieString += `expires=${expireCookie.toUTCString()} domain=${currentLocation.protocol}//${currentLocation.hostname}; path=/`;

        document.cookie = cookieString;
        window.open(pasUrl, "_blank");
    }

    const onClickHifacQms = () => {
        const currentLocation = window.location;
        const pasUrl = `${currentLocation.protocol}//${currentLocation.hostname}:${3200}/dashboard`;
        let param = {};

        mainViewStore.getAuthorizeToken();
        param.loginUser = mainViewStore.loginUser;
        param.authorizeToken = mainViewStore.authorizeToken;

        const expireCookie = new Date();
        expireCookie.setSeconds(expireCookie.getSeconds() + 10);

        let cookieString = "login=";
        cookieString += JSON.stringify(param);
        cookieString += "; ";
        cookieString += `expires=${expireCookie.toUTCString()} domain=${currentLocation.protocol}//${currentLocation.hostname}; path=/`;

        document.cookie = cookieString;
        window.open(pasUrl, "_blank");
    }


    useEffect(() => {

        function getToggleStatus() {
            let savedToggle = sessionStorage.getItem('sidebarToggle');
            let dashBoardSavedToggle = sessionStorage.getItem('dashBoardToggle');
            savedToggle = JSON.parse(savedToggle);
            dashBoardSavedToggle = JSON.parse(dashBoardSavedToggle);
            if (savedToggle === null || savedToggle === undefined) {
                setToggle(false);
            }
            else {
                setToggle(savedToggle);
            }

            if (dashBoardSavedToggle === null || dashBoardSavedToggle === undefined) {
                setdashBoardToggle(false);
            }
            else {
                setdashBoardToggle(dashBoardSavedToggle);
            }
        }

        getToggleStatus();
        removeSelectedSidebar();

        let root = history.pathname;
        let bound = sideMenuRef.current.children.length;        
        for (let index = 0; index < bound; index++) {
            let item = sideMenuRef.current.children[index];            
            let elementId = item.children[0].id;
            if (root.includes(elementId)) {
                item.children[0].classList.add("on");
            }
        }

    }, [history, toggle, sessionStorage, dashBoardToggle])

    function removeSelectedSidebar(){
        let bound = sideMenuRef.current.children.length;
        for (let index = 0; index < bound; index++) {
            let item = sideMenuRef.current.children[index];
            item.children[0].classList.remove("on");
        }
    }

    function setDashBoardToggleEvent(){
        setdashBoardToggle(!dashBoardToggle);
        sessionStorage.setItem('dashBoardToggle', !dashBoardToggle);
    }

    function setAnalysisToggleEvent() {
        setToggle(!toggle);
        sessionStorage.setItem('sidebarToggle', !toggle);
    }  

    const devTestClick = async () => {
        await Fetcher('get', '/httpAPI/devTestEvent');
    };

    return (
        <aside className="sidebar">
            <div>
                <nav className="pm_nav">
                    <ul ref={sideMenuRef}>
                        <li className={dashBoardToggle === true ? "active-toggle-li" : ""}>
                            <a id="dashboard" onClick={setDashBoardToggleEvent} >
                                <i><AiOutlineDashboard className="menu-icon" /></i>
                                {t('LAN_DASHBOARD')}
                                {dashBoardToggle === false ?
                                    <BiPlus className="sidebar-toggle"></BiPlus> :
                                    <BiMinus className="sidebar-toggle"></BiMinus>}
                            </a>
                        </li>
                        {
                            dashBoardToggle &&
                            <li>
                                <Link  to="/dashboard/trendMonitoring" id="trendMonitoring" onClick={menuChangedEvent} style={{ marginLeft: "15px" }}>
                                    <div style={{ fontSize: "12px" }}>
                                        <i><AiOutlineDashboard className="menu-icon" /></i>
                                        {t('LAN_REALTIME_MONITORING')}
                                    </div>
                                </Link>
                            </li>
                        }
                        {
                            dashBoardToggle &&
                            <li>
                                <Link  to="/dashboard/ipMonitoring" id="ipMonitoring" onClick={menuChangedEvent} style={{ marginLeft: "15px" }}>
                                    <div style={{ fontSize: "12px" }}>
                                        <i><AiOutlineDashboard className="menu-icon" /></i>
                                        {t('LAN_IP_MONITORING')}
                                    </div>
                                </Link>
                            </li>
                        }
                        
                        <li>
                            <a id="hifacpas" href={void(0)} onClick={onClickHifacPas}>
                                <i><IoConstructOutline className="menu-icon"/></i>
                                HIFAC PAS
                            </a>
                        </li>
                        <li>
                            <a id="hifacpas" href={void(0)} onClick={onClickHifacQms}>
                                <i><AiOutlineTool className="menu-icon" /></i>
                                HIFAC QMS
                            </a>
                        </li>
                        <li className={toggle === true ? "active-toggle-li" : ""}>
                            <a id="monitoring" onClick={setAnalysisToggleEvent} >
                                <i><BsSearch className="menu-icon"></BsSearch></i>
                                {t('LAN_DATA_ANALYSIS')}
                                {toggle === false ?
                                    <BiPlus className="sidebar-toggle"></BiPlus> :
                                    <BiMinus className="sidebar-toggle"></BiMinus>}
                            </a>
                        </li>
                        {
                            toggle &&
                            <li>
                                <Link to='/monitoring/dryZone' id="dryZone" onClick={menuChangedEvent} style={{ marginLeft: "15px" }}>
                                    <div style={{ fontSize: "12px" }}>
                                        <i><FiWind className="menu-icon-small"></FiWind></i>
                                        {t('LAN_DRY_ZONE_UNIT')}
                                    </div>
                                </Link>
                            </li>
                        }
                        {
                            toggle &&
                            <li>
                                <Link to='/monitoring/drivingParts' id="drivingParts" onClick={menuChangedEvent} style={{marginLeft : '15px'}}>
                                    <div style={{fontSize : '12px'}}>
                                    <span style={{ position:"relative", left:"-2px" }}>
                                        <i>
                                            <GiRailway style={{ fontSize: "22px", marginRight: "10px" }}></GiRailway>
                                            <GiRolledCloth style={{ fontSize: "17px", position:"absolute", top:"1", left: "2px" }}></GiRolledCloth>
                                        </i>
                                        {t('LAN_DRIVEN_PARTS_ANALYSIS')}
                                        </span>
                                    </div>
                                </Link>
                        </li>
                        }                        
                    </ul>
                </nav>
            </div>
            <div className="footer" onClick={devTestClick}>
                <div className="copyright">Copyright ⓒ 2023</div>
                <div className="hanhwa">Hanhwa Momentum Co.,Ltd.</div>
                <div className="all rights">All rights Reserved</div>
                <div className="ver">(version 1.0.0)</div>
            </div>
        </aside>
    );
}

export default Sidebar;