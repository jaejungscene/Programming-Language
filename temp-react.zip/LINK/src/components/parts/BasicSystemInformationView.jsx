import MachineAgentView from "./MachineAgentView";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import React, { useEffect, useState, useRef } from "react";
import { useTranslation } from 'react-i18next';
import Accordion from 'react-bootstrap/Accordion';
import PLCView from "./PLCView";


function BasicSystemInformationView() {

    const { t } = useTranslation();
    useEffect(() => {

    }, []);

    return (
        <div class="page-inner-container">
            <Col>
                <Accordion defaultActiveKey={['1', '2']} alwaysOpen>
                    {/**System Management */}
                    {/* <Accordion.Item eventKey="0">
                        <Accordion.Button style={{ margin: '0' }}>{t('NOT_USED_SYSTEM_LIST')}</Accordion.Button>
                        <Accordion.Body>
                            <Row>
                                <Col sm={8} style={{ marginRight: "0px", paddingRight: "0px" }}>
                                    System List
                                </Col>
                                <Col sm={4} style={{ marginRight: "0px", paddingRight: "0px", paddingTop: "10px" }}>
                                    System Info
                                </Col>
                            </Row>
                        </Accordion.Body>
                    </Accordion.Item> */}
                    {/**PLC Management */}
                    <Accordion.Item eventKey="1">
                        <Accordion.Button style={{ margin: '0' }}>{t('LAN_EQUIPMENT_PLC_LIST')}</Accordion.Button>
                        <Accordion.Body>
                            <Row>
                                <PLCView plcChanged={() => {}} />
                            </Row>
                        </Accordion.Body>
                    </Accordion.Item>
                    {/**MachineAgent Management */}
                    <Accordion.Item eventKey="2">
                        <Accordion.Button style={{ margin: '0' }}>{t('LAN_MA_LIST')}</Accordion.Button>
                        <Accordion.Body>
                            <Row>
                                <MachineAgentView />
                            </Row>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
            </Col>
        </div>
    );
}


export default BasicSystemInformationView;