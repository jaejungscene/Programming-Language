import ProtocolView from "./ProtocolView";
import EquipmentListView from "./EquipmentListView";
import PLCListView from "./PLCListView";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import useStore from '../../stores/useStore';
import React, { useEffect, useState, useRef } from "react";
import CurrentTimer from "./Common/CurrentTimer";
import swal from 'sweetalert2';
import AddEquipmentView from "../views/AddEquipmentView"
import { useTranslation } from 'react-i18next';
import Accordion from 'react-bootstrap/Accordion';
import PLCInformationView from "./PLCInformationView";


function EquipmentManagementView() {

    const { equipmentManagementStore, protocolStore, equipmentListStore, currentTimerStore, mainViewStore, plcManagementStore } = useStore();

    const [equipmentListStatus, setEquipmentListStatus] = useState(null);
    const [sysInfoStatus, setSysInfoStatus] = useState(null);
    const [addEquipmentViewShow, setaddEquipmentViewShow] = React.useState(false);
    const [plcListStatus, setPlcListStatus] = useState(false);

    const { t } = useTranslation();

    //useref가 같은 거라 이벤트가 동일하게 먹히네!!!!!!!!!!!!!
    const equipmentListViewRef = useRef();
    const plcListViewRef = useRef();

    useEffect(() => { 
        
        protocolInitialize();
        equipmentInitialize();
        currentTimerStore.initialize();
        plcInitialize();

    }, [equipmentManagementStore, currentTimerStore, protocolStore, plcManagementStore, equipmentListStore, equipmentListViewRef, plcListViewRef]);

    const plcInitialize = async () => {
        await plcManagementStore.initializePlcManagementListStore();
        setPlcListStatus(true);
    }

    const protocolInitialize = async () => {
        await protocolStore.initialize();
        setSysInfoStatus(true);
    }

    const equipmentInitialize = async () => {
        //await equipmentListStore.initialize(mainViewStore.webSocket);
        await equipmentListStore.initialize(mainViewStore.getWebsocket());
        setEquipmentListStatus(true);
    }

    const onDeleteEquipment = async () => {
        let result = await equipmentManagementStore.onDeleteEquipment();
        let isRunning = equipmentManagementStore.equipmentIsRunning();

        if(result === undefined){
            swal.fire({
                title: t('MSG_EQUIPMENT_SELECT'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
        }
        else{
            /**구동중인 설비는 삭제 불가 */
            if(isRunning){
                swal.fire({
                    title: t('MSG_RUNNING_EQUIPMENT_DELETE_ERROR'),
                    text: "",
                    icon: "error",
                    confirmButtonText: "OK"
                });                
            }
            else{
                if (result) {
                    swal.fire({
                        title: t('MSG_EQUIPMENT_DELETE_SUCCESS'),
                        text: "",
                        icon: "success",
                        confirmButtonText: "OK"
                    });
        
                    equipmentInitialize();
                    clearEquipmentList();
                }
                else {
                    swal.fire({
                        title: t('MSG_EQUIPMENT_DELETE_FAIL'),
                        text: "",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                }
            }
        }
    }

    const onSave = async () => {
        let eqpResult = await equipmentListStore.saveEquipment();

        let protocolResult = await protocolStore.saveSystemInfo();
        if (protocolResult || eqpResult) {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    function clearEquipmentList(){
        for (let item of equipmentListViewRef.current.children) {
            if (item.className === 'table-active') {
                item.classList.remove('table-active');                
            }      
        }        
    }

    return (
        <div style={{ margin: '10px', backgroundColor: 'white' }}>
            <Row>
                <Col style={{ margin: "10px" }}>
                    <h5>{t('LAN_STANDARD_MANAGEMENT')}</h5>
                    <hr />
                </Col>
            </Row>
            <Row>
                {sysInfoStatus && <ProtocolView stores={protocolStore} />}
            </Row>
            <Row>
                <Col style={{ margin: "10px", marginRight:"0px", paddingRight:"0px" }}>
                    <hr />
                        <h5 style={{ height: '40px', display:'flex', alignItems:'center' }}>
                            {t('LAN_EQUIPMENT_LIST')}                            
                        </h5>
                </Col>

                <Col style={{ margin: "10px", marginLeft:"0px", paddingLeft:"0px" }}>
                    <hr />
                    <h5 style={{ height: '40px', display:'flex', alignItems:'center', float:"right" }}>
                        <Button style={{ float: 'right', margin: '5px' }} onClick={() => setaddEquipmentViewShow(true)}>+</Button>
                        <Button style={{ float: 'right', margin: '5px' }} onClick={() => onDeleteEquipment()}>-</Button>
                    </h5>
                    
                </Col>
            </Row>
            <Row>
                {equipmentListStatus && <EquipmentListView ref={equipmentListViewRef} stores={equipmentListStore} selectedEquipment={(index,state) => { equipmentManagementStore.onChangeSelectedEquipmentId(index,state) }} />}
            </Row>
            <Row>
                <Col style={{ margin: "10px" }}>
                    <div className="d-flex justify-content-end">
                        {/*<h5>warning message</h5>*/}
                    </div>
                </Col>
                <Col style={{ margin: "10px" }}>
                    <div className="d-flex justify-content-end">
                        <Button variant="primary" onClick={() => onSave()}>{t('LAN_SAVE')}</Button>
                    </div>
                </Col>
            </Row>
            <Row>
                <Col style={{ margin: "10px" }}>
                    <div className="d-flex justify-content-end">
                        <CurrentTimer stores={currentTimerStore} />
                    </div>
                </Col>
            </Row>
        </div>
    );
}


export default EquipmentManagementView;