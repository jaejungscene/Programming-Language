import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Table from 'react-bootstrap/Table';
import Stack from 'react-bootstrap/Stack';
import React, { useState }  from 'react';
import { useTranslation } from 'react-i18next';
import Form from 'react-bootstrap/Form';
import { Observer } from 'mobx-react';
var moment = require('moment');

function AlarmHistoryListView({ ...props }, ref) {

    const { t } = useTranslation();


    return (
        <Observer>
            {() => (
                <div>
                    <Row>
                        <Col style={{ margin: "10px", overflow: 'scroll', maxHeight: '240px', minHeight: '240px' }}>
                            <Table>
                                <thead>
                                    <tr>
                                        <th style={{ display: 'none' }}>{'AlarmId'}</th>
                                        <th style={{ width: '10%' }}>{t('LAN_NO')}</th>
                                        <th style={{ width: '30%' }}>{t('LAN_TABLE_ITEM')}</th>
                                        <th style={{ width: '15%' }}>{t('LAN_TABLE_VALUE')}</th>
                                        <th style={{ width: '15%' }}>{t('LAN_LOWER_ERROR_THRESHOLD')}</th>
                                        <th style={{ width: '15%' }}>{t('LAN_UPPER_ERROR_THRESHOLD')}</th>
                                        <th style={{ width: '30%' }}>{t('LAN_TABLE_DATE')}</th>
                                    </tr>
                                </thead>
                                <tbody ref={ref}>
                                    {props.viewData.map((item, index) =>
                                        <tr key={index + 1} id={index + 1} onClick={(e) => { props.onClick(e, item) }}>
                                            <td style={{ display: 'none' }}>{item._id}</td>
                                            <td>{index + 1}</td>
                                            <td>{item.ParameterName}</td>
                                            <td>{item.Value}</td>
                                            <td>{item.LowerErrorThreshold}</td>
                                            <td>{item.UpperErrorThreshold}</td>
                                            <td>{moment(item.CreDate).format("YYYY-MM-DD HH:mm:ss")}</td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </Col>
                    </Row>
                    <Row style={{ marginRight: '10px' }} className="alarm-select-form">
                        <Card style={{ height: '70px', paddingTop : '16px', paddingLeft:'20px' }}>
                            <Stack direction="horizontal" gap={2}>
                                <div>
                                    <div style={{ float: 'left' }}>
                                        <h5 class="form-label">{t('LAN_TABLE_ITEM')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '240px' }} type="text" value={props.selectedRowItems ? props.selectedRowItems.ParameterName : '' } readOnly={true} />
                                    </div>
                                </div>
                                <div className='vr' />
                                <div>
                                    <div style={{ float: 'left' }}>
                                        <h5 class="form-label">{t('LAN_TABLE_VALUE')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '100px' }} type="text" value={props.selectedRowItems ? props.selectedRowItems.Value : ''} readOnly={true} />
                                    </div>
                                </div>
                                <div className='vr' />
                                <div>
                                    <div style={{ float: 'left' }}>
                                        <h5 class="form-label">{t('LAN_LOWER_ERROR_THRESHOLD')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '80px' }} type="text" value={props.selectedRowItems ? props.selectedRowItems.LowerErrorThreshold : ''} readOnly={true} />
                                    </div>
                                </div>     
                                <div className='vr' />
                                <div>
                                    <div style={{ float: 'left' }}>
                                        <h5 class="form-label">{t('LAN_UPPER_ERROR_THRESHOLD')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '80px' }} type="text" value={props.selectedRowItems ? props.selectedRowItems.UpperErrorThreshold : ''} readOnly={true} />
                                    </div>
                                </div>     
                                <div className='vr' />
                                <div>
                                    <div style={{ float: 'left' }}>
                                        <h5 class="form-label">{t('LAN_TABLE_MESSAGE')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '430px' }} type="text" value={props.selectedRowItems ? props.selectedRowItems.AlarmMessage : ''}  readOnly={true} />
                                    </div>
                                </div>
                            </Stack>
                        </Card>
                    </Row>
                </div>
            )}
        </Observer>
    )
}


export default React.forwardRef(AlarmHistoryListView);