import Stack from 'react-bootstrap/Stack';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Observer } from 'mobx-react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Button from 'react-bootstrap/Button';
import useStore from '../../stores/useStore';
import swal from 'sweetalert2';
import Swich from './Common/Switch';
import EquipmentTypeDropDown from './Common/EquipmentTypeDropDown';
import DropDownList from './Common/DropDownList';

function MachineAgentInfoView({...props}) {

    const { t } = useTranslation();

    const onSave = async () => {

        if (props.stores.isRunning === true)
        {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_NOW_RUNNING'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
            return;
        }
        
        let eqpResult = await props.stores.onSaveMachineAgent();

        if (eqpResult) {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
            props.initialize();
        }
        else {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    const onDelete = async () => {
        if (props.stores.isRunning === true)
        {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_NOW_RUNNING'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
            return;
        }
        

        let result = await props.stores.onDeleteMachineAgent();

        if (result) {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
            
            props.initialize();
        }
        else {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    function onChangedPlcType(e){
        if(e.target.value){
            props.stores.onChangeSelectPLC(e.target.value);
        }
    }

    return (
        <Observer>
            {() => (
                    <Stack direction="vertical" gap={3}>
                        <Row>
                            <Col>
                                <div style={{ float: 'left' }}>
                                    <h5 style={{width:'140px', textAlign: 'right'}}>{t('LAN_EQUIPMENT_TYPE')}</h5>
                                </div>
                                <div style={{ float: 'left', paddingLeft: '20px' }}>
                                    <EquipmentTypeDropDown value={props.stores.equipmentType} onChange={(e) => { props.stores.onChangeEquipmentType(props.stores.EquipmentId, e.target.value) }} />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <div style={{ float: 'left' }}>
                                    <h5 style={{width:'140px', textAlign: 'right'}}>{t('LAN_EQUIPMENT_NAME')}</h5>
                                </div>
                                <div style={{ float: 'left', paddingLeft: '20px' }}>
                                    <Form.Control style={{width:'220px'}} type="text" placeholder="Name" value={props.stores.equipmentName}
                                    onChange={(e) => props.stores.onChangeName(e.target.value)}
                                    />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <div style={{ float: 'left' }}>
                                    <h5 style={{width:'140px', textAlign: 'right'}}>{t('LAN_ENABLE')}</h5>
                                </div>
                                <div style={{ float: 'left', paddingLeft: '20px' }}>
                                    <Swich value={props.stores.machineAgentEnable} onChange={(e) => { props.stores.onChangeEnable(e.target.checked) }} />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <div style={{ float: 'left' }}>
                                    <h5 style={{width:'140px', textAlign: 'right'}}>{t('LAN_EQUIPMENT_PLC_TYPE')}</h5>
                                </div>
                                <div style={{ float: 'left', paddingLeft: '20px' }}>
                                    <DropDownList value={props.stores.selectedPlcId} options={props.stores.plcList} width={'220px'} onSelect={(e) => onChangedPlcType(e)}/>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col style={{ marginRight:'137px'}}>
                                <h5 style={{ height: '40px', display:'flex', alignItems:'center', float:"right" }}>
                                    <Button onClick={() => onDelete()} style={{ float: 'right', margin: '5px' }}>Delete</Button>
                                    <Button onClick={() => onSave()} style={{ float: 'right', margin: '5px' }}>Save</Button>
                                </h5>
                            </Col>
                        </Row>
                    </Stack>
            )}
        </Observer>
    );
}
export default MachineAgentInfoView;