import { useTranslation } from 'react-i18next';
import React, { useEffect, useState, useRef } from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Carousel from 'react-bootstrap/Carousel';
import Checkbox from './Common/Checkbox';
import useStore from '../../stores/useStore';
import NewCoaterLayout from './NewCoaterLayout';
import { Observer } from 'mobx-react';
import { useObserver } from 'mobx-react';
import DashBoardHeader from './Common/DashBoardHeader';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { FaAngleLeft, FaAngleRight } from "react-icons/fa"
import DashBoardRealTimeChart from './Common/DashBoardRealTimeChart';
import ToastContainer from 'react-bootstrap/ToastContainer';
import Toast from 'react-bootstrap/Toast';
import SixChartMatrix from './SixChartMatrix'
import ChartListCard from './Common/ChartListCard';
import TextListCard from './Common/TextListCard';
import CoatingQualityCard from './Common/CoatingQualityCard';
import LoadingSpinner from './Common/Spinner';
import { useLocation } from 'react-router-dom';

let interval = null;
let left = 0;
function TrendMonitoringView(props) {

    const navigate = useNavigate();
    const { dashBoardStore } = useStore();
    const { mainViewStore } = useStore();
    const { alertHistoryStore } = useStore();
    const graphRef = useRef();
    const { t } = useTranslation();
    const [dashboardInitialize, setDashboardInitialize] = useState(false);
    const [equipmentChanged, setEquipmentChanged] = useOutletContext().equipmentChanged;
    const sessionStorage = window.sessionStorage;
    const [dashboardType, setDashboardType] = useState("graph");
    const [checkModule, setCheckModule] = useState([]);
    const [activeIndex, setActiveIndex] = useState(0);
    const [pause, setPause] = useState(false);
    
    useEffect(() => {
        initialize();
        return () => clearInterval(interval);
    }, []);

    const initialize = async () => {
        setDashboardInitialize(false);

        if (!dashBoardStore.webSocket) {
            await dashBoardStore.initialize(mainViewStore.getWebsocket());
        }

        setDashboardInitialize(true);
    };

    const toggleDashboardType = (type) => {
        setDashboardType(type);
        setActiveIndex(0);
    }

    const changeModule = (checked) => {
        setCheckModule(checked);
        setActiveIndex(0);
    }


    return (
            <div class="page-container dashboard-container">
                { !dashboardInitialize && <LoadingSpinner /> }
                <Observer>
                    {() => (
                        <DashBoardHeader
                            title={[t('LAN_TABLE_RECIPE_ID'), t('LAN_TABLE_BATCH_ID'), t('LAN_START_TIME'), t('LAN_PRODUCT_TIME'), t('LAN_PRODUCT_SPEED')]}
                            viewData={dashBoardStore.workingInfo}
                            process={dashBoardStore.processInfo}
                            selectedType={dashboardType}
                            selectedAuto={pause}
                            onChangeType={toggleDashboardType}
                            onChangeModule={changeModule}
                            onChangeAuto={(auto) => setPause(!auto)}
                        >
                        </DashBoardHeader>
                    )}
                </Observer>

                {
                    dashboardType === "graph" &&
                    <Carousel
                        interval={pause === true ? null : 5000}
                        className="dashboard-card-carousel"
                        activeIndex={activeIndex}
                        variant="dark"
                        onSelect={(selected) => setActiveIndex(selected)}
                        indicators={false}
                        prevIcon={<FaAngleLeft color={checkModule.length > 1 ? 'black' : 'white'} size='1x' />}
                        nextIcon={<FaAngleRight color={checkModule.length > 1 ? 'black' : 'white'}  size='1x' />}
                    >
                        {
                            checkModule.map((seq, index) => {
                                let nextSeq = typeof checkModule[index + 1] !== "undefined" ? checkModule[index + 1] : null;
                                return index % 2 === 0 &&
                                typeof dashBoardStore.processInfo[seq] !== "undefined" &&
                                dashBoardStore.realTimeStorage[dashBoardStore.processInfo[seq].CollectionInfoId] &&
                                <Carousel.Item key={index}>
                                    <Observer>
                                        {() => (
                                            <div class="carousel-inner-items">
                                                <ChartListCard
                                                    id={dashBoardStore.processInfo[seq].CollectionInfoId}
                                                    title={dashBoardStore.processInfo[seq].CollectionName}
                                                    viewData={dashBoardStore.realTimeStorage[dashBoardStore.processInfo[seq].CollectionInfoId]}
                                                />

                                                {
                                                    nextSeq !== null &&
                                                    <ChartListCard
                                                        id={dashBoardStore.processInfo[nextSeq].CollectionInfoId}
                                                        title={dashBoardStore.processInfo[nextSeq].CollectionName}
                                                        viewData={dashBoardStore.realTimeStorage[dashBoardStore.processInfo[nextSeq].CollectionInfoId]}
                                                    />
                                                }
                                            </div>
                                        )}
                                    </Observer>
                                </Carousel.Item>
                            })
                        }
                    </Carousel>
                }
                {
                    dashboardType === "text" &&
                    <Observer>
                        {() => (
                            <div class="dashboard-card-stack">
                                {/* small card */}
                                <div class="dashboard-cards dashboard-cards-4 around-cards">
                                    {
                                        dashBoardStore.processInfo.map((item, index) => 
                                            item.Size === "Small" &&
                                            <TextListCard
                                                id={item.CollectionInfoId}
                                                title={item.CollectionName}
                                                viewData={dashBoardStore.realTimeStorage[item.CollectionInfoId]}
                                            />
                                        )
                                    }
                                </div>

                                {/* big card */}
                                <div class="dashboard-cards dashboard-cards-4">
                                    {
                                        dashBoardStore.processInfo.map((item, index) => 
                                            item.Size === "Big" &&
                                            <TextListCard
                                                id={item.CollectionInfoId}
                                                title={item.CollectionName}
                                                type="dryer"
                                                viewData={dashBoardStore.realTimeStorage[item.CollectionInfoId]}
                                            />
                                        )
                                    }
                                </div>
                            </div>
                        )}
                    </Observer>
                }
            </div>    
        )
}

export default TrendMonitoringView;