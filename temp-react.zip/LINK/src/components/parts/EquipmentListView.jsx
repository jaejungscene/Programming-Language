import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import EquipmentTypeDropDown from './Common/EquipmentTypeDropDown';
import PLCTypeDropDown from './Common/PLCTypeDropDown';
import Swich from './Common/Switch';
import React from 'react';
import { useObserver } from 'mobx-react';
import { useTranslation } from 'react-i18next';
import ConnectCondition from './Common/ConnectCondition';


function EquipmentListView({...props}, ref) {

    //const tableBodyRef = useRef(null);
    const tableBodyRef = ref;

    const { t } = useTranslation();

    function onRowClicked(state, e) {

        let selectedId = -1;
                
        for (let item of tableBodyRef.current.children) {
            if (e.currentTarget.id === item.id) {
                item.classList.toggle('table-active');                
                if(e.currentTarget.className === 'table-active'){
                    selectedId = parseInt(e.currentTarget.id);
                }else{
                    selectedId = -1;
                }
            }
            else {
                item.classList.remove('table-active');                
            }            
        }        
        props.selectedEquipment(selectedId, state);

    }

    return useObserver(() =>
    (
        <div>
            <Row>
                <Col style={{ margin: "10px", overflow: 'scroll', maxHeight: '320px' }}>
                    <Table>
                        <thead>
                            <tr>
                                <th>{t('LAN_NO')}</th>
                                <th>{t('LAN_EQUIPMENT_TYPE')}</th>
                                <th>{t('LAN_EQUIPMENT_NAME')}</th>
                                <th>{t('LAN_EQUIPMENT_PLC_TYPE')}</th>
                                <th>{t('LAN_EQUIPMENT_PLC_ADDRESS')}</th>
                                <th>{t('LAN_ENABLE')}</th>
                                <th colSpan={2}>{t('LAN_CONNECT')}</th>
                            </tr>
                        </thead>
                        <tbody ref={ref}>
                            {props.stores.equipmentList.map((item, index) =>
                                <tr key={item} id={index + 1} onClick={(e) => {onRowClicked(item.isRunning, e)} }>
                                    <td>{index + 1}</td>
                                    <td>
                                        <div style={{ display: 'inline-block' }}>
                                            <EquipmentTypeDropDown value={item.EquipmentType} onChange={(e) => { props.stores.onChangeEquipmentType(item.EquipmentId, e.target.value) }} />
                                        </div>
                                    </td>
                                    <td>{item.EquipmentName}</td>
                                    <td>
                                        <div style={{ display: 'inline-block' }}>
                                            <PLCTypeDropDown/>
                                        </div>
                                    </td>
                                    <td>{item.PlcIp}</td>
                                    <td>
                                        <Swich value={item.Enabled} disabled={item.isRunning} onChange={(e) => { props.stores.onChangeEquipmentMode(item.EquipmentId, e.target.checked) }} />
                                    </td>
                                    <td>
                                        <Button variant="primary" onClick={() => props.stores.connectionTest(item.EquipmentId)}>{t('LAN_TEST')}</Button>
                                    </td>
                                    <td>
                                        <ConnectCondition visible={props.stores.connectionList[index]} value={item.isRunning}></ConnectCondition>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </Table>
                </Col>
            </Row>
        </div>
    )
    );
}


export default React.forwardRef(EquipmentListView);