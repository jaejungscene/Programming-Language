
import { useTranslation } from 'react-i18next';
import React, { useEffect, useState, useRef } from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import useStore from '../../stores/useStore';
import { Observer } from 'mobx-react';
import { useObserver } from 'mobx-react';
import DateTimePicker from './Common/DateTimePicker';
import DropDownList from './Common/DropDownList';
import {startOfWeek, subDays} from 'date-fns'
import DashBoardHeader from './Common/DashBoardHeader';
import { useNavigate, useOutletContext, useLocation } from 'react-router-dom';
import { TbDeviceDesktopAnalytics } from "react-icons/tb";
import { AiOutlineLineChart } from "react-icons/ai"
import AlarmHistoryListView from './AlarmHistoryListView';
import SixChartMatrix from './SixChartMatrix';
import Table from './Common/Table';
import RelatedFactorView from './RelatedFactorView';
import { AiFillAlert } from "react-icons/ai";
import LoadingSpinner from './Common/Spinner';

function AlarmHistoryView(props) {

    const navigate = useNavigate();
    const { alertHistoryStore } = useStore();
    const { alarmHistoryStore } = useStore(); 
    const { t } = useTranslation();
    const [dashboardInitialize, setDashboardInitialize] = useState(null);
    const errorText = useRef();
    const [equipmentChanged, setEquipmentChanged] = useOutletContext().equipmentChanged;    
    const [isLoading, setIsLoading] = useState(false);
    const [selectedCollectionItem, setSelectedCollectionItem] = useState(0);
    const [fromDate, setFromDate] = useState(subDays(new Date(), 7));
    const [toDate, setToDate] = useState(new Date());
    const [minDate, setMinDate] = useState(subDays(new Date(), 7));
    const [alarmListTableData, setAlarmListTableData] = useState([]);
    const [selectedRowInfo, setSelectedRowInfo] = useState({alarmId: "None"});
    const [selectedRowItems, setselectedRowItems] = useState(null);
    const [relatedFactorValues, setRelatedFactorValues] = useState(null);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const location = useLocation();
    const selectedImage = location.state && location.state.param;

    useEffect(() => {
        InitController();
    }, [location]);

    function InitController()
    {   
        if(selectedImage !== null && selectedImage !== undefined){
            let collectionInfoID = alertHistoryStore.PARTS_TYPE[selectedImage];
            setSelectedCollectionItem(collectionInfoID);
            refreshAnalysisData(collectionInfoID);
        }
        else
            setSelectedCollectionItem(alarmHistoryStore.lastSearchValue);

        for(let type in alertHistoryStore.PARTS_TYPE){
            alertHistoryStore.removeBlinkEffect(alertHistoryStore.PARTS_TYPE[type]);
        }
    };

    const handleSelectionChgange = (e) =>{
        setSelectedIndex(e);
    }

    const handleDateTimePicker = (type, date) => {
        if(type == 'from') {
            setFromDate(date);
        }
        else {
            setToDate(date);
        }
    }

    const handleDropDownSelect = (e) => {      
        setSelectedCollectionItem(e.target.value);
    }

    const refreshAnalysisData = async (collectionInfoID) => {
        try{
            setIsLoading(true);

            const minTime = new Date(fromDate);
            minTime.setHours(0, 0, 0, 0);
            const maxTime = new Date(toDate);
            maxTime.setHours(23, 59, 59, 999);

            await alarmHistoryStore.getAlertList(minTime, maxTime, collectionInfoID == 0 ? undefined : collectionInfoID);
            setRelatedFactorValues({});
            alarmHistoryStore.lastSearchValue = collectionInfoID;
            setIsLoading(false);
        }catch(err) {
            setIsLoading(false);
            console.log(err.message);
        }
        
    }
    const searchAlarm = async () => {
        refreshAnalysisData(selectedCollectionItem)       
    }

    const handleRowSelect = async (e, item) => {
        setIsLoading(true);
        setselectedRowItems(item);
        const from = new Date(item.CreDate);
        const to = new Date(from - 60000);
        const relatedBlockValues = await alarmHistoryStore.getRealTimeDataByDate(from, to, item.BlockInfoID);

        setRelatedFactorValues(relatedBlockValues);
        setIsLoading(false);
    }


    return useObserver(() => (
        <Observer>
            {() => (
                <div style={{ marginTop: '10px', marginLeft: '10px', marginRight: '12px', marginBottom: '10px', backgroundColor: 'white' }}>
                    { isLoading && <LoadingSpinner /> }
                    <Row style={{marginTop : '15px'}}>
                        <Col sm={2}>
                            <div style={{ width: '280px', lineHeight: '40px', float: 'center', textAlign: 'left', paddingLeft: "30px", fontSize: '1.3em', backgroundColor: 'rgb(52,58,64)', color: 'white', borderRadius: '5px 5px 0px 0px', margin: '5px 15px 0 22px' }}>
                                <AiFillAlert style={{ marginTop: '-5px' }} />
                                &nbsp;&nbsp;&nbsp;{t('LAN_ALARM_HISTORY')}
                            </div>
                        </Col>

                        <Col sm={10}></Col>
                    </Row>

                    <Row style={{ margin: '0px 10px 0 10px' }}>
                        <Col>
                            <Card style={{ height: '60px'}}>
                                <Card.Body style={{ paddingTop: '8px'}}>
                                    <Stack direction="horizontal" gap={4}>
                                        <DateTimePicker from={fromDate} to={toDate} minDate={minDate} onChangeDate={handleDateTimePicker} className="alarm-datepicker" />
                                        <div className='vr' />
                                        <DropDownList options={alarmHistoryStore.dropDownList} label={t("LAN_SEARCH") + " " + t("LAN_EQUIPMENT")} width={'300px'} value={selectedCollectionItem} onSelect={handleDropDownSelect} onChange={handleSelectionChgange} />
                                        <button title='Search' onClick={searchAlarm} className="alarm-submit-btn">{t("LAN_SEARCH")}</button>
                                    </Stack>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>

                    <Row style={{ margin: "10px 10px 5px 25px"}}>
                        <Col>
                            {<AlarmHistoryListView viewData={alarmHistoryStore.alarmList} onClick={handleRowSelect} selectedRowItems={selectedRowItems}/>}
                        </Col>
                    </Row>


                    <RelatedFactorView viewData={relatedFactorValues} />


                </div>
            )}
        </Observer>
    ));

}

export default AlarmHistoryView;