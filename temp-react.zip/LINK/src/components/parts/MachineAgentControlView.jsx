import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import { useObserver } from 'mobx-react';
import Swich from './Common/Switch';
import swal from 'sweetalert2';
import { useTranslation } from 'react-i18next';


function MachineAgentControlView(props) {

    const { t } = useTranslation();

    async function onMachineAgentModeChange(mode){
        let result = await props.onMachineAgentModeChange(0, mode);
        await props.stores.onMachineAgentModeChange();
        
        /*
        if (result) {
            swal.fire({
                title: "Machine Agent mode changed!",
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else {
            swal.fire({
                title: "Machine Agent Problem. Please check Machine Agent",
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
        */
    }

    return useObserver(() => (
        <>
            <Row>
                <Col style={{ float: 'right', margin: '5px' }}>
                    <Col style={{ float: 'right', margin: '5px' }}>
                        <h9>{t('LAN_SIMULATION_MODE')}</h9>
                    </Col>
                    <Col style={{ float: 'right', margin: '5px' }}>
                        <Swich value={props.stores.machineAgentMode} onChange={(e) => { onMachineAgentModeChange(e.target.checked===true?0:1) }} />
                    </Col>
                </Col>
            </Row>
        </>
    ));
}


export default MachineAgentControlView;