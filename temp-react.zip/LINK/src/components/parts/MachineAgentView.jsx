import { Observer } from 'mobx-react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import CurrentTimer from './Common/CurrentTimer';
import useStore from '../../stores/useStore';
import MachineAgentControlView from './MachineAgentControlView';
import MachineAgentListView from './MachineAgentListView';
import MachineAgentInfoView from './MachineAgentInfoView';
import React, { useEffect, useState, useRef } from "react";
import { useTranslation } from 'react-i18next';

function MachineAgentView() {

    const { machineAgentListStore, machineAgentControlStore, currentTimerStore, mainViewStore, machineAgentInformationStore } = useStore();
    const [equipmentListStatus, setEquipmentListStatus] = useState(null);
    const { t } = useTranslation();
    const errorText = useRef();

    const machineAgentListViewRef = useRef();

    useEffect(() => {
        equipmentInitialize();
        currentTimerStore.initialize();
        //connectToMachineAgent();
    }, [machineAgentListStore, machineAgentControlStore, currentTimerStore, errorText]);

    const equipmentInitialize = async () => {
        //await machineAgentListStore.initialize(mainViewStore.webSocket);
        await machineAgentListStore.initialize(mainViewStore.getWebsocket());
        setEquipmentListStatus(true);
        //await machineAgentInformationStore.initialize(mainViewStore.webSocket);
        await machineAgentInformationStore.initialize(mainViewStore.getWebsocket());
        
        clearPlcList();
    }

    async function connectToMachineAgent(){
        machineAgentListStore.webSocket.on("machineAgentLog", (msg) => {
            fireMchineAgentLogMessage(msg);
        });
    }

    async function fireMchineAgentLogMessage(msg) {
        if (errorText.current === null || errorText === null) {
            return;
        }
        errorText.current.value += msg + '\n';

        errorText.current.scrollTop = errorText.current.scrollHeight;
    }

    async function onChangeMachineAgent(item){
        machineAgentInformationStore.onChangeMachineAgent(item);
    }

    function clearPlcList(){        
        if(machineAgentListViewRef.current !== undefined){
            for (let item of machineAgentListViewRef.current.children) {
                if (item.className === 'table-active') {
                    item.classList.remove('table-active');                
                }      
            }
        }
                
    }

    return (
        <Observer>
            {() => (
                <div class="page-inner-container">
                    {/** MachineAgent Control View */}
                    <Row style={{marginTop:"10px", marginRight:"130px", marginBottom:"10px"}}>
                        {/* 레이아웃 리펙토링 필요 */}
                        <MachineAgentControlView stores={machineAgentControlStore} onMachineAgentModeChange={(eqpId, mode) => { machineAgentListStore.onChangeMachineAgentMode(eqpId, mode) }} />
                    </Row>
                    <Row>
                        <Col sm={8}>
                            {equipmentListStatus && <MachineAgentListView stores={machineAgentListStore} onChangeMachineAgent={(item) => {onChangeMachineAgent(item)}} />}
                        </Col>
                        <Col sm={4}>
                            <MachineAgentInfoView stores={machineAgentInformationStore} initialize={() => {equipmentInitialize();}} />
                        </Col>
                    </Row>
                    {/** 
                        <Row style={{marginTop:"0px", marginRight:"150px"}}>
                        <Col>
                            <div className="d-flex justify-content-end">
                                <CurrentTimer stores={currentTimerStore} />
                            </div>
                        </Col>
                        </Row> 
                    */}
                 
                </div>
            )}
        </Observer>
    );

}

export default MachineAgentView;