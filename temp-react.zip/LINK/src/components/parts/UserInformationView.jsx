import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Observer } from 'mobx-react';
import Checkbox from './Common/Checkbox';
import React, { useEffect, useState } from 'react';
import AuthorityTypeDropDown from './Common/AuthorityTypeDropDown';
import { useTranslation } from 'react-i18next';



function UserInformationView({...props}, ref) {

    const [isShow, setIsShow] = useState(false);
    const { t } = useTranslation();

    function onShow(e){
        setIsShow(!isShow);
    }

    function isReadOnly(val){        
        if(val === true){
            return true;
        }else{
            return false;
        }
    }

    return (
        <Observer>
            {() => (
                <Card style={{ height: '150px', maxHeight: '150px'}}>
                    <Card.Body style={{ paddingTop: '25px' }}>
                        <Stack direction="vertical" gap={4}>
                            <Row>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{width:'100px', textAlign: 'right'}}>{t('LAN_USER_ID')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{width:'250px'}} type="text" placeholder={t('LAN_USER_ID')} value={props.stores.userId} onBlur={(e) => props.stores.onChangeId(e, e.target.value)} onChange={(e) => props.stores.onChangeId(e, e.target.value)} readOnly={isReadOnly(props.stores.isSelected)} />
                                    </div>
                                </Col>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{width:'100px', textAlign: 'right'}}>{t('LAN_USER_NAME')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{width:'250px'}} type="text" placeholder={t('LAN_USER_NAME')} value={props.stores.userName} onChange={(e) => props.stores.onChangeName(e.target.value)} />
                                    </div>
                                </Col>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{width:'100px', textAlign: 'right'}}>{t('LAN_USER_AUTHORITY')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <AuthorityTypeDropDown style={{width:'250px'}} value={props.stores.userAuthority} onChange={(e) => props.stores.onChangeAuthority(e.target.value)} />
                                    </div>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{width:'100px', textAlign: 'right'}}>{t('LAN_USER_PASSWORD')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{width:'250px', height: '35px'}} type={isShow ? "text" : "password"} placeholder={t('LAN_USER_PASSWORD')} value={props.stores.userPassword} onChange={(e) => props.stores.onChangePassword(e.target.value)} />
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px', paddingTop: '10px' }}>
                                        <Checkbox label={t('LAN_SHOW')} onChange={(e) => {onShow(e)}} />
                                    </div>
                                </Col>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{width:'100px', textAlign: 'right'}}>{t('LAN_USER_PHONE')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{width:'250px'}} type="text" placeholder={t('LAN_USER_PHONE')} value={props.stores.userPhoneNumber} onChange={(e) => props.stores.onChangePhoneNumber(e.target.value)} onBlur={() => {props.stores.onCheckPhoneNumberFormat()}} />
                                    </div>
                                </Col>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{width:'100px', textAlign: 'right'}}>{t('LAN_USER_MAIL')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{width:'250px'}} type="text" placeholder={t('LAN_USER_MAIL')} value={props.stores.userMail} onChange={(e) => props.stores.onChangeMail(e.target.value)} onBlur={() => {props.stores.onCheckMailFormat()}} />
                                    </div>
                                </Col>
                            </Row>
                        </Stack>
                    </Card.Body>
                </Card>
            )}
        </Observer>
    );
}
export default UserInformationView;