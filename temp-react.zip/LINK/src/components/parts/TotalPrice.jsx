import React from 'react';
import { useObserver } from 'mobx-react';
import useStore from '../../stores/useStore';

const TotalPrice = () => {
  const { marketStore } = useStore();
  return useObserver(() => (
    <div>
      <hr />
      <p>
        <b>총합: </b> {marketStore.total}원
      </p>
    </div>
  ));
};

export default TotalPrice;