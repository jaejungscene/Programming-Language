import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import { useTranslation } from 'react-i18next';
import DrivenDetailView from './DrivenDetailView';

import { useLocation } from "react-router";
import { useEffect, useState } from 'react';


function DrivingPartsView() {
    const { state } = useLocation(null);
    const [activeKey, setActiveKey] = useState('NIPROLL_PRESSURE');
    const { t } = useTranslation();
    useEffect(()=>{
        if(state != null){
            setActiveKey(state.TabKey);
        }
        else{
            setActiveKey('NIPROLL_PRESSURE');
        }
        
    }, [state]);

    const handleTabSelect = (eventKey) =>{ 
        setActiveKey(eventKey);
    }
    return (
        <div style={{ backgroundColor:'white'}}>
            <Tabs style={{margin: '10px'}} defaultActiveKey='NIPROLL_PRESSURE' id="uncontrolled-tab-example" className="mb-3" activeKey={activeKey} onSelect={(k) => setActiveKey(k)}>            
                <Tab eventKey='NIPROLL_PRESSURE' title={t('LAN_NIP_ROLL')}>
                    <DrivenDetailView activeKey = {activeKey} moduleType = {'NIPROLL_PRESSURE'} title={t('LAN_NIP_ROLL')}/>
                </Tab>                
                <Tab eventKey="DANCERROLL" title={t('LAN_DANCER_ROLL')}>
                    <DrivenDetailView activeKey = {activeKey} moduleType = {'DANCERROLL'} title={t('LAN_DANCER_ROLL')}/>
                </Tab>
                <Tab eventKey="PICKUPROLL" title={t('LAN_PICKUP_ROLL')}>
                    <DrivenDetailView activeKey = {activeKey} moduleType = {'PICKUPROLL'} title={t('LAN_PICKUP_ROLL')}/>
                </Tab>
                <Tab eventKey="SERVO" title={t('LAN_SERVO_MOTOR')}>
                    <DrivenDetailView activeKey = {activeKey} moduleType = {'SERVO'} title={t('LAN_SERVO_MOTOR')}/>
                </Tab>
                
            </Tabs>
        </div>
    );
}
 
export default DrivingPartsView;