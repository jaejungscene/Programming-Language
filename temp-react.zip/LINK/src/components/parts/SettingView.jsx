import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import UserManagementView from './UserManagementView';
import { useTranslation } from 'react-i18next';
import CollectionBlockTreeList from '../views/PLCMemoryMapEdit/CollectionBlockTreeList';
import  BasicSystemInformationView from './BasicSystemInformationView';
import IpSettingView from './IpSettingView';
import AlarmSettingView from './AlarmSettingView';
import PLCMemoryMapEdit from '../views/PlcMemoryMapEditView'
import { useLocation } from "react-router";
import { useEffect, useState } from 'react';
function SettingView() {
    const { state } = useLocation(null);
    const [activeKey, setActiveKey] = useState('baseInfo');
    const { t } = useTranslation();
    useEffect(()=>{
        if(state != null){
            setActiveKey(state.TabKey);
        }
        else{
            setActiveKey('baseInfo');
        }
        
    }, [state]);

    const handleTabSelect = (eventKey) =>{ 
        setActiveKey(eventKey);
    }
    return (
        <div class="page-container setting-view">
            <Tabs defaultActiveKey='baseInfo' id="uncontrolled-tab-example" className="mb-3" activeKey={activeKey} onSelect={(k) => setActiveKey(k)}>
                <Tab eventKey='baseInfo' title={t('LAN_STANDARD_INFORMATION')}>
                    <BasicSystemInformationView />
                </Tab>                
                <Tab eventKey="userSetting" title={t('LAN_USER_MANAGEMENT')}>
                    <UserManagementView />
                </Tab>
                {/*
                <Tab eventKey="PlcCollectionEdit" title={t('LAN_PLC_COLLECTION_EDIT')}>
                    <CollectionBlockTreeList handleTabSelect={(k) => handleTabSelect(k)}/>
                </Tab>
                */}
                <Tab eventKey="PlcMemoryMapEdit" title={t('LAN_PLC_MEMORY_EDIT')}>
                    <PLCMemoryMapEdit handleTabSelect={(k) => handleTabSelect(k)}/>
                </Tab>
                <Tab eventKey="ipInfo" title={t('LAN_FIXED_IP_INFO')}>
                    <IpSettingView />
                </Tab>
                <Tab eventKey="alarmInfo" title={t('LAN_ALARM_INFO')}>
                    <AlarmSettingView />
                </Tab>
                
            </Tabs>
        </div>
    );
}
 
export default SettingView;