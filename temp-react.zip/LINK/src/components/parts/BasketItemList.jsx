import React from 'react';
import BasketItem from './BasketItem';
import useStore from '../../stores/useStore';
import { useObserver } from 'mobx-react';

const BasketItemList = () => {

    const { marketStore } = useStore();

    const onTake = (name) => {
        marketStore.take(name)
    }

    return useObserver(() => {
        const itemList = marketStore.selectedItems.map(items => 
            <BasketItem items={items} onTake={onTake} />
        );

        return (
            <div>
                {itemList}
                <hr />
                <p>
                    <b>총합: </b> {marketStore.total}원
                </p>
            </div>
        );
    });
};

export default BasketItemList;