
import { useTranslation } from 'react-i18next';
import React, { useEffect, useState, useRef } from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Carousel from 'react-bootstrap/Carousel';
import Checkbox from './Common/Checkbox';
import useStore from '../../stores/useStore';
import NewCoaterLayout from './NewCoaterLayout';
import { Observer } from 'mobx-react';
import { useObserver } from 'mobx-react';
import DashBoardHeader from './Common/DashBoardHeader';
import DryZoneCard from './Common/DryZoneCard';
import DrivenPartCard from './Common/DrivenPartCard';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { FaAngleLeft, FaAngleRight } from "react-icons/fa"
import DashBoardRealTimeChart from './Common/DashBoardRealTimeChart';
import ToastContainer from 'react-bootstrap/ToastContainer';
import Toast from 'react-bootstrap/Toast';
import SixChartMatrix from './SixChartMatrix'
import CoatingQualityCard from './Common/CoatingQualityCard';
import LoadingSpinner from './Common/Spinner';
import { useLocation } from 'react-router-dom';
import ChartListCard from './Common/ChartListCard';

let interval = null;
let left = 0;
function IpMonitoringView(props) {

    const navigate = useNavigate();
    const { ipDashBoardStore } = useStore();
    const { mainViewStore } = useStore();
    const { alertHistoryStore } = useStore();
    const { t } = useTranslation();
    const [ipMonitoringInitialize, setIpMonitoringInitialize] = useState(false);
    const [equipmentChanged, setEquipmentChanged] = useOutletContext().equipmentChanged;
    const sessionStorage = window.sessionStorage;
    const [checkModule, setCheckModule] = useState([]);
    const [activeIndex, setActiveIndex] = useState(0);
    const [pause, setPause] = useState(false);
    
    useEffect(() => {
        initialize();
        return () => clearInterval(interval);
    }, []);

    const initialize = async () => {
        setIpMonitoringInitialize(false);
        await ipDashBoardStore.initialize();

        if (!ipDashBoardStore.webSocket) {
            await ipDashBoardStore.initializeSocket(mainViewStore.getWebsocket());
        }

        setIpMonitoringInitialize(true);
    };

    const changeModule = (checked) => {
        setCheckModule(checked);
        setActiveIndex(0);
    }


    return (
            <div class="page-container dashboard-container">
                { !ipMonitoringInitialize && <LoadingSpinner /> }
                <Observer>
                    {() => (
                        <DashBoardHeader
                            title={[t('LAN_TABLE_RECIPE_ID'), t('LAN_TABLE_BATCH_ID'), t('LAN_START_TIME'), t('LAN_PRODUCT_TIME'), t('LAN_PRODUCT_SPEED')]}
                            viewData={ipDashBoardStore.workingInfo}
                            process={ipDashBoardStore.processInfo}
                            selectedAuto={pause}
                            onChangeModule={changeModule}
                            onChangeAuto={(auto) => setPause(!auto)}
                        >
                        </DashBoardHeader>
                    )}
                </Observer>

                {
                    <Carousel
                        interval={pause === true ? null : 5000}
                        className="dashboard-card-carousel"
                        activeIndex={activeIndex}
                        variant="dark"
                        onSelect={(selected) => setActiveIndex(selected)}
                        indicators={false}
                        prevIcon={<FaAngleLeft color={checkModule.length > 1 ? 'black' : 'white'} size='1x' />}
                        nextIcon={<FaAngleRight color={checkModule.length > 1 ? 'black' : 'white'}  size='1x' />}
                    >
                        {
                            checkModule.map((seq, index) => {
                                let nextSeq = typeof checkModule[index + 1] !== "undefined" ? checkModule[index + 1] : null;

                                return index % 2 === 0 &&
                                typeof ipDashBoardStore.processInfo[seq] !== "undefined" &&
                                ipDashBoardStore.realTimeStorage[ipDashBoardStore.processInfo[seq].CollectionInfoId] &&
                                <Carousel.Item key={index}>
                                    <Observer>
                                        {() => (
                                            <div class="carousel-inner-items">
                                                <ChartListCard
                                                    visibleIp={true}
                                                    id={ipDashBoardStore.processInfo[seq].CollectionInfoId}
                                                    title={ipDashBoardStore.processInfo[seq].CollectionName}
                                                    viewData={ipDashBoardStore.realTimeStorage[ipDashBoardStore.processInfo[seq].CollectionInfoId]}
                                                    fixedIpData={ipDashBoardStore.fixedIpStorage[ipDashBoardStore.processInfo[seq].CollectionInfoId]}
                                                />

                                                {
                                                    nextSeq !== null &&
                                                    <ChartListCard
                                                        visibleIp={true}
                                                        id={ipDashBoardStore.processInfo[nextSeq].CollectionInfoId}
                                                        title={ipDashBoardStore.processInfo[nextSeq].CollectionName}
                                                        viewData={ipDashBoardStore.realTimeStorage[ipDashBoardStore.processInfo[nextSeq].CollectionInfoId]}
                                                        fixedIpData={ipDashBoardStore.fixedIpStorage[ipDashBoardStore.processInfo[nextSeq].CollectionInfoId]}
                                                    />
                                                }
                                            </div>
                                        )}
                                    </Observer>
                                </Carousel.Item>
                            })
                        }
                    </Carousel>
                }
            </div>    
        )
}

export default IpMonitoringView;