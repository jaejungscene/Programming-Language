import React from 'react';
import '../../public/css/BasketItem.css';
import { useObserver } from 'mobx-react';

const BasketItem = ({items, onTake}) => {
  return useObserver(() => (
    <div className="BasketItem">
      <div className="name">{items.name}</div>
      <div className="price">{items.price}원</div>
      <div className="count">{items.count}</div>
      <div className="return" onClick={() => onTake(items.name)}>갖다놓기</div>
    </div>
  ));
};

export default BasketItem;

