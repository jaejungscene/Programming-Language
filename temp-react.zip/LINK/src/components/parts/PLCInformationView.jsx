import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Observer } from 'mobx-react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import PLCTypeDropDown from './Common/PLCTypeDropDown';
import EndianTypeDropDown from './Common/EndianTypeDropDown';
import Button from 'react-bootstrap/Button';
import useStore from '../../stores/useStore';
import swal from 'sweetalert2';

function PLCInformationView({ ...props }, ref) {

    const { plcManagementStore } = useStore();
    const { t } = useTranslation();
    const tableBodyRef = ref;
    const regExpIp = /^(([1-9]?\d|1\d{2}|2([0-4]\d)|25[0-5])\.){3}([1-9]?\d|1\d{2}|2([0-4]\d)|25[0-5])$/;
    const regExpPort = /^[0-9]{1,5}$/;

    const onSave = async () => {
        if (plcManagementStore.PlcName == "") {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_REQUIRED'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
            return;
        }

        let formatCheckIPresult = regExpIp.test(plcManagementStore.Ip);
        if (formatCheckIPresult !== true) {
            swal.fire({
                title: t('MSG_SYSTEM_IP_FAIL'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
            return;
        }

        let formatCheckPortresult = regExpPort.test(plcManagementStore.Port);
        if (formatCheckPortresult !== true) {
            swal.fire({
                title: t('MSG_SYSTEM_PORT_FAIL'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
            return;
        }

        let eqpResult = await plcManagementStore.onSavePlcInfo();

        if (eqpResult) {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
            props.initialize();
        }
        else {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    const onDelete = async () => {
        let result = await plcManagementStore.onDeletePlcInfo();

        if (result) {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
            debugger;
            props.initialize();
            //clearPlcList();
        }
        else {
            swal.fire({
                title: t('MSG_SYSTEM_INFO_SAVE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    }

    function isReadOnly(val) {
        if (val === true) {
            return true;
        } else {
            return false;
        }
    }

    return (
        <Observer>
            {() => (

                <Stack direction="vertical" gap={3}>
                    <Row>
                        <Col>
                            <div style={{ float: 'left' }}>
                                <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_EQUIPMENT_PLC_NAME')}</h5>
                            </div>
                            <div style={{ float: 'left', paddingLeft: '20px' }}>
                                <Form.Control style={{ width: '200px' }} type="text" placeholder="Name" value={props.stores.PlcName}
                                    onChange={(e) => props.stores.onChangeName(e.target.value)}
                                    readOnly={isReadOnly(props.stores.isSelected)} />
                            </div>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <div style={{ float: 'left' }}>
                                <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_IP')}</h5>
                            </div>
                            <div style={{ float: 'left', paddingLeft: '20px' }}>
                                <Form.Control style={{ width: '200px' }} type="text" placeholder="IP" value={props.stores.Ip}
                                    onChange={(e) => props.stores.onChangeIp(e.target.value)}
                                    readOnly={isReadOnly(props.stores.isSelected)} />
                            </div>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <div style={{ float: 'left' }}>
                                <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_PORT')}</h5>
                            </div>
                            <div style={{ float: 'left', paddingLeft: '20px' }}>
                                <Form.Control style={{ width: '200px' }} type="text" placeholder="PORT" value={props.stores.Port}
                                    onChange={(e) => props.stores.onChangePort(e.target.value)}
                                    readOnly={isReadOnly(props.stores.isSelected)} />
                            </div>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <div style={{ float: 'left' }}>
                                <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_ENDIAN_TYPE')}</h5>
                            </div>
                            <div style={{ float: 'left', paddingLeft: '20px' }}>
                                <EndianTypeDropDown value={props.stores.EndianType} onChange={(e) => {
                                    props.stores.onChangeEndianType(e.target.value);
                                }} />

                            </div>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <div style={{ float: 'left' }}>
                                <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_EQUIPMENT_PLC_TYPE')}</h5>
                            </div>
                            <div style={{ float: 'left', paddingLeft: '20px' }}>
                                <PLCTypeDropDown value={props.stores.PlcType} onChange={(e) => {
                                    props.stores.onChangePlcType(e.target.value);
                                }} />
                            </div>

                        </Col>
                    </Row>


                    {props.stores.isSiemens && (
                        <div>
                            <Row>
                                <Col>
                                    <div style={{ float: 'left', marginBottom: '5px' }}>
                                        <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_CPU')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '200px' }} type="text" placeholder="CPU" value={props.stores.PlcCpu}
                                            onChange={(e) => props.stores.onChangeCpu(e.target.value)}
                                        />
                                    </div>
                                </Col>
                            </Row>

                            <Row paddingTop="20px">
                                <Col>
                                    <div style={{ float: 'left', marginBottom: '5px' }}>
                                        <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_SLOT')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '200px' }} type="text" placeholder="Slot" value={props.stores.PlcSlot}
                                            onChange={(e) => props.stores.onChangeSlot(e.target.value)}
                                        />
                                    </div>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <div style={{ float: 'left' }}>
                                        <h5 style={{ width: '140px', textAlign: 'right' }}>{t('LAN_RACK')}</h5>
                                    </div>
                                    <div style={{ float: 'left', paddingLeft: '20px' }}>
                                        <Form.Control style={{ width: '200px' }} type="text" placeholder="Rack" value={props.stores.PlcRack}
                                            onChange={(e) => props.stores.onChangeRack(e.target.value)}
                                        />
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    )}

                    <Row>
                        <Col style={{ marginRight: '168px' }}>
                            <h5 style={{ height: '40px', display: 'flex', alignItems: 'center', float: "right" }}>
                                <Button onClick={() => onDelete()} style={{ float: 'right', margin: '5px' }}>Delete</Button>
                                <Button onClick={() => onSave()} style={{ float: 'right', margin: '5px' }}>Save</Button>
                            </h5>
                        </Col>
                    </Row>
                </Stack>
            )}
        </Observer>
    );
}
export default PLCInformationView;