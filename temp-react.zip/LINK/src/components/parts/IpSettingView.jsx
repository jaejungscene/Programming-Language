import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Table from 'react-bootstrap/Table';
import React, { useEffect, useState, useRef } from "react";
import useStore from '../../stores/useStore';
import Button from 'react-bootstrap/esm/Button';
import {format} from 'date-fns';
import swal from 'sweetalert2';
import { useTranslation } from 'react-i18next';
import EquipmentClassificationCombo from './Common/EquipmentClassificationCombo';
import LoadingSpinner from './Common/Spinner';
import WebModal from './Common/WebModal';
import AddFixedIpInfoModal from './Common/AddFixedIpInfoModal';

function IpInfoView(props) {
  const formRef = useRef();  
  const { ipSettingStore } = useStore();
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const { t } = useTranslation();

  useEffect(() => {
    initialize();
  }, []);

  const initialize = async () => {
    await searchIpInfo(formRef.current);
    setIsLoading(false);
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    await searchIpInfo(e.target);
  }

  const searchIpInfo = async (form) => {
    try {
      setIsLoading(true);

      const formData = new FormData(form);
      ipSettingStore.collection_info_id = formData.get("collection_info_id");
      ipSettingStore.block_info_id = formData.get("block_info_id");
      ipSettingStore.plc_address_info_id = formData.get("plc_address_info_id");
      ipSettingStore.keyword = formData.get("keyword");

      await ipSettingStore.searchIpInfo();

      setIsLoading(false);
    } catch (err) {
      console.log(err);
      setIsLoading(false);
    }
  }

  const onClickAddFixedIp = () => {
    setModalTitle(t("LAN_FIXED_IP_ADD"));
    setShowModal(true);
  }

  const onCloseModal = () => {
    setShowModal(false);
    initialize();
  }

  const onClickDelete = async (item) => {
    swal.fire({
      title: t('MSG_DELETE_CONFIRM'),
      text: t('MSG_PREVIOUS_VALUE_REMAIN'),
      icon: 'warning',
      
      showCancelButton: true,
      confirmButtonColor: '#ff7d4f',
      confirmButtonText: 'OK',
      cancelButtonText:'CANCEL',
    }).then(async (result) => {
        if (result.isConfirmed){
            let data = await ipSettingStore.deleteFixedIpInfo(item.fixed_ip_info_id);
            console.log(data);

            if(data){
                swal.fire({
                    title: t('LAN_SUCCESS'),
                    text: "",
                    icon: "success",
                    confirmButtonText: "OK"
                });
            }else{
                swal.fire({
                    title: t('LAN_FAILED'),
                    text: "",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            }
            await initialize();
        }
    });
  }

  return (
    <div class="page-inner-container">
      { isLoading === true && <LoadingSpinner /> }
        <Row>
            <Col> 
                <h4 class="page-title">
                {t('LAN_FIXED_IP_INFO')}
                </h4>
            </Col>
        </Row>

        <Row>
          <Col>
            <Card>
              <Card.Header>{t("LAN_SEARCH_KEY")}</Card.Header>
              <Card.Body>
                <form 
                  class="common-form flex-form"
                  onSubmit={onSubmit}
                  ref={formRef}
                >
                    <span class="label">
                      {t('LAN_EQUIPMENT_CATEGORY')}
                    </span>
                    <EquipmentClassificationCombo />

                    <span class="null"></span>

                    <label for="ip_keyword">
                      {t("LAN_KEYWORD")}
                    </label>
                    <input type="text" id='ip_keyword' name='keyword' />

                    <button type='submit'>
                    {t("LAN_SEARCH")}
                    </button>
                </form>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <br />

        <Row>
          <Col>
            <Card>
              <Card.Header>{t('LAN_FIXED_IP_INFO_LIST')}</Card.Header>

              <Card.Body className="setting-scroll-body scrollbar">
                <div className='text right'>
                  <button onClick={onClickAddFixedIp}>{t('LAN_FIXED_IP_ADD')}</button>
                </div>

                <Table>
                  <thead>
                    <tr>
                      <th>{t('LAN_NO')}</th>
                      <th>{t('LAN_MAJOR_CLASSIFICATION')}</th>
                      <th>{t('LAN_MEDIUM_CLASSIFICATION')}</th>
                      <th>{t('LAN_SUB_CLASSIFICATION')}</th>
                      <th>{t('LAN_IP_NAME')}</th>
                      <th>{t('LAN_CREATE_DATE')}</th>
                      <th class="text right">{t('LAN_DELETE')}</th>
                    </tr>
                  </thead>

                  <tbody>
                    {
                      ipSettingStore.ipList.map((item) => {
                        return <tr>
                          <td>
                            {item.fixed_ip_info_id}
                          </td>
                          <td>
                            {item.collection_name}
                          </td>
                          <td>
                            {item.block_name}
                          </td>
                          <td>
                            {item.plc_address_info_name}
                          </td>
                          <td>
                            {item.fixed_ip_info_name}
                          </td>
                          <td>
                            {format(item.create_date, "yyyy-MM-dd HH:mm:ss")}
                          </td>
                          <td class="text right">
                            <button 
                              onClick={(e) => onClickDelete(item)}
                              class="red">{t('LAN_DELETE')}</button>
                          </td>
                        </tr>
                      })
                    }
                  </tbody>
                </Table>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        
        <WebModal
          show={showModal}
          title={modalTitle}
          onClose={onCloseModal}>
          <AddFixedIpInfoModal 
            show={showModal}
            onClose={onCloseModal} />
        </WebModal>
          
    </div>
  )
}

export default IpInfoView