import { Observer } from 'mobx-react';
import Table from 'react-bootstrap/Table';
import React from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useTranslation } from 'react-i18next';

function UserManagementListView({ ...props }, ref) {

    //const tableBodyRef = useRef(null);
    const tableBodyRef = ref;
    const { t } = useTranslation();


    function onRowClicked(e, selectedItem) {
        let setItem = {
            Authority: props.stores.convertNameToAutority(selectedItem.Authority),
            CreDate: selectedItem.CreDate,
            Enabled: selectedItem.Enabled,
            Mail: selectedItem.Mail,
            PhoneNumber: selectedItem.PhoneNumber,
            UserId: selectedItem.UserId,
            UserName: selectedItem.UserName,
            Password: selectedItem.Password,
            isSelected: true
        }

        for (let item of tableBodyRef.current.children) {
            if (e.currentTarget.id === item.id) {

                if (e.currentTarget.className === 'table-active') {
                    setItem = undefined;
                }

                item.classList.toggle('table-active');

            }
            else {
                item.classList.remove('table-active');
            }
        }
        props.onRowClicked(setItem);
    }


    return (

        <Observer>
            {() => (
                <div>
                    <Row>
                        <Col className="scrollbar" style={{ maxHeight: '320px' }}>
                            <Table>
                                <thead>
                                    <tr>
                                        <th>{t('LAN_NO')}</th>
                                        <th>{t('LAN_USER_ID')}</th>
                                        <th>{t('LAN_USER_NAME')}</th>
                                        <th>{t('LAN_USER_AUTHORITY')}</th>
                                        <th>{t('LAN_USER_PHONE')}</th>
                                        <th>{t('LAN_USER_MAIL')}</th>
                                    </tr>
                                </thead>
                                <tbody ref={ref}>
                              
                                    {props.stores.userList.map((item, index) =>
                                        <tr key={index + 1} id={index + 1} onClick={(e) => { onRowClicked(e, item) }} >
                                            <td>{index + 1}</td>
                                            <td>
                                                {item.UserId}
                                            </td>
                                            <td>
                                                {item.UserName}
                                            </td>
                                            <td>
                                                {item.Authority}
                                            </td>
                                            <td>
                                                {item.PhoneNumber}
                                            </td>
                                            <td>
                                                {item.Mail}
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </Col>
                    </Row>
                </div>
            )
            }
        </Observer >
    );

}


export default React.forwardRef(UserManagementListView);