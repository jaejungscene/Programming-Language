import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack'
import DateTimePicker from './Common/DateTimePicker';
import DropDownList from './Common/DropDownList';
import LineChart from './Common/Chart/LineChart';
import MainFactorCard from './Common/RelatedFactorCard';
import Table from './Common/Table'
import { useState, useEffect } from 'react';
import { startOfWeek, subDays } from 'date-fns'
import useStore from '../../stores/useStore'
import { useObserver } from 'mobx-react';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import LoadingSpinner from './Common/Spinner';
import styled from 'styled-components';
import CpCpkCard from './Common/CpCpkCard';

const styles = styled.div`
${``/*.table {
    height: 370px;
    width: 100%;
    tbody {
        height: 340px;
        table-layout: fixed;
        display: block;
        overflow-y: auto;
        overflow-x: hidden;
    }

    thead, tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
    }
}
*/}
height: 370px;
overflow-y: scroll;
`

function LoadingLevelView(props) {
    const [isLoading, setIsLoading] = useState(false);
    const { t } = useTranslation();
    const [options, setOptions] = useState([{ value: 0, name: 'All' }]);

    const tableColumns = [
        {
            accessor: 'No',
            Header: t("LAN_TABLE_NO"),
            width: '10%'
        },
        {
            accessor: 'Name',
            Header: t("LAN_TABLE_NAME"),
            width: '10%'
        },
        {
            accessor: 'CreDate',
            Header: t("LAN_TABLE_DATE"),
            width: '20%'
        },
        {
            accessor: 'AlarmType',
            Header: t("LAN_TABLE_TYPE"),
            width: '10%'
        },
        {
            accessor: 'Value',
            Header: t("LAN_TABLE_VALUE"),
            width: '10%'
        },
        {
            accessor: 'Message',
            Header: t("LAN_TABLE_MESSAGE"),
            width: '40%'
        }
    ];

    useEffect(() => {
        initializeComponentDatas();
    }, []);

    const initializeComponentDatas = async () => {
        let tmpOptions = [options[0]];
        let params = {
            moduleType: "Loading Level"
        }

        try {
            setIsLoading(true);
            setOptions(tmpOptions);
            setIsLoading(false);
        } catch (err) {
            setIsLoading(false);
            console.log(err.message);
        }
    }  

    const handleRowSelect = (row) => {

    }

    return useObserver(() => (
        <div>
            {
                props.viewData.map((viewData) => {
                    return (
                        <Row>
                            <CpCpkCard title={props.title} datas={viewData} unit={props.unit} />
                        </Row>
                    )

                })
            }
            <MainFactorCard relatedFactors = {props.relatedFactors}></MainFactorCard>

            <Row style={{ padding: '10px' }}>
                <div>
                    <Card style={{ fontWeight : 'bold', height: '440px' }}>
                        <Card.Header>{t("LAN_ALARM_HISTORY")}</Card.Header>
                        <Card.Body>
                            <Table columns={tableColumns} data={props.alarmHistory} onSelectBatch={handleRowSelect} Styles={styles} />
                        </Card.Body>
                    </Card>
                </div>
            </Row>
        </div>
    ));
}

export default LoadingLevelView;