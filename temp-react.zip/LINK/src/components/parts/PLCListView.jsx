import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Table from 'react-bootstrap/Table';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Observer } from 'mobx-react';


function PLCListView({ ...props }, ref) {

    //const tableBodyRef = useRef(null);
    const tableBodyRef = ref;


    const { t } = useTranslation();

    function onRowClicked(e, selectedItem) {
        let temp = selectedItem;
        for (let item of tableBodyRef.current.children) {
            if (e.currentTarget.id === item.id) {
                if (e.currentTarget.className === 'table-active') {
                    temp = undefined;
                }
                item.classList.toggle('table-active');
            }
            else {
                item.classList.remove('table-active');
            }
        }
        props.onRowClicked(temp);
    }
    


    return (
        <Observer>
            {() => (
                <div>
                    <Row>
                        <Col className="scrollbar" style={{ maxHeight: '400px' }}>
                            <Table>
                                <thead>
                                    <tr>
                                        <th style={{ display: 'none' }}>{'PlcId'}</th>
                                        <th>{t('LAN_NO')}</th>
                                        <th>{t('LAN_EQUIPMENT_PLC_NAME')}</th>
                                        <th>{t('LAN_EQUIPMENT_PLC_TYPE')}</th>
                                        <th>{t('LAN_EQUIPMENT_PLC_ADDRESS')}</th>
                                        <th>{t('LAN_ENDIAN_TYPE')}</th>
                                        <th>{t('LAN_ASSIGNMENT_STATUS')}</th>
                                    </tr>
                                </thead>
                                <tbody ref={ref}>
                                    {props.stores.plcList.map((item, index) =>
                                        <tr key={index + 1} id={index + 1} onClick={(e) => { onRowClicked(e, item) }}>
                                            <td style={{ display: 'none' }}>{item.PlcId}</td>
                                            <td>{index + 1}</td>
                                            <td>{item.PlcName}</td>
                                            <td>{item.PlcType}</td>
                                            <td>{item.Ip}</td>
                                            <td>{item.EndianType}</td>
                                            <td>{item.Assign}</td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </Col>
                    </Row>
                </div>
            )}
        </Observer>
    )
}


export default React.forwardRef(PLCListView);