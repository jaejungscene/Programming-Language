const {createProxyMiddleware} = require('http-proxy-middleware');

module.exports = (app) => {
  //usage
  //for ui develop use comment return
  //for request api to server use return
  //for release use return
  //return;
  app.use(
    createProxyMiddleware(
      ['/'],{  //도메인 root가 기본주소
      target: 'http://localhost:3001', //통신할 서버의 도메인주소
      changeOrigin: true,
      ws:true
    })
  )
}