const EQUIPMENT_TYPE = [
    {id : '001', typeName: 'Coater'},
    {id : '002', typeName: 'Roll Press'},
    {id : '003', typeName: 'Slitter'}
];
const PLC_TYPE = [
    {id : 0, typeName: 'Mitubishi'},
    {id : 1, typeName: 'Sienmens'},
    {id : 2, typeName: 'Omron'},
];


module.exports.EQUIPMENT_TYPE = EQUIPMENT_TYPE;
module.exports.PLC_TYPE = PLC_TYPE;