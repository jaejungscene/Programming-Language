import constants from './constants';

export function convertIdToTypeName(type, id){
    let name = '';
    let comType = type === 'equipment' ? constants.EQUIPMENT_TYPE :  constants.PLC_TYPE;

    for(let item in comType){
        if(comType[item].id === id){
            name = comType[item].typeName;
            break;
        }
    }

    if(name === ''){
        name = 'None';
    }

    return name;
};

export function convertTypeNameToId(type, name){
    let id = 0;
    let comType = type === 'equipment' ? constants.EQUIPMENT_TYPE :  constants.PLC_TYPE;

    for(let item in comType){
        if(comType[item].typeName === name){
            id = comType[item].id;
            break;
        }
    }

    if(id === 0){
        id = 1;
    }

    return id;
};
