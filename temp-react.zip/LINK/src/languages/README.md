# 다국어 설명
#
# 1. 신규 국가 추가
#   1-1. src/languages/newLanguage 폴더를 추가한다.
#   1-2. src/languages/en/language.json 파일을 복사하여 src/languages/newLanguage/에 붙여 넣는다.
#   1-3. 복사된 파일을 열어 해당하는 언어에 맞게 번역한다(JSON Format).
#   1-4. i18n.js 파일을 열고 신규 추가된 언어를 불러온다.
#   1-5. resources 상수에서 추가된 언어를 기존 양식에 맞게 넣는다.
#   1-6. View에 다국어를 적용한다.
#   1-7. 브라우저를 실행시켜 제대로 동작하는지 확인한다.
#
# 2. 다국어 추가
#   2-1. src/languages/* 에 국가별 language.json에 신규 라벨을 추가한다.
#        (라벨 포멧 : LAN_*, 메시지 포멧 : MSG_*)
#   2-2. View에 다국어를 적용한다.
#   2-3. 브라우저를 실행시켜 제대로 동작하는지 확인한다.
#
# 3. 다국어 수정
#   3-1. src/languages/* 에 국가별 language.json에서 수정하고자 하는 라벨을 검색 후 수정한다.
#   3-2. View에 다국어를 적용한다.
#   3-3. 브라우저를 실행시켜 제대로 동작하는지 확인한다.
#
# 4. 다국어 삭제
#   4-1. src/languages/* 에 국가별 language.json에서 수정하고자 하는 라벨을 검색 후 삭제한다.
#
# 5. 다국어 View 적용하기
#   5-1. import { useTranslation } from 'react-i18next';
#   5-2. const { t } = useTranslation();
#   5-3. rendering level   {t('LANGUAGE_LABEL')}   ||   code level   t('LANGUAGE_LABEL');