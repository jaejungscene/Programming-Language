import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const BlockInfo = {
    'DrivenInfo':
    {
        'UNWINDER':
        [
            'UNWINDER_DANCERROLL_POSITION',
            'UNWINDER_PICKUPROLL_TENSION',
            'UNWINDER_SERVO_LOAD',
            'UNWINDER_SERVO_CURRENT'
        ],
        'COATER': 
        [
            'COATER_NIPROLL_PRESSURE',
            'COATER_SERVO_LOAD',
            'COATER_SERVO_CURRENT'
        ],
        'VACUUMROLL':
        [
            'VACUUMROLL_PICKUPROLL_TENSION',
            'VACUUMROLL_SERVO_LOAD',
            'VACUUMROLL_SERVO_CURRENT'
        ],
        'OUTFEED':
        [
            'OUTFEED_NIPROLL_PRESSURE',
            'OUTFEED_DANCERROLL_POSITION',
            'OUTFEED_PICKUPROLL_TENSION',
            'OUTFEED_SERVO_LOAD',
            'OUTFEED_SERVO_CURRENT'
        ],
        'REWINDER':
        [
            'REWINDER_DANCERROLL_POSITION',
            'REWINDER_PICKUPROLL_TENSION',
            'REWINDER_SERVO_LOAD',
            'REWINDER_SERVO_CURRENT'
        ]
    },

    'DryerInfo':  
    {
        'ZONE_1':
        [
            'ZONE1_DIFF_PRESSURE',
            'ZONE1_PLATE_TEMPERATURE',
            'ZONE1_ROOM_TEMPERATURE',
            'ZONE1_SUPPLY_WIND_SPEED',
            'ZONE1_EXHAUST_WIND_SPEED'
        ],
        'ZONE_2': 
        [
            'ZONE2_DIFF_PRESSURE',
            'ZONE2_PLATE_TEMPERATURE',
            'ZONE2_ROOM_TEMPERATURE',
            'ZONE2_SUPPLY_WIND_SPEED',
            'ZONE2_EXHAUST_WIND_SPEED'
        ],
        'ZONE_3':
        [
            'ZONE3_DIFF_PRESSURE',
            'ZONE3_PLATE_TEMPERATURE',
            'ZONE3_ROOM_TEMPERATURE',
            'ZONE3_SUPPLY_WIND_SPEED',
            'ZONE3_EXHAUST_WIND_SPEED'
        ],
        'ZONE_4':
        [
            'ZONE4_DIFF_PRESSURE',
            'ZONE4_PLATE_TEMPERATURE',
            'ZONE4_ROOM_TEMPERATURE',
            'ZONE4_SUPPLY_WIND_SPEED',
            'ZONE4_EXHAUST_WIND_SPEED'
        ],
        'ZONE_5':
        [
            'ZONE5_DIFF_PRESSURE',
            'ZONE5_PLATE_TEMPERATURE',
            'ZONE5_ROOM_TEMPERATURE',
            'ZONE5_SUPPLY_WIND_SPEED',
            'ZONE5_EXHAUST_WIND_SPEED'
        ],
        'ZONE_6':
        [
            'ZONE6_DIFF_PRESSURE',
            'ZONE6_PLATE_TEMPERATURE',
            'ZONE6_ROOM_TEMPERATURE',
            'ZONE6_SUPPLY_WIND_SPEED',
            'ZONE6_EXHAUST_WIND_SPEED'
        ]
    }
               
}

const trendChartStore = observable({
    webSocket: null,
    DrivenInfo:{
        'UNWINDER':
        {
            'UNWINDER_DANCERROLL_POSITION': [{PLCAddressId: '1', ParameterName: 'DANCERROLL_POSITION', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'UNWINDER_PICKUPROLL_TENSION': [{PLCAddressId: '2', ParameterName: 'PICKUPROLL_TENSION', Threshold : 5, ErrorThreshold : 3, Unit : 'N'}],
            'UNWINDER_SERVO_LOAD': [{PLCAddressId: '3', ParameterName: 'SERVO_LOAD', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'UNWINDER_SERVO_CURRENT': [{PLCAddressId: '4', ParameterName: 'SERVO_CURRENT', Threshold : 5, ErrorThreshold : 3, Unit : 'A'}],
        },
        'COATER':
        {
            'COATER_NIPROLL_PRESSURE': [{PLCAddressId: '1', ParameterName: 'NIPROLL_PRESSURE_OS', Threshold : 5, ErrorThreshold : 3, Unit : 'MPa'},
                                        {PLCAddressId: '1', ParameterName: 'NIPROLL_PRESSURE_DS', Threshold : 5, ErrorThreshold : 3, Unit : 'MPa'}],
            'COATER_SERVO_LOAD': [{PLCAddressId: '2', ParameterName: 'SERVO_LOAD', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'COATER_SERVO_CURRENT': [{PLCAddressId: '3', ParameterName: 'SERVO_CURRENT', Threshold : 5, ErrorThreshold : 3, Unit : 'A'}],
        },
        'VACUUMROLL':
        {
            'VACUUMROLL_PICKUPROLL_TENSION': [{PLCAddressId: '1', ParameterName: 'PICKUPROLL_TENSION', Threshold : 5, ErrorThreshold : 3, Unit : 'N'}],
            'VACUUMROLL_SERVO_LOAD': [{PLCAddressId: '2', ParameterName: 'SERVO_LOAD', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'VACUUMROLL_SERVO_CURRENT': [{PLCAddressId: '3', ParameterName: 'SERVO_CURRENT', Threshold : 5, ErrorThreshold : 3, Unit : 'A'}],
        },
        'OUTFEED':
        {
            'OUTFEED_NIPROLL_PRESSURE': [{PLCAddressId: '1', ParameterName: 'NIPROLL_PRESSURE', Threshold : 5, ErrorThreshold : 3, Unit : 'MPa'}],
            'OUTFEED_DANCERROLL_POSITION': [{PLCAddressId: '2', ParameterName: 'DANCERROLL_POSITION', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'OUTFEED_PICKUPROLL_TENSION': [{PLCAddressId: '3', ParameterName: 'PICKUPROLL_TENSION', Threshold : 5, ErrorThreshold : 3, Unit : 'N'}],
            'OUTFEED_SERVO_LOAD': [{PLCAddressId: '2', ParameterName: 'SERVO_LOAD', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'OUTFEED_SERVO_CURRENT': [{PLCAddressId: '3', ParameterName: 'SERVO_CURRENT', Threshold : 5, ErrorThreshold : 3, Unit : 'A'}],
        },
        'REWINDER':
        {
            'REWINDER_DANCERROLL_POSITION': [{PLCAddressId: '1', ParameterName: 'DANCERROLL_POSITION', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'REWINDER_PICKUPROLL_TENSION': [{PLCAddressId: '3', ParameterName: 'PICKUPROLL_TENSION', Threshold : 5, ErrorThreshold : 3, Unit : 'N'}],
            'REWINDER_SERVO_LOAD': [{PLCAddressId: '2', ParameterName: 'SERVO_LOAD', Threshold : 5, ErrorThreshold : 3, Unit : '%'}],
            'REWINDER_SERVO_CURRENT': [{PLCAddressId: '3', ParameterName: 'SERVO_CURRENT', Threshold : 5, ErrorThreshold : 3, Unit : 'A'}],
        },
    },

    DrivenValue : {},

    DryerInfo:{
        'ZONE_1':
        {
            'ZONE1_DIFF_PRESSURE': [{PLCAddressId: '1', ParameterName: 'DIFF_PRESSURE', Threshold : 5, ErrorThreshold : 3, Unit : 'MPa'}],
            'ZONE1_PLATE_TEMPERATURE': [{PLCAddressId: '2', ParameterName: 'PLATE_TEMPERATURE', Threshold : 5, ErrorThreshold : 3, Unit : '℃'}],
            'ZONE1_ROOM_TEMPERATURE': [{PLCAddressId: '3', ParameterName: 'ROOM_TEMPERATURE', Threshold : 5, ErrorThreshold : 3, Unit : '℃'}],
            'ZONE1_SUPPLY_WIND_SPEED': [{PLCAddressId: '4', ParameterName: 'SUPPLY_WIND_SPEED', Threshold : 5, ErrorThreshold : 3, Unit : 'RPM'}],
            'ZONE1_EXHAUST_WIND_SPEED': [{PLCAddressId: '5', ParameterName: 'EXHAUST_WIND_SPEED', Threshold : 5, ErrorThreshold : 3, Unit : 'RPM'}],
        },
        'ZONE_2':
        {
            'ZONE2_DIFF_PRESSURE': [{PLCAddressId: '1', ParameterName: 'DIFF_PRESSURE', Threshold : 5, ErrorThreshold : 3, Unit : 'MPa'}],
            'ZONE2_PLATE_TEMPERATURE': [{PLCAddressId: '2', ParameterName: 'PLATE_TEMPERATURE', Threshold : 5, ErrorThreshold : 3, Unit : '℃'}],
            'ZONE2_ROOM_TEMPERATURE': [{PLCAddressId: '3', ParameterName: 'ROOM_TEMPERATURE', Threshold : 5, ErrorThreshold : 3, Unit : '℃'}],
            'ZONE2_SUPPLY_WIND_SPEED': [{PLCAddressId: '4', ParameterName: 'SUPPLY_WIND_SPEED', Threshold : 5, ErrorThreshold : 3, Unit : 'RPM'}],
            'ZONE2_EXHAUST_WIND_SPEED': [{PLCAddressId: '5', ParameterName: 'EXHAUST_WIND_SPEED', Threshold : 5, ErrorThreshold : 3, Unit : 'RPM'}],
        },
        'ZONE_3':
        {
            'ZONE3_DIFF_PRESSURE': [{PLCAddressId: '1', ParameterName: 'DIFF_PRESSURE', Threshold : 5, ErrorThreshold : 3, Unit : 'MPa'}],
            'ZONE3_PLATE_TEMPERATURE': [{PLCAddressId: '2', ParameterName: 'PLATE_TEMPERATURE', Threshold : 5, ErrorThreshold : 3, Unit : '℃'}],
            'ZONE3_ROOM_TEMPERATURE': [{PLCAddressId: '3', ParameterName: 'ROOM_TEMPERATURE', Threshold : 5, ErrorThreshold : 3, Unit : '℃'}],
            'ZONE3_SUPPLY_WIND_SPEED': [{PLCAddressId: '4', ParameterName: 'SUPPLY_WIND_SPEED', Threshold : 5, ErrorThreshold : 3, Unit : 'RPM'}],
            'ZONE3_EXHAUST_WIND_SPEED': [{PLCAddressId: '5', ParameterName: 'EXHAUST_WIND_SPEED', Threshold : 5, ErrorThreshold : 3, Unit : 'RPM'}],
        },
    }
    ,

    DryerValue:{
        /*  예시로 남겨둠. 
        'DRYER_1':
        {
            'ZONE1_DIFF_PRESSURE': [{Value: 0}],[{Value: 0}]
            'ZONE1_PLATE_TEMPERATURE': [{Value: 0}],
            'ZONE1_ROOM_TEMPERATURE': [{Value: 0}],
            'ZONE1_SUPPLY_WIND_SPEED': [{Value: 0}],  
            'ZONE1_EXHAUST_WIND_SPEED': [{Value: 0}],  
        },
        'DRYER_2':
        {
            'ZONE2_DIFF_PRESSURE': [{Value: 0}],
            'ZONE2_PLATE_TEMPERATURE': [{Value: 0}],
            'ZONE2_ROOM_TEMPERATURE': [{Value: 0}],
            'ZONE2_SUPPLY_WIND_SPEED': [{Value: 0}],  
            'ZONE2_EXHAUST_WIND_SPEED': [{Value: 0}],  
        },
        'DRYER_3':
        {
            'ZONE3_DIFF_PRESSURE': [{Value: 0}],
            'ZONE3_PLATE_TEMPERATURE': [{Value: 0}],
            'ZONE3_ROOM_TEMPERATURE': [{Value: 0}],
            'ZONE3_SUPPLY_WIND_SPEED': [{Value: 0}],  
            'ZONE3_EXHAUST_WIND_SPEED': [{Value: 0}],  
        },
        */
    }
    ,

    async initData() {
        await refreshGetStandardInfo();
        await requestPreviousData();
    },

    async leavePage() {
        this.webSocket.removeListener("standardInfoBroadcast", handleStandardInfoBroadcast);
        this.webSocket.removeListener("plcRealTimeDataBroadcast", handleRealTimeData);
    },


    async initialize(websocket) {
        if(this.webSocket == null){
            this.webSocket = websocket;
        }
        
        this.webSocket.on('standardInfoBroadcast', handleStandardInfoBroadcast);

        this.webSocket.on("plcRealTimeDataBroadcast", handleRealTimeData);
    },

});


const refreshGetStandardInfo = async (standardInfo) => {
    if(standardInfo === undefined){
        standardInfo = await Fetcher('get', '/plcAPI/getStandardInfo');
    }

    trendChartStore.DrivenInfo = {};
    trendChartStore.DryerInfo = {};
    //배열초기화
    for (const key in BlockInfo.DrivenInfo) {
        trendChartStore.DrivenInfo[key] = {};
    }
    for (const key in BlockInfo.DryerInfo) {
        trendChartStore.DryerInfo[key] = {};
    }


    for (let info of standardInfo) {

        const drivenKey = Object.keys(BlockInfo.DrivenInfo).find(key =>
            BlockInfo.DrivenInfo[key].includes(info.BlockInfoId)
        );
    
        if (drivenKey){
            if (!trendChartStore.DrivenInfo[drivenKey][info.BlockInfoId]) {
                trendChartStore.DrivenInfo[drivenKey][info.BlockInfoId] = [];
            }
            trendChartStore.DrivenInfo[drivenKey][info.BlockInfoId].push(info);
            continue;
        }

        const dryerKey = Object.keys(BlockInfo.DryerInfo).find(key =>
            BlockInfo.DryerInfo[key].includes(info.BlockInfoId)
        );

        if (dryerKey){
            if (!trendChartStore.DryerInfo[dryerKey][info.BlockInfoId]) {
                trendChartStore.DryerInfo[dryerKey][info.BlockInfoId] = [];
            }
            trendChartStore.DryerInfo[dryerKey][info.BlockInfoId].push(info);
            continue;
        }

    }
};

const handleStandardInfoBroadcast = async (standardInfo) => {
    await refreshGetStandardInfo(standardInfo);
};

const handleRealTimeData = async (plcRealTimeDatas) => {
    processPlcRealTimeData(plcRealTimeDatas);
  };


const requestPreviousData = async () => {
    const drivenInfoArray = Object.values(BlockInfo.DrivenInfo).flat();
    const dryerInfoArray = Object.values(BlockInfo.DryerInfo).flat();
    let param = { blockInfoIDs : drivenInfoArray.concat(dryerInfoArray) };
    let realTimeDatas = await Fetcher('post', '/plcAPI/getPreviousRealTimeData', {param});
    processPlcRealTimeData(realTimeDatas);
}

function processPlcRealTimeData(dataList) {
    let drivenValue = {};
    let dryerValue = {};


    let creDateGroup = [...new Set(dataList.map(item => item.CreDate))];
    let dateGroup = [];
    let plcData = {};
    const drivenInfoArray = Object.values(BlockInfo.DrivenInfo).flat();
    const dryerInfoArray = Object.values(BlockInfo.DryerInfo).flat();

    for(let creDate of creDateGroup)
    {
        plcData = {};
        dateGroup = dataList.filter(item => item.CreDate === creDate);


        //동일 시간 끼리 묶어서 전송하여 차트에 중복 표현될 수 있도록 함.
        for(let timeData of dateGroup)
        {
            if (!plcData[timeData.BlockInfoID]) {
                plcData[timeData.BlockInfoID] = [];
            }
            plcData[timeData.BlockInfoID].push(timeData);
        }

        for(let blkKey in plcData){
            if (drivenInfoArray.includes(blkKey)) {
                if (!drivenValue[blkKey]) {
                    drivenValue[blkKey] = [];
                }
                drivenValue[blkKey].push(plcData[blkKey]);
            }
            else if (dryerInfoArray.includes(blkKey)) {
                if (!dryerValue[blkKey]) {
                    dryerValue[blkKey] = [];
                }
                dryerValue[blkKey].push(plcData[blkKey]);
            }

        }
    }

    trendChartStore.DrivenValue = drivenValue;
    trendChartStore.DryerValue = dryerValue;
};

export { trendChartStore };