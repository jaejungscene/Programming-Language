import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const machineAgentControlStore = observable({
    machineAgentMode: false,

    async onMachineAgentAllStart(){
        let result = await Fetcher('get', '/httpAPI/machineAgentAllStart');

        return result;
    },

    async onMachineAgentAllStop(){
        let result = await Fetcher('get', '/httpAPI/machineAgentAllStop');

        return result;
    },

    async onMachineAgentModeChange(){
        this.machineAgentMode = !this.machineAgentMode;
        return this.machineAgentMode
    },
})

export { machineAgentControlStore }