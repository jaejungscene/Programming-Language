import { faLongArrowAltRight, faPersonWalkingDashedLineArrowRight } from '@fortawesome/free-solid-svg-icons';
import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import swal from 'sweetalert2';

const PLCAddressEditStore = observable({
    async initializeComponentDatas() {
        // this.webSocket = websocket;        
        await this.getDBPLCList();


        // await this.webSocket.on('plcRealTimeDataBroadcast', async (plcRealTimeDatas) => {
        //     console.log(plcRealTimeDatas); 
        //     plcRealTimeDatas.forEach(plcRealTimeData => {
        //         console.log(this.plcMemoryMap.find((p)=> p.PLCAddress === plcRealTimeData.PLCAddressId).Value = plcRealTimeData.Value);
        //     });
        //     console.log(this.plcMemoryMap);
        // });

    },
    currentPlcInfoId: 1,
    currentPlcType: 1,
    plcMemoryMpaHeader: [
        "PLCAddress",
        "Collection",
        "StartAddress",
        "ParameterName",
        "DataType",
        "SelectAddress_1",
        "FormulaType",
        "SelectAddress_2",
        "StandardValue",
        "LowerErrorThreshold",
        "UpperErrorThreshold",
        "DigitalLength",
        "Value",
        "PLCAddressInfoId",
        "CollectionInfoId",
        "BlockInfoId",
        "IsRecipe",
        "IsFlexibleIp"
    ],
    plcList: [],
    plcTypeList: [],
    collectionMap: [
    ],
    blockMap: [
    ],
    plcMemoryMap: [],
    dbFormatPlcMap: [],
    boolType_Data:[
        {
            text: "True",
            value: "True",
        },
        {
            text: "False",
            value: "False",
        },
    ],
    formulaType_Data: [
        {
            text: "SingleMode",
            value: "SingleMode",
        },
        {
            text: "+",
            value: "+",
        },
        {
            text: "-",
            value: "-",
        },
        {
            text: "*",
            value: "*",
        },
        {
            text: "/",
            value: "/",
        },

    ],
    dropDown_TypeList: [
        "ALL",
        "Mapping Address",
        "Not Mapping Address"
    ],
    dataType_Data: [
        {
            text: "BIT",
            value: "BIT",
        },
        {
            text: "BYTE",
            value: "BYTE",
        },
        {
            text: "WORD",
            value: "WORD",
        },
        {
            text: "DWORD",
            value: "DWORD",
        },


    ],
    importCollection: [

    ],
    importBlock: [

    ],
    importPlcAddress: [

    ],
    selectPLCAddress_dropdownlist: [

    ],
    sendPlcAddressMapList: {

    },
    async sendPlcMapToMA() {
        return await Fetcher('post', '/plcAPI/sendPLCMemoryMap', { 'PlcId': this.currentPlcInfoId });
    },
    setSelectPLCAddress_dropDownList() {
        this.selectPLCAddress_dropdownlist = Array.from(
            new Set(
                this.plcMemoryMap.map((p) => (p.PLCAddress ? p.PLCAddress : ""))
            ));
        this.selectPLCAddress_dropdownlist.unshift('None');
        return this.selectPLCAddress_dropdownlist;
    },
    setPLCList() {

    },

    objOverlapCheck(curArray, upArray, type) {
        let notOverlapArray = [];
        curArray.forEach(cur => {
            let checkOverlap = false;
            upArray.forEach(up => {
                if (type.includes('Collection')) {
                    if (cur.CollectionInfoId === up.CollectionInfoId) {
                        checkOverlap = true;
                    }
                }
                else {
                    if (cur.PLCAddress === up.PLCAddress && cur.BlockInfoId === up.BlockInfoId) {
                        checkOverlap = true;
                    }
                }

            });
            if (!checkOverlap) {
                notOverlapArray.push(cur);
            }
        });

        return notOverlapArray;
    },
    async setDBCollectionBlock(clientData) {
        try {

            let blockPlcAddressList = [];
            let updateCollection = JSON.parse(JSON.stringify(clientData));
            let updateBlocklist = [];
            if (updateCollection.length > 0) {
                updateCollection.map((col) => {
                    col.CollectionInfoId = col.id;
                    col.EquipmentId = this.currentPlcInfoId;
                    col.CollectionName = col.name;
                    const tempBlock = col.BlockList;
                    if (tempBlock != undefined && tempBlock.length > 0) {
                        tempBlock.map((block) => {
                            block.CollectionInfoId = col.id;
                            block.EquipmentId = this.currentPlcInfoId;
                            if (block.BlockInfoId != undefined)
                                block.BlockInfoId = block.BlockInfoId;
                            else
                                block.BlockInfoId = block.id;
                            block.BlockStartAddress = block.StartAddress;
                            block.BlockEndAddress = block.EndAddress;
                            block.BlockName = block.name;
                            block.BlockSize = block.BlockSize;
                            block.AddressType = block.AddressType;
                            //block.Unit = block.Unit;

                            // if(this.currentPlcType === 1)
                            //     block.BlockSize = block.EndAddress.slice(1) - block.StartAddress.slice(1) +1;
                            // else if(this.currentPlcInfoId === 2)
                            //     block.BlockSize = block.EndAddress.split('.').replace('/[^0-9]/g', "") - block.StartAddress.split('.').replace('/[^0-9]/g', "") +1;
                            for (let i = 0; i < block.BlockSize; i++) {
                                let findPlc = null;
                                if (this.currentPlcType === 0) {
                                    findPlc = this.plcMemoryMap.find((curPlc) =>
                                        curPlc.PLCAddress === block.StartAddress[0] + (parseInt(block.StartAddress.slice(1)) + (i) && curPlc.BlockInfoId === block.BlockInfoId
                                        ));
                                }
                                else if (this.currentPlcType === 1) {
                                    findPlc = this.plcMemoryMap.find((curPlc) =>
                                        curPlc.PLCAddress === block.StartAddress.slice(0, block.StartAddress.split('.')[0].length + block.StartAddress.split('.')[1].search(/[0-9]/g)) + (parseInt(block.StartAddress.split('.')[1].slice(block.StartAddress.split('.')[1].search(/[0-9]/g))) + (i) && curPlc.BlockInfoId === block.BlockInfoId

                                        ));
                                }

                                if (findPlc != undefined) {
                                    blockPlcAddressList.push(this.changeDBFormatAddress(findPlc));
                                }
                                else {
                                    blockPlcAddressList.push({
                                        "PLCAddressInfoId": parseInt(new Date().getTime()) + i,
                                        "PLCAddress": this.currentPlcType === 0 ? block.StartAddress[0] + (parseInt(block.StartAddress.slice(1)) + (i))
                                            : this.currentPlcType === 1 ? block.StartAddress.slice(0, block.StartAddress.split('.')[0].length + block.StartAddress.split('.')[1].search(/[0-9]/g)) + (parseInt(block.StartAddress.split('.')[1].slice(block.StartAddress.split('.')[1].search(/[0-9]/g))) + (i))
                                                : "NaN",
                                        "ParameterName": "",
                                        "SelectAddress_1": 'None',
                                        "FormulaType": 0,
                                        "FormulaMode": 0,
                                        "SelectAddress_2": "None",
                                        "DigitalLength": 1,
                                        "DataType": this.currentPlcType === 0 ? 2
                                            : this.currentPlcType === 1 ? 1
                                                : 'Nan',
                                        "StandardValue" : 0,
                                        "LowerErrorThreshold": 0,
                                        "UpperErrorThreshold": 0,
                                        "BlockStartAddress": block.StartAddress,
                                        "CollectionName": col.CollectionName,
                                        "BlockInfoId": block.BlockInfoId,
                                        "UpdateDate": new Date().toISOString(),
                                        "IsRecipe": false,
                                        "IsFlexibleIp": false,
                                        "Value": 0,
                                        "Unit": '',
                                    });
                                }

                            }
                            block.UpdateDate = new Date().toISOString();
                        });
                        updateBlocklist.push(tempBlock.slice());
                    }

                    col.UpdateDate = new Date().toISOString();
                    delete col.BlockList;
                });
            }
            if (updateBlocklist.length > 0) {
                updateBlocklist = updateBlocklist.reduce(function (acc, cur) {
                    return acc.concat(cur);
                });

            }

            let removeCollection = [];
            let removeBlock = [];
            let sendResult = [];
            removeCollection = this.objOverlapCheck(this.collectionMap, updateCollection, "CollectionInfoId");
            removeBlock = this.objOverlapCheck(this.blockMap, updateBlocklist, "CollectionInfoId");
            if (removeCollection.length > 0) {
                sendResult.push(await Fetcher('post', '/plcAPI/deleteCollectionInfoList', removeCollection));
            }
            if (removeBlock.length > 0) {
                sendResult.push(await Fetcher('post', '/plcAPI/deleteBlockInfoList', removeBlock));
            }
            if (updateCollection.length > 0)
                sendResult.push(await Fetcher('post', '/plcAPI/updateCollectionInfoList', updateCollection));
            if (updateBlocklist.length > 0)
                sendResult.push(await Fetcher('post', '/plcAPI/updateBlockInfoList', updateBlocklist));

            if (sendResult.includes(false)) {
                return false;
            }
            else {
                this.blockMap = updateBlocklist;
                this.collectionMap = updateCollection;

                let removePlcAddress = this.objOverlapCheck(JSON.parse(JSON.stringify(this.plcMemoryMap)), blockPlcAddressList, "PLCAddress");
                sendResult = [];

                if (removePlcAddress != undefined) {
                    sendResult.push(await Fetcher('post', '/plcAPI/deletePLCAddressInfo', removePlcAddress));
                }
                if (blockPlcAddressList != undefined) {
                    sendResult.push(await Fetcher('post', '/plcAPI/updatePLCAddressInfo', { 'PLCAddressList': blockPlcAddressList }));
                }

                if (!sendResult.includes(false)) {
                    this.plcMemoryMap = blockPlcAddressList.map((item) => ({
                        ...this.changeClientFormatAddress(item),
                    }));
                }
                return true;
            }

        } catch (error) {
            console.log(error);
            return false;
        }
    },

    async setDBPLCMemoryMap(clientDatas) {        
        try {
            this.plcMemoryMap = clientDatas;
            this.dbFormatPlcMap = clientDatas.map((clientData) => ({
                ...this.changeDBFormatAddress(clientData),
                ['upsert']: true
            }));
            return (await Fetcher('post', '/plcAPI/updatePLCAddressInfo', { 'PLCAddressList': this.dbFormatPlcMap }));

        } catch (error) {
            console.log(error);
            return false;
        }

    },
    changeDBFormatAddress(clientData) {        
        return {
            ["CollectionInfoId"]: clientData.CollectionInfoId,
            ["PLCAddressInfoId"]: clientData.PLCAddressInfoId,
            ["PLCAddress"]: clientData.PLCAddress,
            ["BlockInfoId"]: clientData.BlockInfoId,
            ["ParameterName"]: clientData.ParameterName,
            ["DigitalLength"]: clientData.DigitalLength,
            ["SelectAddress_1"]: clientData.SelectAddress_1,
            ["SelectAddress_2"]: clientData.SelectAddress_2,
            ["DataType"]: clientData.DataType === "BIT" ? 0
                : clientData.DataType === "BYTE" ? 1
                    : clientData.DataType === "WORD" ? 2
                        : 3,
            ["FormulaMode"]: clientData.FormulaType === "SingleMode" ? 0 : 1,
            ["FormulaType"]: clientData.FormulaType === "+" ? 0
                : clientData.FormulaType === "-" ? 1
                    : clientData.FormulaType === "*" ? 2
                        : 3,
            ["StandardValue"] : clientData.StandardValue,
            ["LowerErrorThreshold"]: clientData.LowerErrorThreshold,
            ["UpperErrorThreshold"]: clientData.UpperErrorThreshold,
            ["IsRecipe"]: clientData.IsRecipe === "True" ? true : false,
            ["IsFlexibleIp"]: clientData.IsFlexibleIp === "True"? true : false,
            ["Value"]: 0,
        };
    },
    changeClientFormatAddress(dbData) {
        return {
            ["CollectionInfoId"]: dbData.CollectionInfoId,
            ["PLCAddressInfoId"]: dbData.PLCAddressInfoId,
            ["PLCAddress"]: dbData.PLCAddress,
            ["BlockInfoId"]: dbData.BlockInfoId,
            ["Collection"]: dbData.CollectionName,
            ["StartAddress"]: dbData.BlockStartAddress,
            ["ParameterName"]: dbData.ParameterName,
            ["DigitalLength"]: dbData.DigitalLength,
            ["SelectAddress_1"]: dbData.SelectAddress_1,
            ["SelectAddress_2"]: dbData.SelectAddress_2,
            ["DataType"]: dbData.DataType === 0 ? "BIT"
                : dbData.DataType === 1 ? "Byte"
                    : dbData.DataType === 2 ? "WORD"
                        : "DWORD",
            ["FormulaType"]: dbData.FormulaMode === 0 ? "SingleMode"
                : dbData.FormulaType === 0 ? "+"
                    : dbData.FormulaType === 1 ? "-"
                        : dbData.FormulaType === 2 ? "*"
                            : 3,
            ["StandardValue"] : Number(dbData.StandardValue),
            ["LowerErrorThreshold"]: Number(dbData.LowerErrorThreshold),
            ["UpperErrorThreshold"]: Number(dbData.UpperErrorThreshold),
            ["IsRecipe"]: dbData.IsRecipe === true ? "True" : "False",
            ["IsFlexibleIp"]: dbData.IsFlexibleIp === true ? "True" : "False",
            ["Value"]: 0,
        };
    },
    async deleteAllCollectionBlockInfoByPlcId() {
        return await Fetcher('post', '/plcAPI/deleteAllCollectionBlockInfoByPlcId', { 'PlcId': this.currentPlcInfoId });
    },
    async getDBPLCList() {
        const dbPLCList = await Fetcher('get', '/plcAPI/getAllPLCInfo');
        this.plcList = [];
        this.plcTypeList = [];
        dbPLCList.forEach(dbPlcItem => {

            let IPAddress = dbPlcItem.Port === '' || dbPlcItem.Port === undefined? dbPlcItem.Ip : dbPlcItem.Ip + ':' + dbPlcItem.Port
            this.plcList.push(`${dbPlcItem.PlcName}(${IPAddress})`);
            this.plcTypeList.push(dbPlcItem.PlcType)
        });
        this.currentPlcType = this.plcTypeList[0];

        if (this.plcList.length > 0) {
            await Promise.allSettled([

                this.getDBCollectionList(),
                this.getDBBlockList(),
                this.getDBPLCAddressList(),
                //this.makeStandardInfo(),
                //this.makeStandardView(),
            ]);
        }

        return this.plcList;
    },
    async getDBCollectionList() {
        try {
            this.collectionMap = [];
            const dbFormatCollection = await Fetcher('post', '/plcAPI/getCollectionByPlcId', { 'PlcId': String(this.currentPlcInfoId) });
            if (dbFormatCollection.length > 0) {
                this.collectionMap = dbFormatCollection;
            }
            
        } catch (error) {
            console.log(error);
        }

    },
    async getDBBlockList() {
        try {
            this.blockMap = [];

            const dbFormatBlock = await Fetcher('post', '/plcAPI/getBlockByPlcId', { 'PlcId': this.currentPlcInfoId });
            if (dbFormatBlock.length > 0) {
                this.blockMap = dbFormatBlock;
            }

        } catch (error) {
            console.log(error);
        }

    },
    async getDBPLCAddressList() {
        const dbFormatPlcMap = await Fetcher('post', '/plcAPI/getPlcAddressByPlcId', { 'PlcId': this.currentPlcInfoId });
        this.plcMemoryMap = [];
        if (dbFormatPlcMap.length > 0) {
            //console.log(dbFormatPlcMap);
            this.plcMemoryMap = dbFormatPlcMap.map((dbData) => ({
                ...this.changeClientFormatAddress(dbData),
            }));
        }
    },

    async setDBImportCollectionBlock() {
        let sendResult = [];
        sendResult.push(await Fetcher('post', '/plcAPI/addCollectionInfo', this.importCollection));
        sendResult.push(await Fetcher('post', '/plcAPI/addBlockInfo', this.importBlock));
        // sendResult.push(await Fetcher('post', '/plcAPI/addPLCAddressInfo', this.importPlcAddress));
        
        if (!sendResult.includes(false)) {
            this.blockMap = this.importBlock;
            this.collectionMap = this.importCollection;
            return true;
        }

        else {
            return false;
        }

    },

    async makeStandardInfo() {
        const dbFormatPlcMap = await Fetcher('post', '/plcAPI/getPlcAddressByPlcId', { 'PlcId': this.currentPlcInfoId });        
        const standardInfos = dbFormatPlcMap.reduce((acc, item) => {
            const groupKey = item.CollectionName;
            const subGroupKey = item.BlockName;

            if (!acc[groupKey]) {
                acc[groupKey] = {};
            }
            if (!acc[groupKey][subGroupKey]) {
                acc[groupKey][subGroupKey] = [];
            }
            acc[groupKey][subGroupKey].push(item);
            return acc;
        }, {});

        console.log(standardInfos);
    },

    async makeStandardView(){
        const dbFormatPlcMap = await Fetcher('post', '/plcAPI/getPlcAddressByPlcId', { 'PlcId': this.currentPlcInfoId });
        const standardView = dbFormatPlcMap.reduce((acc, obj) => {
            const {PLCAddress} = obj;
            acc[PLCAddress] = acc[PLCAddress] ?? [];
            acc[PLCAddress].push(obj);
            return acc;
        }, {});

        for(let i = 0; i < Object.keys(standardView).length; i++){
            let key = Object.keys(standardView)[i];            
            standardView[key] = standardView[key][0];
        }
        console.log(standardView);
    },

    async alertMessage(msg, type) {
        if (type == "error") {
            swal.fire({
                title: msg,
                text: "",
                icon: "error",
                confirmButtonText: "OK",
                customClass: {
                    container: 'swal2-container'
                }
            });
        }
        else if (type == "success") {
            swal.fire({
                title: msg,
                text: "",
                icon: "success",
                confirmButtonText: "OK",
                customClass: {
                    container: 'swal2-container'
                }
            });
        }
    },

    async changeSelectPlcCollection(selectIndex) {
        this.currentPlcInfoId = selectIndex;
        this.currentPlcType = this.plcTypeList[selectIndex - 1];
        await Promise.allSettled([
            this.getDBCollectionList(),
            this.getDBBlockList(),
            this.getDBPLCAddressList(),
        ]);
    },
    async changeSelectPlc(selectIndex) {
        this.currentPlcInfoId = selectIndex;
        this.currentPlcType = this.plcTypeList[selectIndex - 1];
        await Promise.allSettled([
            this.getDBCollectionList(),
            this.getDBBlockList(),
            this.getDBPLCAddressList(),
        ]);
    },
    validationCheckImportCSV(importData) {
        let collection = [];
        let block = [];
        let plcAddress = [];

        plcAddress = new Set(
            importData.map((p) => (p.PLCAddress ? p.PLCAddress : ""))
        );
        if (plcAddress.length !== importData.size) {
            //PlcAddress 중복 존재            
            return false;
        }
        collection = importData.reduce((acc, obj) => {
            const { CollectionInfoId } = obj;
            // acc[name]이 있으면 acc[name]의 값을 할당 없으면, 빈 배열을 할당
            acc[CollectionInfoId] = acc[CollectionInfoId] ?? [];
            // acc[name]에 객체를 추가
            acc[CollectionInfoId].push(obj);
            return acc;
        }, {});
        block = importData.reduce((acc, obj) => {
            const { BlockInfoId } = obj;
            // acc[name]이 있으면 acc[name]의 값을 할당 없으면, 빈 배열을 할당
            acc[BlockInfoId] = acc[BlockInfoId] ?? [];
            // acc[name]에 객체를 추가
            acc[BlockInfoId].push(obj);
            return acc;
        }, {});

        this.importCollection = [];
        console.log(Object.keys(collection).f);
        this.importCollection = Object.keys(collection).map((col) => ({
            
            // CollectionName: col.Collection,
            // CollectionInfoId: parseInt(new Date().getTime()) + Object.keys(collection).indexOf(col),
            CollectionName: collection[col][0].Collection,
            CollectionInfoId: col,
            EquipmentId: this.currentPlcInfoId,
            SendPeriod: 1,
            UpdateDate: new Date().toISOString(),
        }));        

        this.importBlock = [];
        this.importBlock = Object.keys(block).map((blk) => ({
            EquipmentId: this.currentPlcInfoId,
            // CollectionInfoId: this.importCollection.find((c) => c.CollectionName === (block[blk][0].Collection)).CollectionInfoId,
            // BlockInfoId: parseInt(new Date().getTime()) + Object.keys(block).indexOf(blk),
            // BlockName: 'Block_' + parseInt(new Date().getTime()) + Object.keys(block).indexOf(blk),
            CollectionInfoId: this.importCollection.find((c) => c.CollectionName === (block[blk][0].Collection)).CollectionInfoId,
            BlockInfoId: blk,
            BlockName: 'Block_' + parseInt(new Date().getTime()) + Object.keys(block).indexOf(blk),
            BlockStartAddress: block[blk][0].StartAddress,
            BlockEndAddress: block[blk].slice(-1)[0].PLCAddress,
            Editable: true,
            UpdateDate: new Date().toISOString(),
            BlockSize: block[blk].slice(-1)[0].PLCAddress.slice(1) - block[blk][0].StartAddress.slice(1) + 1,
        }));

        importData.forEach(plcItem => {
            plcItem.BlockInfoId = this.importBlock.find((b) => b.BlockStartAddress === plcItem.StartAddress).BlockInfoId;
            plcItem.CollectionInfoId = this.importBlock.find((b) => b.BlockStartAddress === plcItem.StartAddress).CollectionInfoId;
            plcItem.IsFlexibleIp = plcItem.IsFlexibleIp === "T" ? true : false;
            plcItem.IsRecipe = plcItem.IsRecipe === "T" ? true : false;
        });        
       
        return true;
    }
});

export { PLCAddressEditStore };