import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import swal from 'sweetalert2';
import i18n from "i18next";

const regExpName = /^[0-9a-zA-Z_]{0,}$/;
const regExpMail = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;
const regExpPhoneNumber = /^[0-9]{2,4}-[0-9]{2,4}(-[0-9]{2,4})?$/g;

const userManagementStore = observable({
    userId: '',
    userAuthority: 1,
    userEnabled: '',
    userPhoneNumber: '',
    userName: '',
    userMail: '',
    userPassword: '',
    isSelected : false,
    localStorage : window.localStorage,

    onChangeId(e, id) {
        let formatCheckresult = regExpName.test(id);

        if (formatCheckresult !== true && this.userId !== '' && id !== '') {
            this.userId = '';

            swal.fire({
                title: i18n.t('MSG_TEXT_ONLY'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });

            this.userId = '';
        }
        else {
            this.userId = id;
        }
    },

    onChangeAuthority(authority) {
        this.userAuthority = authority;
    },

    onChangeEnable(enable) {
        this.userEnabled = enable;
    },

    onChangePhoneNumber(phoneNumber) {
        this.userPhoneNumber = phoneNumber;
    },

    onChangeName(name) {
        this.userName = name;
    },

    clearUserInfo(){
        this.userId = '';
        this.userAuthority = 1;
        this.userEnabled = '';
        this.userPhoneNumber = '';
        this.userName = '';
        this.userMail = '';
        this.userPassword = '';
        this.isSelected = false;
    },

    onChangeSelectedUserInfo(user) {
        if (user === undefined) {
            this.clearUserInfo();
        }
        else {
            this.userId = user.UserId;
            this.userAuthority = user.Authority;
            this.userEnabled = user.Enabled;
            this.userPhoneNumber = user.PhoneNumber;
            this.userName = user.UserName;
            this.userMail = user.Mail;
            this.userPassword = user.Password;
            this.isSelected = user.isSelected;
        }
    },

     onCheckPhoneNumberFormat() {
        if (this.userPhoneNumber === '') {
            return;
        }

        let formatCheckresult = regExpPhoneNumber.test(this.userPhoneNumber);

        if (formatCheckresult !== true) {
            this.userPhoneNumber ='';
            swal.fire({
                title: i18n.t('MSG_PHONE_NUMBER_FORMAT_WRONG'),
                test: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
        }
    },

    onChangeMail(mail) {
        this.userMail = mail;
    },

    onCheckMailFormat() {
        if (this.userMail === '') {
            return;
        }

        let formatCheckresult = regExpMail.test(this.userMail)

        if (formatCheckresult !== true) {
            this.userMail = '';
            swal.fire({
                title: i18n.t('MSG_MAIL_FORMAT_WRONG'),
                text: "",
                icon: "warning",
                confirmButtonText: "OK"
            });
        }
    },

    onChangePassword(pwd) {
        this.userPassword = pwd;
    },

    async deleteUserInfo(){
        let loginUser = JSON.parse(sessionStorage.getItem('loginUser'));
        let returnVal = false;

        if(this.userId === ''){
            swal.fire({
                title: i18n.t('MSG_SELECT_USER'),
                text: "",
                icon: "info",
                confirmButtonText: "OK"
            });
            return returnVal;
        }
        
        if(this.userId ===loginUser.UserId){
            swal.fire({
                title: i18n.t('MSG_LOGINED_USER'),
                text: "",
                icon: "info",
                confirmButtonText: "OK"
            });
            return returnVal;
        }


        let deleteInfo = {
            userId : this.userId
        }

        returnVal = await Fetcher('post', '/httpAPI/deleteUserInfo', deleteInfo);

        if(returnVal){
            this.clearUserInfo();
            swal.fire({
                title: i18n.t('MSG_USER_INFO_DELETE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else{
            swal.fire({
                title: i18n.t('MSG_USER_INFO_DELETE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }

        return returnVal;
    },

    async onSaveUserInfo(userList) {

        if (this.userId === '' ||
            this.userAuthority === '' ||
            this.userPhoneNumber === '' ||
            this.userName === '' ||
            this.userMail === '' ||
            this.userPassword === ''
        ) {
            swal.fire({
                title: i18n.t('MSG_USER_INFO_ENTER_PLEASE'),
                text: "",
                icon: "info",
                confirmButtonText: "OK"
            });

            return;
        }

        if(!this.isSelected){
            for(let user of userList){
                if(user.id === this.userId){
                    swal.fire({
                        title: i18n.t('MSG_USER_ID_DUPLICATED'),
                        text: "",
                        icon: "info",
                        confirmButtonText: "OK"
                    });

                    return;
                }
            }
        }

        let saveUser = {
            UserId: this.userId,
            Authority: this.userAuthority,
            Enabled: this.userEnabled,
            PhoneNumber: this.userPhoneNumber,
            UserName: this.userName,
            Mail: this.userMail,
            Password: this.userPassword
        }

        let result = await Fetcher('post', '/httpAPI/addUserInfo', saveUser);

        if (result.ok === 1) {
            let returnVal = {
                result: true,
                data: saveUser
            }

            this.clearUserInfo();

            return returnVal;
        }
        else {
            return false;
        }
    }
    
});

export { userManagementStore };