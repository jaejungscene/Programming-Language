import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const addEquipmentStore = observable ({
    equipmentName: "",
    equipmentType: 1,
    protocolType: 1,
    equipmentIp: "",

    async onChangeEquipmentName(value){
        this.equipmentName = value
    },

    async onChangeEquipmentType(value){
        this.equipmentType = value
    },

    async onChangeEquipmentPLCType(value){
        this.protocolType = value
    },

    async onChangeEquipmentIp(value){
        this.equipmentIp = value
    },

    async onSaveEquipment() {
      let equipment = {
            EquipmentName: this.equipmentName,
            EquipmentType: this.makeEqpId,
            ProtocolType: this.protocolType,
            EquipmentIp: this.equipmentIp,
        }
        equipment = JSON.parse(JSON.stringify(equipment));
        let result = await Fetcher('post', '/httpAPI/addEquipmentInfo', equipment);
        
        return result;
    },

    clearData(){
    this.equipmentName = "";
    this.equipmentType = 1;
    this.protocolType = 1;
    this.equipmentIp = "";
    },

    equipmentNameValidationCheck(){
        if(this.equipmentName === ""){
            return false;
        }else{
            return true;
        }

    },

    ipValidationCheck(){
        let ip = this.equipmentIp.split(':')[0];
        let regex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        
        if(regex.test(ip)) {
            return true;
        }else{
            return false;
        }
    },

    portValidationCheck(){
        let port = Number(this.equipmentIp.split(':')[1]);
        if( Number.isInteger(port) && port >= 1 && port <= 65535) {            
            return true;
        }else{

            return false;
        }
    }
    
});

export { addEquipmentStore };