import { observable } from 'mobx';
import i18n from "i18next";
import Fetcher from '../components/parts/Common/Fetcher';
var moment = require('moment');

const ALARM_TYPE = {
    0: 'Warning',
    1: 'Error'
}

const PARTS_TYPE = {
    'Roll_Front' : 'Roll_Front',
    'Roll_Rear' : 'Roll_Rear',
    'Dryer_1' : 'Dryer_1',
    'Dryer_2' : 'Dryer_2',
    'Dryer_3' : 'Dryer_3',
    'Dryer_4' : 'Dryer_4',
    'Dryer_5' : 'Dryer_5',
    'Dryer_6' : 'Dryer_6',
}

const ROLL_FRONT_LIST = ['D14000', 'D14001', 'D14004', 'D14007', 'D14053', 'D14054','D14060', 'D14067', 'D14069', 'D14070', 'D14071'];
const ROLL_REAR_LIST = ['D14002', 'D14003', 'D14005','D14006','D14008','D14009', 'D14010', 'D14055','D14056','D14057'];
const DRYER1_LIST = ['D14011','D14012','D14013','D14014', 'D14015','D14016','D14017'];
const DRYER2_LIST = ['D14018','D14019','D14020','D14021','D14022','D14023','D14024'];
const DRYER3_LIST = ['D14025','D14026','D14027','D14028','D14029','D14030','D14031'];
const DRYER4_LIST = ['D14032','D14033','D14034','D14035','D14036','D14037','D14038'];
const DRYER5_LIST = ['D14039','D14040','D14041','D14042','D14043','D14044','D14045'];
const DRYER6_LIST = ['D14046','D14047','D14048','D14049','D14050','D14051','D14052'];
    

const alertStore = observable({
    webSocket : null,
    alertList: [],
    alertCount: 0,
    isExistNewAlert : false,
    selectedModule : '',
    selectedModuleList : [],
    modalOpenTime : '',

    rollFrontAlertListData : { data : [], toolTip : 'Roll_Front', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    rollRearAlertListData : { data : [], toolTip : 'Roll_Rear', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    dryer1AlertListData : { data : [], toolTip : 'Dryer_1', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    dryer2AlertListData : { data : [], toolTip : 'Dryer_2', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    dryer3AlertListData : { data : [], toolTip : 'Dryer_3', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    dryer4AlertListData : { data : [], toolTip : 'Dryer_4', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    dryer5AlertListData : { data : [], toolTip : 'Dryer_5', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },
    dryer6AlertListData : { data : [], toolTip : 'Dryer_6', className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' },

    async initialize(websocket){
        this.webSocket = websocket;

        this.webSocket.on("dateChangeBroadcast", ()=>{
            this.alertCount = 0;
        });
    },

    addAlertList(data){
        //this.alertList.unshift(data);
        this.alertCount += data.length;
        if(!this.isExistNewAlert){
            this.isExistNewAlert = true;
        }
        
    },
    async getAlertList(){
        let datas = await Fetcher('get', '/httpAPI/getTodayAlarmList');
        for(let data of datas){
            data.ModuleInfoId = data.CollectionName;
            data.Name = `${data.BlockName}_${data.ParameterName}`;
            data.CreDate = moment(data.CreDate).format("YYYY-MM-DD HH:mm:ss");
            data.AlarmType = ALARM_TYPE[data.AlarmType]; 
            this.alertList.push(data);
        }
    },

    async getAlertCount() {
        let data = await Fetcher('get', '/httpAPI/getTodayAlarmCount');
        this.alertCount = data.count;        
        return this.alertCount;
    },

    async initAlertList() {        
        this.alertList.splice(0);

         //login User check
         let loginUser = sessionStorage.getItem('loginUser');
         loginUser = JSON.parse(loginUser)
         if (loginUser) {
            this.getAlertCount();
         }

         if(this.selectedModule === PARTS_TYPE['Roll_Front']){
            this.rollFrontAlertListData = { data : [], toolTip : PARTS_TYPE['Roll_Front'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Roll_Rear']){
            this.rollRearAlertListData = { data : [], toolTip : PARTS_TYPE['Roll_Rear'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Dryer_1']){
            this.dryer1AlertListData = { data : [], toolTip : PARTS_TYPE['Dryer_1'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Dryer_2']){
            this.dryer2AlertListData = { data : [], toolTip : PARTS_TYPE['Dryer_2'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Dryer_3']){
            this.dryer3AlertListData = { data : [], toolTip : PARTS_TYPE['Dryer_3'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Dryer_4']){
            this.dryer4AlertListData = { data : [], toolTip : PARTS_TYPE['Dryer_4'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Dryer_5']){
            this.dryer5AlertListData = { data : [], toolTip : PARTS_TYPE['Dryer_5'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(this.selectedModule === PARTS_TYPE['Dryer_6']){
            this.dryer6AlertListData = { data : [], toolTip : PARTS_TYPE['Dryer_6'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }

        this.selectedModule = '';
        this.modalOpenTime = '';
        this.selectedModuleList = [];
        this.isExistNewAlert = false;
    },

    removeBlinkEffect(parts){
        if(parts === PARTS_TYPE['Roll_Front']){
            this.rollFrontAlertListData = { toolTip : PARTS_TYPE['Roll_Front'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Roll_Rear']){
            this.rollRearAlertListData = { toolTip : PARTS_TYPE['Roll_Rear'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Dryer_1']){
            this.dryer1AlertListData = { toolTip : PARTS_TYPE['Dryer_1'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Dryer_2']){
            this.dryer2AlertListData = { toolTip : PARTS_TYPE['Dryer_2'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Dryer_3']){
            this.dryer3AlertListData = { toolTip : PARTS_TYPE['Dryer_3'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Dryer_4']){
            this.dryer4AlertListData = { toolTip : PARTS_TYPE['Dryer_4'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Dryer_5']){
            this.dryer5AlertListData = { toolTip : PARTS_TYPE['Dryer_5'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
        else if(parts === PARTS_TYPE['Dryer_6']){
            this.dryer6AlertListData = { toolTip : PARTS_TYPE['Dryer_6'], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        }
    },

    async clearAlertDatas(){
        this.rollFrontAlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.rollRearAlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.dryer1AlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.dryer2AlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.dryer3AlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.dryer4AlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.dryer5AlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
        this.dryer6AlertListData = { data : [], className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' };
    },

    async getNoneCheckedAlertListByPLCAddressId(e){        
        if(e === PARTS_TYPE['Roll_Front']){
            this.selectedModuleList = ROLL_FRONT_LIST;
        }
        else if(e === PARTS_TYPE['Roll_Rear']){
            this.selectedModuleList = ROLL_REAR_LIST;
        }
        else if(e === PARTS_TYPE['Dryer_1']){
            this.selectedModuleList = DRYER1_LIST;
        }
        else if(e === PARTS_TYPE['Dryer_2']){
            this.selectedModuleList = DRYER2_LIST;
        }
        else if(e === PARTS_TYPE['Dryer_3']){
            this.selectedModuleList = DRYER3_LIST;
        }
        else if(e === PARTS_TYPE['Dryer_4']){
            this.selectedModuleList = DRYER4_LIST;
        }
        else if(e === PARTS_TYPE['Dryer_5']){
            this.selectedModuleList = DRYER5_LIST;
        }
        else if(e === PARTS_TYPE['Dryer_6']){
            this.selectedModuleList = DRYER6_LIST;
        }
        else{
            return;
        }
        let params = {
            //equipmentId : this.selectedEquipmentId,
            moduleList : this.selectedModuleList,
            time : this.modalOpenTime
        }
        let datas = await Fetcher('get', 'httpAPI/getNoneCheckedAlarmListByPLCAddressId', {params});

        for(let data of datas){ 
            data.ModuleInfoId = data.CollectionName;
            data.Name = `${data.BlockName}_${data.ParameterName}`;
            data.CreDate = moment(data.CreDate).format("YYYY-MM-DD HH:mm:ss");
            data.AlarmType = ALARM_TYPE[data.AlarmType]; 
            this.alertList.push(data);
        }

    },

    setAlarmListDataByParts(datas){
        //각 부위 Roll(Front,Rear), Dryer(1Zone ~ 6Zone)별 Alert List -> 이미지 표시용
        let rollFrontAlertList = [];
        let rollRearAlertList = [];
        let dryer1AlertList = [];
        let dryer2AlertList = [];
        let dryer3AlertList = [];
        let dryer4AlertList = [];
        let dryer5AlertList = [];
        let dryer6AlertList = [];

        for(let data of datas){            
            if(ROLL_FRONT_LIST.includes(data.PLCAddress)){
                rollFrontAlertList.push(data);
            }
            else if(ROLL_REAR_LIST.includes(data.PLCAddress )){
                rollRearAlertList.push(data);
            }
            else if(DRYER1_LIST.includes(data.PLCAddress)){
                dryer1AlertList.push(data);
            }
            else if(DRYER2_LIST.includes(data.PLCAddress)){
                dryer2AlertList.push(data);
            }
            else if(DRYER3_LIST.includes(data.PLCAddress)){
                dryer3AlertList.push(data);
            }
            else if(DRYER4_LIST.includes(data.PLCAddress)){
                dryer4AlertList.push(data);
            }
            else if(DRYER5_LIST.includes(data.PLCAddress)){
                dryer5AlertList.push(data);
            }
            else if(DRYER6_LIST.includes(data.PLCAddress)){
                dryer6AlertList.push(data);
            }
        }

        //Roll_Front
        if(rollFrontAlertList.length !== 0){
            let isErrorExist = rollFrontAlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.rollFrontAlertListData = {
                toolTip : toolTip,
                data : rollFrontAlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }
        //Roll_Rear
        if(rollRearAlertList.length !== 0){
            let isErrorExist = rollRearAlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.rollRearAlertListData = {
                toolTip : toolTip,
                data : rollRearAlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }
        //Dryer1
        if(dryer1AlertList.length !== 0){
            let isErrorExist = dryer1AlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.dryer1AlertListData = {
                toolTip : toolTip,
                data : dryer1AlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }
        //Dryer2
        if(dryer2AlertList.length !== 0){
            let isErrorExist = dryer2AlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.dryer2AlertListData = {
                toolTip : toolTip,
                data : dryer2AlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }
        //Dryer3
        if(dryer3AlertList.length !== 0){
            let isErrorExist = dryer3AlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.dryer3AlertListData = {
                toolTip : toolTip,
                data : dryer3AlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }
        //Dryer4
        if(dryer4AlertList.length !== 0){
            let isErrorExist = dryer4AlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.dryer4AlertListData = {
                toolTip : toolTip,
                data : dryer4AlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }

        //Dryer5
        if(dryer5AlertList.length !== 0){
            let isErrorExist = dryer5AlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.dryer5AlertListData = {
                toolTip : toolTip,
                data : dryer5AlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }

        
        //Dryer6
        if(dryer6AlertList.length !== 0){
            let isErrorExist = dryer6AlertList.some(alertData => ALARM_TYPE[alertData.AlarmType] === 'Error');
            let toolTip = 'Alarm!';
            let fillColor  = isErrorExist ? "#ff0000" : "#ff5e00";
            let fillOpacity = '0.3';

            this.dryer6AlertListData = {
                toolTip : toolTip,
                data : dryer6AlertList,
                className : 'blinkSvgImage',
                fillColor : fillColor,
                fillOpacity : fillOpacity,
                cursor : 'pointer'
            }
        }
    }
});

export {alertStore};