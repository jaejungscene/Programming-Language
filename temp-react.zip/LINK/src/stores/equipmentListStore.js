import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import swal from 'sweetalert2';
import i18n from "i18next";

const equipmentListStore = observable ({
    equipmentList: [],
    connectionList: [],
    webSocket: undefined,
    
    async onChangeEquipmentType(id, value){
        for(let item of this.equipmentList){
            if(id === item.EquipmentId){
                if(item.isRunning){
                    swal.fire({
                        title: i18n.t('MSG_EQUIPMENT_RUN'),
                        text: "",
                        icon: "warning",
                        confirmButtonText: "OK"
                    });
                    break;
                }

                item.EquipmentType = value
                break;
            }
        }
    },

    async onChangeEquipmentPLCType(id, value){
        for(let item of this.equipmentList){
            if(id === item.EquipmentId){
                if(item.isRunning){
                    swal.fire({
                        title: i18n.t('MSG_EQUIPMENT_RUN'),
                        text: "",
                        icon: "warning",
                        confirmButtonText: "OK"
                    });
                    break;
                }
                
                item.ProtocolType = value
                break;
            }
        }
    },

    async onChangeEquipmentMode(id, enable){
        for(let item of this.equipmentList){
            if(id === item.EquipmentId){
                if(item.isRunning){
                    swal.fire({
                        title: i18n.t('MSG_EQUIPMENT_RUN'),
                        text: "",
                        icon: "warning",
                        confirmButtonText: "OK"
                    });
                    break;
                }

                item.Enabled = enable
                break;
            }
        }
    },

    async connectionTest(id){
        let equipmentList = {
            EquipmentId : id
        }
        equipmentList = JSON.parse(JSON.stringify(equipmentList));
        let result = await Fetcher('post', '/httpAPI/connectionCheck', equipmentList);

        for(let index in this.equipmentList){
            if(id === this.equipmentList[index].EquipmentId){
                this.equipmentList[index].isRunning = result;
                this.connectionList[index] = true;
                break;
            }
        }
      
    },

    async saveEquipment(){
        let equipmentList = JSON.parse(JSON.stringify(this.equipmentList));
        let result = await Fetcher('post', '/httpAPI/updateEquipmentList', equipmentList);
        return result;
    },

    async initialize(websocket){
        let datas = await Fetcher('get', '/httpAPI/getEquipmentInfo');
        this.equipmentList = [];
        this.connectionList= [];
        this.webSocket = websocket;
        for (let data of datas) {
            let equipment = JSON.parse(JSON.stringify(data));
            equipment.isRunning = false;
            this.equipmentList.push(equipment);
            this.connectionList.push(false);
        }

        this.webSocket.on("machineAgentConnected", async (equipmentId) =>{
            for(let data of this.equipmentList){
                if(data.EquipmentId === equipmentId){
                    data.isRunning = true;
                    break;
                }
            }
        });

        this.webSocket.on("machineAgentDisConnected", async (equipmentId) =>{
            for(let data of this.equipmentList){
                if(data.EquipmentId === equipmentId){
                    data.isRunning = false;
                    break;
                }
            }
        });

        
        return true;
    }
})

export {equipmentListStore}