import { observable } from 'mobx';
import i18n from "i18next";
import Fetcher from '../components/parts/Common/Fetcher';
import { alertHistoryStore } from './alertHistoryStore';
var moment = require('moment');


const alarmHistoryStore = observable({
//AlarmMessage, PLCAddress, CreDate, Value, ErrorThreshold, CollectionInfoID, BlockInfoID
    alarmList: [],
    dropDownList : [],
    lastSearchValue : '0',

    InitializeControl()
    {
        let tempOption = [{value: 0, name: 'All'}];
        for(let eventName in alertHistoryStore.PARTS_TYPE){
            tempOption.push({ value: alertHistoryStore.PARTS_TYPE[eventName], name: alertHistoryStore.PARTS_TYPE[eventName] });
        }
        this.dropDownList = tempOption;
    },

    async getAlertList(from, to, collectionInfoID = undefined){

        let param = {
            from : from,
            to: to,
            collectionInfoID: collectionInfoID
        };

        let datas = await Fetcher('post', '/httpAPI/getAlarmListByDate', {param});
        this.alarmList = [];
        for(let data of datas){
            this.alarmList.push(data);
        }
    },

    async getRelatedBlockStandardInfo(blockID)
    {
        const relatedFactorList = {};
        try{
            let param = {
                blockID: blockID
            };

            let blockStandardInfo = await Fetcher('post', '/plcAPI/getRelatedBlockStandardInfo', {param})

            for(let info of blockStandardInfo){
                if (!relatedFactorList[info.BlockInfoId]) {
                    relatedFactorList[info.BlockInfoId] = [];
                }
                relatedFactorList[info.BlockInfoId].push(info);
            }
        }catch{ }
        return relatedFactorList;
    },

    async getRealTimeDataByDate(from, to, blockInfoID){
        const relatedFactorValueList = {};
        try{
            let param = {
                from : from,
                to: to,
                blockInfoID: blockInfoID
            };

            let relatedData = await Fetcher('post', '/plcAPI/getRealTimeDataByDate', {param});


            for(let data in relatedData){
                if (!relatedFactorValueList[relatedData[data].BlockInfoID]) {
                    relatedFactorValueList[relatedData[data].BlockInfoID] = [];
                }
                relatedFactorValueList[relatedData[data].BlockInfoID].push(relatedData[data]);
            }

        }catch{}
        return relatedFactorValueList;
    },


});

alarmHistoryStore.InitializeControl();

export {alarmHistoryStore};