import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const equipmentManagementStore = observable ({

    selectedEquipmentid: -1,
    selectedEquipmentRunningState : false,

    onChangeSelectedEquipmentId(eqpId, state){        
        this.selectedEquipmentid = eqpId;
        this.selectedEquipmentRunningState = state;
        console.log('equipment call');
    },

    equipmentIsRunning(){
        return this.selectedEquipmentRunningState;
    },

    async onDeleteEquipment(){
        if(this.selectedEquipmentid === -1){
            return;
        }

        if(this.selectedEquipmentRunningState){                        
            return -1;
        }

        let data = {
            EquipmentId : this.selectedEquipmentid
        }

        data = JSON.parse(JSON.stringify(data));

        let result = await Fetcher('post', '/httpAPI/deleteEquipmentInfo', data);
        if(result){
            this.selectedEquipmentid = -1;
        }
        return result
    }
  
});

export { equipmentManagementStore };