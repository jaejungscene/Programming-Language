import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const ipSettingStore = observable({

    // search condition
    collection_info_id: 0,
    block_info_id: 0,
    plc_address_info_id: 0,
    keyword: "",
    fixed_ip_info_name: "",
    unit: "",

    ipList: [],

    async initialize() {
        await this.searchIpInfo();
    },

    async searchIpInfo() {
        try {
            let param = {
                collection_info_id: this.collection_info_id,
                block_info_id: this.block_info_id,
                plc_address_info_id: this.plc_address_info_id,
                keyword: this.keyword
            }
            let result = await Fetcher('post', '/httpAPI/getIpInfoSearch', param);
            let tmp = [];
        
            if (result !== false) {
                result.map((item) => {
                    if (item.CollectionInfo.length === 1) {
                        item.collection_name = item.CollectionInfo[0].CollectionName;
                    }

                    if (item.BlockInfo.length === 1) {
                        item.block_name = item.BlockInfo[0].BlockName;
                    }

                    if (item.PlcAddressInfo.length === 1) {
                        item.plc_address_info_name = item.PlcAddressInfo[0].ParameterName;
                    }

                    item.create_date = new Date(item.create_date);
                    
                    tmp.push(item);
                });
            }

            this.ipList = tmp;
        }
        catch (err) {
            console.log(err);
        }
    },

    async deleteFixedIpInfo(id) {
        try {
            let param = {
                fixed_ip_info_id: id
            }
            return await Fetcher('post', '/httpAPI/deleteFixedIpInfobyId', param);
        }
        catch (err) {
            console.log(err);
            return false;
        }
    },

    async insertFixedIpInfo() {
        try {
            let param ={
                fixed_ip_info_name: this.fixed_ip_info_name,
                unit: this.unit,
                collection_info_id: this.collection_info_id,
                block_info_id: this.block_info_id,
                plc_address_info_id: this.plc_address_info_id
            }
            return await Fetcher('post', '/httpAPI/insertFixedIpInfo', param);
        }
        catch (err) {
            console.log(err);
            return false;
        }
    }
});


export { ipSettingStore };