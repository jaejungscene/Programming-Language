import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';


const headerViewStore = observable({    
    equipmentList : [],
    dropdownItemList : [],
    selectedEquipmentId : 0,

    async headerViewInitialize() {
        if(this.selectedEquipmentId === 0){
            await this.getEquipmentList();
        }
    },

    async getEquipmentList(){
        let datas = await Fetcher('get', '/httpAPI/getEquipmentInfoWithPlcInfo');
        this.equipmentList = [];
        for(let data of datas){
            this.equipmentList.push(data);
        }
        this.dataToDropDownItemList(this.equipmentList);        
    },

    onChangeEquipmentId(eqpId){
        this.selectedEquipmentId = eqpId;
    },

    getSelectedEquipmentId(){
        return this.selectedEquipmentId;
    },

    dataToDropDownItemList(equipmentList){
        this.dropdownItemList = [];

        for(let equipment of equipmentList){
            if(equipment.Enabled === true){
                this.dropdownItemList.push({value:equipment.EquipmentId, name:equipment.EquipmentName});    
            }
        }
        this.selectedEquipmentId = equipmentList[0].EquipmentId;
    }

})

export { headerViewStore };