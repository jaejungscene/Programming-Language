import { observable } from 'mobx';

const currentTimerStore = observable ({
    currentTime: '',

    initialize(){
        setInterval(() => {
            this.refreshDateTime();
        }, 1000);
    },

    refreshDateTime(){
        let date = new Date();
        this.currentTime = date.toLocaleTimeString();
    }
});

export { currentTimerStore };