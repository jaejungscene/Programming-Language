import { observable } from 'mobx';
import moment from 'moment';
import { alertHistoryStore } from './alertHistoryStore';
import Fetcher from '../components/parts/Common/Fetcher';



const ipDashBoardStore = observable({
    webSocket: null,
    errorList: [],
    realTimeAlarmList: [],
    workingInfo : {
        recipeId : '-', 
        startTime : '-', 
        workingTime : '-', 
        distance : '-', 
        lineSpeed : '-',
        isRunning : false,
    },
    processInfo: [],
    realTimeStorage: {},
    fixedIpStorage: {},
    equipmentId: 0,

    async leavePage() {
        this.webSocket.removeListener("workingInfoDataBroadcast", handleWorkingInfoDataBroadcast);
        this.webSocket.removeListener("standardInfoBroadcast", handleStandardInfoBroadcast);
        this.webSocket.removeListener("plcRealTimeDataBroadcast", handleRealTimeData);
        this.webSocket.removeListener("fixedIpRealTimeDataBroadcast", handleFixedIpRealTimeData);
        this.webSocket.removeListener("alarmHistoryBroadcast", handleAlarmHistoryBroadcast);
        //this.webSocket.removeListener("connect", handleConnect);
    },

    async initialize() {
        await this.refreshGetStandardInfo();
        await this.refreshGetFixedIpInfo();
        await requestPreviousData();
    },

    async initializeSocket(websocket) {
        if(this.webSocket == null){
            this.webSocket = websocket;
        }

        this.webSocket.on('workingInfoDataBroadcast', handleWorkingInfoDataBroadcast);

        this.webSocket.on('standardInfoBroadcast', handleStandardInfoBroadcast);

        this.webSocket.on('alarmHistoryBroadcast', handleAlarmHistoryBroadcast);

        //this.webSocket.on("connect", handleConnect);    //새로고침 처리

        this.webSocket.on("plcRealTimeDataBroadcast", handleRealTimeData);

        this.webSocket.on("fixedIpRealTimeDataBroadcast", handleFixedIpRealTimeData);
    },

    async refreshGetStandardInfo (standardInfo) {
        let tmpStorage = {};
        // let tmp = await Fetcher('get', '/httpAPI/getStandardInfoCollectionInfo');
        let tmp = await Fetcher('get', '/httpAPI/getStandardInfoProcess');
        if(typeof standardInfo === "undefined"){
            standardInfo = await Fetcher('get', '/plcAPI/getStandardInfo');
        }

        // 대시보드 표시할 process 항목
        this.processInfo = tmp.filter((item) => {
            if (item.EquipmentId === this.equipmentId) {
                tmpStorage[item.CollectionInfoId] ??= [];
                return true;
            }
            
            return false;
        });
        this.realTimeStorage = tmpStorage;
        
        standardInfo.map((item) => {
            if (typeof this.realTimeStorage[item.CollectionInfoId] === "undefined") {
                return;
            }

            if (item.IsFlexibleIp === false) {
                return;
            }

            this.realTimeStorage[item.CollectionInfoId][item.BlockInfoId] ??= [];
            item.dataArray = [];
            this.realTimeStorage[item.CollectionInfoId][item.BlockInfoId].push({...item});
        });
    },

    async refreshGetFixedIpInfo () {
        let tmpStorage = {};
        let tmp = await Fetcher('get', '/httpAPI/getStandardInfoProcess');
        let fixedIpInfo = await Fetcher('get', '/httpAPI/getFixedIpInfo');

        tmp.map((item) => {
            if (item.EquipmentId === this.equipmentId) {
                tmpStorage[item.CollectionInfoId] ??= [];
            }
        });

        fixedIpInfo.map((item) => {
            if (typeof tmpStorage[item.collection_info_id] !== "undefined") {
                tmpStorage[item.collection_info_id].push({
                    ...item,
                    dataArray: []
                })
            }
        });
        
        let collectionIDList = [];
        for(var info of ipDashBoardStore.processInfo){
            collectionIDList.push(info.CollectionInfoId);
        };
        let param = { 
            equipmentID: ipDashBoardStore.equipmentId,
            collectionIDList 
        };
        
        let fixedIpData = await Fetcher('post', '/httpAPI/getPreviousFixedIpDatas', param);

        fixedIpData.map((item) => {
            if (typeof tmpStorage[item.collection_info_id] !== "undefined") {

                tmpStorage[item.collection_info_id].map((collectionItem) => {
                    if (collectionItem.fixed_ip_info_id === item.fixed_ip_info_id) {
                        item.FixedIpData.map((ipData) => {
                            collectionItem.dataArray.push([{
                                date: ipData.update_date,
                                value: ipData.value,
                                name: "value"
                            },{
                                date: ipData.update_date,
                                value: ipData.setting_value,
                                name: "setting value"
                            }]);
                        });
                    }
                });
            }
        });

        this.fixedIpStorage = {...tmpStorage};
    },
    
    setSelectedEquipmentId(equipmentId) {
        console.log(equipmentId, "set selected ipstore");
        this.equipmentId = equipmentId;
    },
    
});

let runningCount = 0;
const handleWorkingInfoDataBroadcast = async (workingInfo) => {
    // 가동 여부를 수신하지 않아 구동시간으로 임의 비교 함.
    // 개선필요
    if (ipDashBoardStore.workingInfo.workingTime === workingInfo.WorkingTime) {
        runningCount++;
    }
    else {
        runningCount = 0;
    }

    ipDashBoardStore.workingInfo.recipeId = workingInfo.RecipeID;
    ipDashBoardStore.workingInfo.startTime = workingInfo.StartTime;
    ipDashBoardStore.workingInfo.workingTime = workingInfo.WorkingTime;
    ipDashBoardStore.workingInfo.distance = workingInfo.Distance;
    ipDashBoardStore.workingInfo.lineSpeed = workingInfo.LineSpeed;
    ipDashBoardStore.workingInfo.batchId = workingInfo.BatchID;

    ipDashBoardStore.workingInfo.isRunning = runningCount > 3 ? false : true;
};

const handleStandardInfoBroadcast = async (standardInfo) => {
    ipDashBoardStore.refreshGetStandardInfo(standardInfo);
};

const handleRealTimeData = async (plcRealTimeDatas) => {
    processPlcRealTimeData(plcRealTimeDatas);
};

const handleFixedIpRealTimeData = async (fixedIpRealTimeDatas) => {
    processFixedIpRealTimeData(fixedIpRealTimeDatas);
}

const handleAlarmHistoryBroadcast = async (datas) => {
    alertHistoryStore.addAlertList(datas);
    alertHistoryStore.setAlarmListDataByParts(datas);
    ipDashBoardStore.errorList = [];
};

const requestPreviousData = async () => {
    let collectionIDList = [];
    for(var info of ipDashBoardStore.processInfo){
        collectionIDList.push(info.CollectionInfoId);
    };
    let param = { 
        equipmentID: ipDashBoardStore.equipmentId,
        collectionIDList 
    };
    let previousDatas = await Fetcher('post', '/plcAPI/getPreviousCollectionDatas', {param});
    processPlcRealTimeData(previousDatas);
}

function processPlcRealTimeData(dataList) {
    let tmpStorage = {...ipDashBoardStore.realTimeStorage};

    dataList.map((item) => {
        if (
            typeof tmpStorage[item.CollectionInfoID] !== "undefined" &&
            typeof tmpStorage[item.CollectionInfoID][item.BlockInfoID] !== "undefined"
        ) {
            // 수집할 blockInfo 여부 확인
            const plcAddressItems = tmpStorage[item.CollectionInfoID][item.BlockInfoID];
            // Block에 단독 plcAddress인 경우
            if (plcAddressItems.length === 1) {
                // 600개 초과 시 삭제
                if (plcAddressItems[0].dataArray.length >= 600) {
                    for (let i = plcAddressItems[0].dataArray.length; i >= 600; i--) {
                        plcAddressItems[0].dataArray.shift();
                    }
                }

                plcAddressItems[0].dataArray.push([{
                    date: item.CreDate,
                    value: item.Value
                }]);
            }
            // Block에 여러 plcAddress 인 경우
            else if (plcAddressItems.length > 1) {
                // 수집된 데이터의 plcAddressInfo Id
                plcAddressItems.forEach((plcAddressItem, index) => {
                    if (plcAddressItem.PLCAddressInfoId === item.PLCAddressInfoId) {
                        if (typeof plcAddressItems[index].dataArray !== "undefined") {
                            if (plcAddressItems[index].dataArray.length >= 600) {
                                for (let i = plcAddressItems[index].dataArray.length; i >= 600; i--) {
                                    plcAddressItems[index].dataArray.shift();
                                }
                            }


                            plcAddressItems[index].dataArray.push([{
                                date: item.CreDate,
                                value: item.Value
                            }]);
                        }
                    }
                });
            }
            else {
                console.log("plcaddressitems not have!");
            }
        }
    });

    ipDashBoardStore.realTimeStorage = {...tmpStorage};
};

function processFixedIpRealTimeData(dataList) {
    
    // 향후 실시간 fixed ip 업데이트 필요 hr.kwon

}


export { ipDashBoardStore };