import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const machineAgentInformationStore = observable({
    equipmentId: -1,
    equipmentName: '',
    equipmentType: '001',
    machineAgentEnable: false,
    equipmentProtocolType: '',
    selectedPlcId: 1,
    plcList: [],
    isRunning: false,
    webSocket: undefined,


    async initialize(websocket){
        let result = await Fetcher('get', '/plcAPI/getAllPLCInfo');

        this.plcList = [];

        for(let plc of result){
            plc.value = plc.PlcId;
            plc.name = plc.PlcName;
            plc.type = plc.PlcType;
        }
        
        this.plcList = result;
        
        this.webSocket = websocket;

        this.webSocket.on("machineAgentConnected", async (equipmentId) =>{
            if(this.equipmentId === equipmentId){
                this.isRunning = true;
            }
        });

        this.webSocket.on("machineAgentDisConnected", async (equipmentId) =>{
            if(this.equipmentId === equipmentId){
                this.isRunning = false;
            }
        });
    },

    async onChangeName(name) {
        this.equipmentName = name;
    },

    async onChangeEquipmentType(equipmentId, value) {
        this.equipmentType = value;
    },

    async onChangeEnable(enable) {
        this.machineAgentEnable = enable;
    },

    async onChangeSelectPLC(plcId) {
        this.selectedPlcId = plcId.toString();
    },

    async clearPLCInfo() {
        this.equipmentName = '';
        this.equipmentType = '001';
        this.machineAgentEnable = false;
        this.selectedPlcId = 0;
        this.equipmentId = -1;
    },

    async onChangeMachineAgent(selectMa) {
        if (selectMa === undefined) {
            this.clearPLCInfo();
        }
        else {
            this.equipmentId = selectMa.EquipmentId;
            this.equipmentName = selectMa.EquipmentName;
            this.equipmentProtocolType = selectMa.EquipmentProtocolType;
            this.equipmentType = selectMa.EquipmentTypeCode;
            this.selectedPlcId = selectMa.PlcId.toString();
            this.machineAgentEnable = selectMa.Enabled;
        }
    },

    async onSaveMachineAgent() {
        let saveData = {
            EquipmentName: this.equipmentName,
            EquipmentType: this.equipmentType,
            Enabled: this.machineAgentEnable,
            PlcId: this.selectedPlcId,
            EquipmentId: this.equipmentId
        }

        let url = this.getEquipmentUrl();
       
        let result = await Fetcher('post', url, saveData);

        if(result){
            result = await this.updatePlcStatus(this.machineAgentEnable, this.selectedPlcId);
        }

        return result;
    },

    getEquipmentUrl(){
        let url = '';

        if(this.equipmentId === -1)
        {
            url = '/httpAPI/addEquipmentInfo';
        }
        else{
            url = '/httpAPI/updateEquipmentInfo';
        }

        return url;
    },
    
    async onDeleteMachineAgent() {
        if (this.equipmentId === -1) {
            return;
        }
        
        let deleteData = {
            EquipmentId: this.equipmentId,
        }

        let result = await Fetcher('post', '/httpAPI/deleteEquipmentInfo', deleteData);

        if(result){
            result = await this.updatePlcStatus(false, this.selectedPlcId);
        }

        return result;

    },

    async updatePlcStatus(assign, plcId){
        try{

            let updateData = {
                Assign: assign,
                PlcId: plcId
            }

            let result = await Fetcher('post', '/plcAPI/updatePlcAssignStatus', updateData);

            return result;
    
        }
        catch(e){
            console.log(e);
            return false;
        }
    }

});

export { machineAgentInformationStore };