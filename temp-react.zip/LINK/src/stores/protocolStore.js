import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';

const protocolStore = observable({
    dbIP: '',
    dbPort: '',
    mqttIP: '',
    mqttPort: '',
    mesIP: '',
    mesPort: '',
    dbConnectionStatus: false,
    mqttConnectionStatus: false,
    mesConnectionStatus: false,

    onChangeDbIp(data){
        this.dbIP = data;
    },

    onChangeDbPort(data){
        this.dbPort = data;
    },

    onChangeMqttIp(data){
        this.mqttIP = data;
    },

    onChangeMqttPort(data){
        this.mqttPort = data;
    },

    onChangeMesIp(data){
        this.mesIP = data;
    },

    onChangeMesPort(data){
        this.mesPort = data;
    },

    async initialize() {
        let datas = await Fetcher('get', '/httpAPI/getSystemInfo');

        datas = JSON.parse(JSON.stringify(datas));

        this.dbIP = datas.DatabaseIp;
        this.dbPort = datas.DatabasePort;
        this.mqttIP = datas.MqttIp;
        this.mqttPort = datas.MqttPort;
        this.mesIP = datas.MesIp;
        this.mesPort = datas.MesPort;
    },

    async OnProtocolTest(name) {
        switch (name) {
            case 'DB':
                this.dbConnectionStatus = await Fetcher('get', '/httpAPI/getDBConnectionStatus');
                break;
            case 'MQTT':
                this.mqttConnectionStatus = await Fetcher('get', '/httpAPI/getMQTTConnectionStatus');
                break;
            case 'MES':
                this.mesConnectionStatus = await Fetcher('get', '/httpAPI/getMESConnectionStatus');
                break;
            default:
                this.dbConnectionStatus = false;
                this.mqttConnectionStatus = false;
                this.mesConnectionStatus = false;
        }
    },

    async saveSystemInfo(){
        let data = {
           'DatabaseIp' :this.dbIP,
            'DatabasePort':this.dbPort,
            'MqttIp':this.mqttIP,
            'MqttPort':this.mqttPort,
            'MesIp':this.mesIP,
            'MesPort':this.mesPort
        }

        let saveData = JSON.parse(JSON.stringify(data));
        let result = await Fetcher('post', '/httpAPI/saveSystemInfo', saveData);
     
        return result;
    }

})

export { protocolStore }