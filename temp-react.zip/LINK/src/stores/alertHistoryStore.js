import { observable } from 'mobx';
import i18n from "i18next";
import Fetcher from '../components/parts/Common/Fetcher';
var moment = require('moment');

const ALARM_TYPE = {
    1: 'Warning',
    2: 'Error',
    3: 'Warning',
    4: 'Error',
    5: 'Normal',
}

function alertStatusChange(alertKey, alertStatus = 5)
{
    let value = {}
    switch(ALARM_TYPE[alertStatus])
    {
        case "Error":
            value = { toolTip : 'Error', className : 'blinkSvgImage', fillColor : '#ff5e00', fillOpacity : '0.3', cursor : 'pointer' }
            break;
        case "Warning":
            value = { toolTip : 'Warning', className : 'blinkSvgImage', fillColor : '#ffff66', fillOpacity : '0.3', cursor : 'pointer' }
            break;
        default:
            value = { toolTip : alertKey, className : 'svgImage', fillColor : '#ececec', fillOpacity : '0.1', cursor : 'default' }
            break;
    }
    return value
}


const alertHistoryStore = observable({
    webSocket : null,
    alertList: [],  //알람뷰
    alertCount: 0,
    isExistNewAlert : false,
    selectedModule : '',
    selectedModuleList : [],
    modalOpenTime : '',
    toastList : [],

    //ALARM : COLLECTION_ID
    PARTS_TYPE : {
        'Roll_Front' : 'ROLL_FRONT',
        'Roll_Rear' : 'ROLL_REAR',
        'Dryer_1' : 'DRYER_1ZONE',
        'Dryer_2' : 'DRYER_2ZONE',
        'Dryer_3' : 'DRYER_3ZONE',
        'Dryer_4' : 'DRYER_4ZONE',
        'Dryer_5' : 'DRYER_5ZONE',
        'Dryer_6' : 'DRYER_6ZONE',
        'Exhaust_Fan' : 'DRYER_MAIN_EXHAUST_FAN',
        'Supply_Fan' : 'DRYER_MAIN_SUPPLY_FAN',
        'Coating_Quality' : 'COATING_QUALITY',
        'Changeable_IP_Monitoring' : 'CHANGEABLE_IP_MONITORING',
        'Fixed_IP_Monitoring' : 'FIXED_IP_MONITORING',
        'Sensor' : 'SENSOR',
    },

    AlertCollData : {},         // CollectionID 기준정보
    AlertBlinkDate:{},     // 알람 Blick 남은 시간

    getAlertCollDataByPartType(partType)
    {
        return this.AlertCollData[this.PARTS_TYPE[partType]];
    },

    initializeStore()
    {
        for (const key in this.PARTS_TYPE) {
            this.AlertCollData[this.PARTS_TYPE[key]] = alertStatusChange(this.PARTS_TYPE[key]);
            this.AlertBlinkDate[this.PARTS_TYPE[key]] = 0;
          }
    },

    async initialize(websocket){
        this.webSocket = websocket;

        this.webSocket.on("dateChangeBroadcast", ()=>{
            this.alertCount = 0;
        });
    },



    //대시보드에서 데이터가 추가로 들어왔을 경우의 카운터변경 및 새로운 알람 표시
    addAlertList(data){
        this.toastList = [];
        for(let i = 0; i < data.length; i++){
            data[i].id = i;
            this.toastList.push(data[i]);
        }
        
        
        //this.alertList.unshift(data);
        this.alertCount += data.length;
        if(!this.isExistNewAlert){
            this.isExistNewAlert = true;
        }
        
    },
    async getAlertList(){
        let datas = await Fetcher('get', '/httpAPI/getTodayAlarmList');
        for(let data of datas){
            data.ModuleInfoId = data.CollectionName;
            data.Name = `${data.BlockName}_${data.ParameterName}`;
            data.CreDate = moment(data.CreDate).format("YYYY-MM-DD HH:mm:ss");
            data.AlarmType = ALARM_TYPE[data.AlarmType]; 
            this.alertList.push(data);
        }
    },

    async getAlertCount() {
        let data = await Fetcher('get', '/httpAPI/getTodayAlarmCount');
        this.alertCount = data.count;        
        return this.alertCount;
    },

    async initAlertList() {        
        this.alertList.splice(0);

        //login User check
        let loginUser = sessionStorage.getItem('loginUser');
        loginUser = JSON.parse(loginUser)
        if (loginUser) {
        this.getAlertCount();
        }

        this.AlertCollData[this.PARTS_TYPE[this.selectedModule]] = alertStatusChange(this.PARTS_TYPE[this.selectedModule]);
        
        this.selectedModule = '';
        this.modalOpenTime = '';
        this.selectedModuleList = [];
        this.isExistNewAlert = false;
    },

    removeBlinkEffect(parts){
        this.AlertCollData[parts] = alertStatusChange(parts);
    },

    async clearAlertDatas(){
        for (const key in this.AlertCollData) {
            this.AlertCollData[key] = alertStatusChange(key);
        }
    },
    // 알람 발생 시 분기해서 넣기
    setAlarmListDataByParts(datas){

        //각 부위 Roll(Front,Rear), Dryer(1Zone ~ 6Zone)별 Alert List -> 이미지 표시용
        let collData = {}
        for(let data of datas){
            for (const key in this.AlertCollData) {
                if(key === data.CollectionInfoID)
                {
                    if (!collData[key]) {
                        collData[key] = [];
                    }
                    collData[key].push(data);
                }
            }
        }

        for(let collKey in collData)
        {
            let isErrorExist = collData[collKey].some(x => ALARM_TYPE[x.AlarmType] === 'Error')
            this.AlertCollData[collKey] = alertStatusChange(collKey, isErrorExist ? 1 : 0)
            

            const alertInsertDate = this.AlertBlinkDate[collKey] =new Date();
            
            setTimeout(() => {
                if(alertInsertDate >= this.AlertBlinkDate[collKey])
                    this.removeBlinkEffect(collKey);
            }, 60000); 

        }
    },
});

alertHistoryStore.initializeStore();

export {alertHistoryStore};