import { observable } from 'mobx';

const counterStore = observable ({
    number: 0,
    increase() {
      this.number++;
    },
    decrease() {
      this.number--;
    },
    clear(){
      this.number = 0;
    }
});

export { counterStore };