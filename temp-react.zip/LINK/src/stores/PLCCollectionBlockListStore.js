import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import swal from 'sweetalert2';
//import "../components/views/PLCMemoryMapEdit/ComponentStyle.css"

const PLCCollectionBlockListStore = observable({

    //멤버 변수 선언
    collectionBlockList: [],
    plcList:[],
    PlcId: [],

    //수정
    collectionMap: [],
    updateCollection: [],
    blockMap: [],
    updateBlock: [],

    //삭제
    deleteCollection: [],
    deleteBlock: [],

    //추가
    addCollection: [],
    addBlock: [],


    

    async initializeComponentDatas() {
        await this.getAllPLCInfo();
        await this.initializeDatas();

        console.log("plc List : " + this.plcList);
    },

    // 1. PLC ID 리스트 조회 [plc name, PLC IP 가져옴] - getAllPLCInfo
    // 2. PLC ID 리스트가 존재할 경우 페이지에 데이터가 표시되며 존재하지 않을 경우 PLC 등록 페이지로 넘어간다. - getAllCollectionBlockInfoByPlcId
    // 3. PLC ID 조건에 따른 blockStartAddress, BlockEndAddress, BlockSize를 가져온다. 페이지 새로고침한다. -> view에서 작성
    // 멤버 변수 선언 후 읽을 때는 this 사용
    async getAllPLCInfo() {
        this.plcList = await Fetcher('get', '/plcAPI/getAllPLCInfo');
        //this.collectionBlockList = [];
    },

    async getCollectionBlockDataByplcId(plcId){
        this.collectionBlockList = await Fetcher('post', '/plcAPI/getAllCollectionBlockInfoByPlcId', {'PlcId': plcId});
        //let temp =  await Fetcher('post', '/plcAPI/getAllCollectionBlockInfoByPlcId', {'PlcId': plcId});
        //console.log(temp);
    },

    //초기 화면
    async initializeDatas() {
        try {
            await this.getAllPLCInfo();
        } catch(err) {
            console.log(err.message);
        }
    },
    
    //collection 추가
    //async updateCollectionInfo(equipmentId){
    //        let results = false;
    //        for(let data of this.addCollection){
    //            if(data.EquipmentId === equipmentId){
    //                
    //                let sendData = {
    //                    'EquipmentId' : data.EquipmentId,
    //                    'PlcId': 1
    //                };
//
    //                sendData = JSON.parse(JSON.stringify(sendData));
//
    //                if(data.isRunning === false){
    //                    results = await Fetcher('post', '/plcAPI/updateCollectionInfoList', sendData);
    //                }
    //                else{
    //                    console.log('error');
    //                    return false;
    //                }
    //                break;
    //            }
    //        }
    //    },
//
    ////block 추가
    //async updateBlockInfo(equipmentId){
    //    let results = false;
    //    for(let data of this.addBlock){
    //        if(data.EquipmentId === equipmentId){
    //            
    //            let sendData = {
    //                'EquipmentId' : data.EquipmentId,
    //                'CollectionId' : data.CollectionId
    //            };
//
    //            sendData = JSON.parse(JSON.stringify(sendData));
//
    //            if(data.isRunning === false){
    //                results = await Fetcher('post', '/plcAPI/updateBlockInfoList', sendData);
    //            }
    //            else{
    //                console.log('error');
    //                return false;
    //            }
    //            break;
    //        }
    //    }
    //},


    //collection 수정
    /*
    async updateCollectionInfo(collectionDatas) {
        try {
            this.collectionMap = collectionDatas;
            this.updateCollection = collectionDatas.map((collectionDatas) => ({
                ...this.changeCollectionsDBFormat(collectionDatas),
            }));

            return (await Fetcher('post', '/plcAPI/updateCollectionInfoList', this.updateCollection));

        } catch (error) {
            console.log(error);
            return false;
        }

    },    
    */
    //changeCollectionsDBFormat(collectionDatas) {
    //    return {
    //        ["_id"]: collectionDatas._id,
    //        ["EquipmentId"]: collectionDatas.EquipmentId,
    //        ["EquipmentName"]: collectionDatas.EquipmentName,
    //        ["EquipmentType"]: collectionDatas.EquipmentType,
    //        ["PlcId"]: collectionDatas.PlcId,
    //        ["CollectionId"]: collectionDatas.CollectionId,
    //        ["CollectionName"]: collectionDatas.CollectionName,
    //        ["CollectionSendPeroid"]: collectionDatas.CollectionSendPeroid
    //    };
    //},

//
//
    ////block 수정
    //async updateBlockInfo(blockDatas) {
    //    try {
    //        this.collectionMap = blockDatas;
    //        this.updateBlock = blockDatas.map((blockDatas) => ({
    //            ...this.changeBlockDBFormat(blockDatas),
    //        }));
    //        
    //        return (await Fetcher('post', '/plcAPI/updateCollectionInfoList', this.updateBlock));
//
    //    } catch (error) {
    //        console.log(error);
    //        return false;
    //    }
    //    
    //},    
    //changeBlockDBFormat(blockDatas) {
    //    return {
    //        ["_id"]: blockDatas._id,
    //        ["CollectionId"]: blockDatas.CollectionId,
    //        ["EquipmentId"]: blockDatas.EquipmentId,
    //        ["BlockName"]: blockDatas.BlockName,
    //        ["BlockEndAddress"]: blockDatas.BlockEndAddress,
    //        ["BlockSize"]: blockDatas.BlockSize,
    //        ["Editable"]: blockDatas.Editable,
    //        ["UpdateDate"]: blockDatas.UpdateDate,
    //        ["BlockInfoId"]: blockDatas.BlockInfoId
    //    };
    //},
    
    //apply
    setCollectionMap(data) {
        this.CollectionMap = data;
    },
    //apply
    setBlockMap(data) {
        this.BlockMap = data;
    },
    //apply
    alertMessage (msg, type) {
        if(type === "error"){
            swal.fire({
                title: msg,
                text: "",
                icon: "error",
                confirmButtonText: "OK",
            });
        }
        else if(type === "success"){
            swal.fire({
                title: msg,
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
    },
    

});

export { PLCCollectionBlockListStore };