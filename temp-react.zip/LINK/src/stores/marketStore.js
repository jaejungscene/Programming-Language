import { observable } from 'mobx';

const marketStore = observable({
  selectedItems: null,
  put(name, price) {
    const exists = this.selectedItems.find((item) => item.name === name);

    //check has a list
    if (!exists) {
      this.selectedItems.push({
        name,
        price,
        count: 1,
      });
      return;
    }
    exists.count++;
  },
  take(name) {
    const itemToTake = this.selectedItems.find((item) => item.name === name);
    itemToTake.count--;

    //check empty item in list
    if (itemToTake.count === 0) {
      this.selectedItems.remove(itemToTake); // clear item in list
    }
  },
  get total() {
    return this.selectedItems.reduce((previous, current) => {
      return previous + current.price * current.count;
    }, 0);
  },
});

export { marketStore };