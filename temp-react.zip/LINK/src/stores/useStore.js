import { counterStore } from './counterStore';
import { marketStore } from './marketStore';
import { equipmentManagementStore } from './equipmentManagementStore';
import { currentTimerStore } from './currentTimerStore';
import { protocolStore } from './protocolStore';
import { equipmentListStore } from './equipmentListStore';
import { addEquipmentStore } from './addEquipmentStore';
import { machineAgentListStore } from './machineAgentListStore';
import { machineAgentControlStore } from './machineAgentControlStore';
import { userManagementListStore } from './userManagementListStore';
import { userManagementStore } from './userManagementStore';
import { mainViewStore } from './mainViewStore';
import { dashBoardStore } from './dashBoardStore';
import { ipDashBoardStore } from './ipDashBoardStore';
import {PLCAddressEditStore} from './PLCAddressEditStore';
import { alertHistoryStore } from './alertHistoryStore';
import {PLCCollectionBlockListStore} from './PLCCollectionBlockListStore';
import {headerViewStore} from './headerViewStore';
import {plcManagementStore} from './plcManagementStore';
import {machineAgentInformationStore} from './machineAgentInformationStore';
import { trendChartStore } from './trendChartStore';
import { alarmHistoryStore } from './alarmHistoryStore';
import { ipSettingStore } from './ipSettingStore';
import { alarmSettingStore } from './alarmSettingStore';

const useStore = () => {
  return {
    counterStore, //demo
    marketStore,  //demo
    equipmentManagementStore,
    equipmentListStore,
    currentTimerStore,
    protocolStore,
    addEquipmentStore,
    machineAgentListStore,
    machineAgentControlStore,    
    userManagementListStore,
    userManagementStore,
    mainViewStore,
    dashBoardStore,
    ipDashBoardStore,
    PLCAddressEditStore,
    alertHistoryStore,
    headerViewStore,
    PLCCollectionBlockListStore,
    plcManagementStore,
    machineAgentInformationStore,
    trendChartStore,
    alarmHistoryStore,
    ipSettingStore,
    alarmSettingStore,
  };
};

export default useStore;