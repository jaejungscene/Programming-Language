import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import swal from 'sweetalert2';
import i18n from "i18next";

const plcManagementStore = observable({
    PlcId: -1,
    PlcType: 0,
    PlcName: '',
    Ip: '',
    Port: '',
    Assign: false,
    PlcRack: -1,
    PlcSlot: -1,
    PlcCpu : '',
    EndianType: 0,
    plcList: [],
    isSiemens : false,

    onChangePort(value) {
        this.Port = value;
    },

    onChangeEndianType(value) {
        this.EndianType = value;
    },

    onChangeIp(value) {
        this.Ip = value;
    },
    onChangeName(value) {
        this.PlcName = value;
    },
    onChangeRack(value) {
        this.PlcRack = value;
    },
    onChangeSlot(value) {
        this.PlcSlot = value;
    },
    onChangeCpu(value) {
        this.PlcCpu = value;
    },

    onChangePlcType(value) {
        console.log(value);
        this.PlcType = value;
        this.PlcRack = '';
        this.PlcSlot = '';
        this.PlcCpu = '';
        this.checkSiemens();
    },

    onChangeSelectedPlcInfo(plc) {
        
        if (plc === undefined) {
            this.clearPlcInfo();
        }
        else {
            this.PlcId = plc.PlcId;
            this.PlcType = plc.PlcType;
            this.PlcName = plc.PlcName;
            this.Ip = plc.Ip;
            this.Port = plc.Port;
            this.Assign = plc.Assign;
            this.PlcRack = plc.PlcRack;
            this.PlcSlot = plc.PlcSlot;
            this.PlcCpu = plc.PlcCpu;
            this.EndianType = plc.EndianType;
            this.checkSiemens();
           
        }
    },

    checkSiemens(){
        // 0: Mitubishi, 1: siemens, 2: Omron ...
        if(this.PlcType.toString() === '1'){
            this.isSiemens = true;
        }
        else{
            this.isSiemens = false;
        }
    },

    clearPlcInfo(){
        this.PlcId = -1;
        this.PlcType = 0;
        this.PlcName = '';
        this.Ip = '';
        this.Port = '';
        this.Assign = false;
        this.PlcRack = -1;
        this.PlcSlot = -1;  
        this.PlcCpu  = '';
        this.EndianType = 0;
        this.isSiemens = false;
    },

    async initializePlcManagementListStore() {
        this.getAllPlcInfo();
    },


    async getAllPlcInfo() {
        
        let temp = await Fetcher('get', '/plcAPI/getAllPLCInfo');
        for(let item of temp){
            item.Assign = this.convertAssignValue(item, true);
        }

        this.plcList = temp;
    },

    convertAssignValue(item, isBoolean){
        let returnVal = undefined;

        if(isBoolean){
            if(item.Assign === true){
                returnVal = 'Y';
            }
            else{
                returnVal = 'N';
            }
        }
        else{
            if(item.Assign === 'Y'){
                returnVal = true;
            }
            else{
                returnVal = false;
            }
        }
       

        return returnVal;
    },

    async onSavePlcInfo() {

        /* 유효성 검사~~
        if (this.PlcName === '' ||
            this.Ip === '' ||
            this.Port === '' ||
            (this.PlcType === 1 && this.PlcCpu === '')
        ) {
            swal.fire({
                title: i18n.t('유효성 검사는 나중에 하자구~~~~~~ 각자 따로 ~ pscho'),
                text: "",
                icon: "info",
                confirmButtonText: "OK"
            });

            return;
        }

        if(!this.isSelected){
            for(let user of userList){
                if(user.id === this.userId){
                    swal.fire({
                        title: i18n.t('MSG_USER_ID_DUPLICATED'),
                        text: "",
                        icon: "info",
                        confirmButtonText: "OK"
                    });

                    return;
                }
            }
        }
        */
        let savePlc = {
            PlcId: this.PlcId,
            PlcType: this.PlcType,
            PlcName: this.PlcName,
            Ip: this.Ip,
            Port: this.Port,
            Assign: this.convertAssignValue(this.Assign, false),
            PlcRack: this.PlcRack,
            PlcSlot: this.PlcSlot,
            PlcCpu: this.PlcCpu,
            EndianType: this.EndianType
        }

        let url = this.getPlcInfoUrl();
        
        let result = await Fetcher('post', url, savePlc);

        if (result.errors !== undefined){
            return false;
        }
        else{
            this.clearPlcInfo();

            savePlc.PlcId = result.PlcId;
            let returnVal = {
                result: true,
                data: savePlc
            }

            return returnVal;
        }

    },

    getPlcInfoUrl(){
        let url = '';
        
        if(this.PlcId === -1)
        {
            url = '/plcAPI/addPLCInfo';
        }
        else{
            url = '/plcAPI/updatePlcInfo';
        }

        return url;
    },

    async onDeletePlcInfo(){
        let returnVal = false;
        let deleteInfo = {
            PlcId : this.PlcId
        }

        returnVal = await Fetcher('post', '/plcAPI/deletePlcInfo', deleteInfo);

        if(returnVal){
            this.clearPlcInfo();
            swal.fire({
                title: i18n.t('MSG_PLC_INFO_DELETE_SUCCESS'),
                text: "",
                icon: "success",
                confirmButtonText: "OK"
            });
        }
        else{
            swal.fire({
                title: i18n.t('MSG_PLC_INFO_DELETE_FAIL'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
        }

        return returnVal;
    }
    
});


export { plcManagementStore };