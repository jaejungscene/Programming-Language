import { observable } from 'mobx';
import swal from 'sweetalert2';
import axios from 'axios';
import i18n from "i18next";
import { io } from 'socket.io-client';
import Fetcher from '../components/parts/Common/Fetcher';

const mainViewStore = observable({

    localStorage: undefined,
    loginUser: undefined,
    authorizeToken: '',
    selectedLanguage: 'en',
    inputUserId: '',
    inputUserPassword: '',
    webSocket: undefined,

    mainViewInitialize() {
        this.websocketInitialize();

        this.localStorage = window.localStorage;
        this.sessionStorage = window.sessionStorage;
        this.loginUser = this.getUser();
        this.authorizeToken = this.getAuthorizeToken();
        this.selectedLanguage = this.getLanguage();
        this.inputUserId = '';
        this.inputUserPassword = '';
    },

    websocketInitialize() {
        this.webSocket = null;
        this.webSocket = io({
            withCredentials: true,
            reconnection: true
        });

        this.webSocket.on("connect", () => {                        
            console.log("connection to webserver");
        });

        this.webSocket.on("disconnect", (error) => {
            console.log("disconnection to webserver");
            console.log(error);

            //maybe auto reconnection option not working. call to connect again
            this.webSocket.connect();
        });

        this.webSocket.on("connect_error", (error) => {
            console.log(error);
            console.log("connect_error!");
          });

    },

    getWebsocket(){
        if(this.webSocket.connected === false){
            this.webSocket.connect();
        }

        if(this.webSocket === null){
            this.websocketInitialize();
        }

        return this.webSocket;
    },

    setLanguage(lan) {
        i18n.changeLanguage(lan);
    },

    setAuthorizeToken(token) {
        this.authorizeToken = token;
        this.sessionStorage.setItem('authorizeToken', token);
    },

    removeAuthorizeToken() {
        this.authorizeToken = '';
        this.sessionStorage.removeItem('authorizeToken');
    },

    getAuthorizeToken() {
        this.authorizeToken = sessionStorage.getItem('authorizeToken') !== null ? sessionStorage.getItem('authorizeToken') : '';
        axios.defaults.headers.common['Authorization'] = 'Bearer' + ' ' + this.authorizeToken;
    },

    getUser() {
        return sessionStorage.getItem('loginUser') !== null ? JSON.parse(sessionStorage.getItem('loginUser')) : undefined
    },

    getLanguage() {
        let lan = localStorage.getItem('selectedLanguage') !== null ? localStorage.getItem('selectedLanguage') : 'en';
        this.setLanguage(lan);
        return lan;
    },

    setUser(user) {
        this.loginUser = user;
        this.sessionStorage.setItem('loginUser', JSON.stringify(user));
    },

    removeUser() {
        this.loginUser = undefined;
        this.sessionStorage.removeItem('loginUser');
    },

    onChangeLanguage(lan) {
        this.selectedLanguage = lan;
        this.localStorage.setItem('selectedLanguage', lan);
        this.setLanguage(lan);
    },

    onChangeId(id) {
        this.inputUserId = id;
    },

    onChangePassword(pw) {
        this.inputUserPassword = pw;
    },

    async onLogout() {

        let loginUser = {
            userId: this.inputUserId,
            userPassword: this.inputUserPassword
        }

        let result = await Fetcher('post', '/httpAPI/logout', loginUser);

        if(result){
            axios.defaults.headers.common['Authorization'] = '';
            this.removeUser();
            this.removeAuthorizeToken();
            this.onChangeId('');
            this.onChangePassword('');
            this.localStorage.setItem('sidebarToggle', false)
        }
        else{
            return false;
        }
       
        return true;
    },
    async loginAPI(loginUser){
        let result = false;
        result = await axios.post('/httpAPI/login', loginUser).then((result) => {
            //result = await axios.post('http://localhost:3001/httpAPI/login', loginUser).then((result) => {
            if (result.status === 200) {
                axios.defaults.headers.common['Authorization'] = 'Bearer' + ' ' + result.data.token;
                this.setUser(result.data.userInfo);
                this.setAuthorizeToken(result.data.token);
                return true
            }
        }).catch(() => {
            swal.fire({
                title: i18n.t('MSG_LOGIN_FAIL_CHECK'),
                text: "",
                icon: "error",
                confirmButtonText: "OK"
            });
            return false;
        })
        return result;
    },
    onLogin() {
        if (this.inputUserid === '' || this.inputUserPassword === '') {
            swal.fire({
                title: i18n.t('MSG_LOGIN_FAIL_CHECK'),
                text: "",
                icon: "info",
                confirmButtonText: "OK"
            });
            return false;
        }
        let loginUser = {
            userId: this.inputUserId,
            userPassword: this.inputUserPassword
        }
        return this.loginAPI(loginUser);
    }
})

export { mainViewStore };