import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import i18n from "i18next";
import { AiOutlineConsoleSql } from 'react-icons/ai';

const userManagementListStore = observable({
    userList: [],
    authorityType: [],

    async initializeUserManagementListStore() {
        this.refreshLanguageLabel();
        this.getUserInfo();
    },

    async refreshLanguageLabel() {
        this.authorityType = [];
        this.authorityType.push({ 'id': 1, 'typeName': i18n.t('LAN_OPERATOR') })
        this.authorityType.push({ 'id': 2, 'typeName': i18n.t('LAN_SERVICE_ENGINEER') })
        this.authorityType.push({ 'id': 3, 'typeName': i18n.t('LAN_DEVELOPER') })
        this.authorityType.push({ 'id': 4, 'typeName': i18n.t('LAN_ADMINISTRATOR') })
    },

    async getUserInfo() {
        let datas = await Fetcher('get', '/httpAPI/getUserInfo');
        this.userList = [];
        for (let data of datas) {
            let user = JSON.parse(JSON.stringify(data));
            user.Authority = this.convertAuthorityToName(user.Authority);
            this.userList.push(user);
        }
       
    },

    async registerLanguageChangedEvent() {
        i18n.on('languageChanged', () => {
            this.getUserInfo();
        });
    },

    convertAuthorityToName(id) {
        let name = '';

        for (let item in this.authorityType) {
            if (this.authorityType[item].id === id) {
                name = this.authorityType[item].typeName;
                break;
            }
        }

        if (name === '') {
            name = 'None';
        }

        return name;
    },

    convertNameToAutority(name) {
        let id = 0;

        for (let item in this.authorityType) {
            if (this.authorityType[item].typeName === name) {
                id = this.authorityType[item].id;
                break;
            }
        }

        if (id === 0) {
            id = 1;
        }

        return id;
    },

});

export { userManagementListStore };