import { observable } from 'mobx';
import moment from 'moment';
import { alertHistoryStore } from './alertHistoryStore';
import Fetcher from '../components/parts/Common/Fetcher';



const dashBoardStore = observable({
    webSocket: null,
    errorList: [],
    realTimeAlarmList: [],
    workingInfo : {
        recipeId : '-', 
        startTime : '-', 
        workingTime : '-', 
        distance : '-', 
        lineSpeed : '-',
        isRunning : false,
    },
    processInfo: [],
    realTimeStorage: {},
    equipmentId: 0,

    async leavePage() {
        this.webSocket.removeListener("workingInfoDataBroadcast", handleWorkingInfoDataBroadcast);
        this.webSocket.removeListener("standardInfoBroadcast", handleStandardInfoBroadcast);
        this.webSocket.removeListener("plcRealTimeDataBroadcast", handleRealTimeData);
        this.webSocket.removeListener("alarmHistoryBroadcast", handleAlarmHistoryBroadcast);
        //this.webSocket.removeListener("connect", handleConnect);
    },

    async initialize(websocket) {
        if(this.webSocket == null){
            this.webSocket = websocket;
        }
        await this.refreshGetStandardInfo();
        await requestPreviousData();

        this.webSocket.on('workingInfoDataBroadcast', handleWorkingInfoDataBroadcast);

        this.webSocket.on('standardInfoBroadcast', handleStandardInfoBroadcast);

        this.webSocket.on('alarmHistoryBroadcast', handleAlarmHistoryBroadcast);

        //this.webSocket.on("connect", handleConnect);    //새로고침 처리

        this.webSocket.on("plcRealTimeDataBroadcast", handleRealTimeData);
    },

    async refreshGetStandardInfo (standardInfo) {
        let tmpStorage = {};
        let tmp = await Fetcher('get', '/httpAPI/getStandardInfoProcess');
        if(typeof standardInfo === "undefined"){
            standardInfo = await Fetcher('get', '/plcAPI/getStandardInfo');
        }

        // 대시보드 표시할 process 항목
        this.processInfo = tmp.filter((item) => {
            if (item.EquipmentId === this.equipmentId) {
                tmpStorage[item.CollectionInfoId] ??= [];
                return true;
            }
            
            return false;
        });
        this.realTimeStorage = tmpStorage;

        standardInfo.map((item) => {
            if (typeof this.realTimeStorage[item.CollectionInfoId] === "undefined") {
                return;
            }

            this.realTimeStorage[item.CollectionInfoId][item.BlockInfoId] ??= [];
            item.dataArray = [];
            this.realTimeStorage[item.CollectionInfoId][item.BlockInfoId].push({...item});
        });
    },
    
    setSelectedEquipmentId(equipmentId) {
        this.equipmentId = equipmentId;
    },
    
});

let runningCount = 0;
const handleWorkingInfoDataBroadcast = async (workingInfo) => {
    // 가동 여부를 수신하지 않아 구동시간으로 임의 비교 함.
    // 개선필요
    if (dashBoardStore.workingInfo.workingTime === workingInfo.WorkingTime) {
        runningCount++;
    }
    else {
        runningCount = 0;
    }

    dashBoardStore.workingInfo.recipeId = workingInfo.RecipeID;
    dashBoardStore.workingInfo.startTime = workingInfo.StartTime;
    dashBoardStore.workingInfo.workingTime = workingInfo.WorkingTime;
    dashBoardStore.workingInfo.distance = workingInfo.Distance;
    dashBoardStore.workingInfo.lineSpeed = workingInfo.LineSpeed;
    dashBoardStore.workingInfo.batchId = workingInfo.BatchID;

    dashBoardStore.workingInfo.isRunning = runningCount > 3 ? false : true;
};

const handleStandardInfoBroadcast = async (standardInfo) => {
    dashBoardStore.refreshGetStandardInfo(standardInfo);
};

const handleRealTimeData = async (plcRealTimeDatas) => {
    processPlcRealTimeData(plcRealTimeDatas);
  };

const handleAlarmHistoryBroadcast = async (datas) => {
    alertHistoryStore.addAlertList(datas);
    alertHistoryStore.setAlarmListDataByParts(datas);
    dashBoardStore.errorList = [];
};

const requestPreviousData = async () => {
    let collectionIDList = [];
    for(var info of dashBoardStore.processInfo){
        collectionIDList.push(info.CollectionInfoId);
    };
    let param = { 
        equipmentID: dashBoardStore.equipmentId,
        collectionIDList 
    };
    let previousDatas = await Fetcher('post', '/plcAPI/getPreviousCollectionDatas', {param});
    processPlcRealTimeData(previousDatas);
}

function processPlcRealTimeData(dataList) {
    let tmpStorage = {...dashBoardStore.realTimeStorage};
    dataList.map((item) => {
        if (
            typeof tmpStorage[item.CollectionInfoID] !== "undefined" &&
            typeof tmpStorage[item.CollectionInfoID][item.BlockInfoID] !== "undefined"
        ) {
            // 수집할 blockInfo 여부 확인
            const plcAddressItems = tmpStorage[item.CollectionInfoID][item.BlockInfoID];
            // Block에 단독 plcAddress인 경우
            if (plcAddressItems.length === 1) {
                // 600개 초과 시 삭제
                if (plcAddressItems[0].dataArray.length >= 600) {
                    for (let i = plcAddressItems[0].dataArray.length; i >= 600; i--) {
                        plcAddressItems[0].dataArray.shift();
                    }
                }

                plcAddressItems[0].dataArray.push([{
                    date: item.CreDate,
                    value: item.Value
                }]);
            }
            // Block에 여러 plcAddress 인 경우
            else if (plcAddressItems.length > 1) {
                // 수집된 데이터의 plcAddressInfo Id
                plcAddressItems.forEach((plcAddressItem, index) => {
                    if (plcAddressItem.PLCAddressInfoId === item.PLCAddressInfoId) {
                        if (typeof plcAddressItems[index].dataArray !== "undefined") {
                            if (plcAddressItems[index].dataArray.length >= 600) {
                                for (let i = plcAddressItems[index].dataArray.length; i >= 600; i--) {
                                    plcAddressItems[index].dataArray.shift();
                                }
                            }

                            plcAddressItems[index].dataArray.push([{
                                date: item.CreDate,
                                value: item.Value
                            }]);
                        }
                    }
                });
            }
            else {
                console.log("plcaddressitems not have!");
            }
        }
    });

    dashBoardStore.realTimeStorage = {...tmpStorage};
};


export { dashBoardStore };