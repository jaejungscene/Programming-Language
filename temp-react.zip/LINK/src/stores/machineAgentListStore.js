import { observable } from 'mobx';
import Fetcher from '../components/parts/Common/Fetcher';
import {convertIdToTypeName, convertTypeNameToId} from '../utils/commonUtils';


const machineAgentListStore = observable ({
    equipmentList: [],
    webSocket: null,
   
    async changeRunningStatus(equipmentId){
        let results = false;
        for(let data of this.equipmentList){
            if(data.EquipmentId === equipmentId){
                
                let sendData = {
                    'EquipmentId' : data.EquipmentId,
                    'RunMode': 0
                };

                sendData = JSON.parse(JSON.stringify(sendData));

                if(data.isRunning === false){
                    data.isRunning = true;
                    this.webSocket.emit('machineAgentConnected', data.EquipmentId);
                    results = await Fetcher('post', '/httpAPI/machineAgentStart', sendData);
                }
                else{
                    results = await Fetcher('post', '/httpAPI/machineAgentStop', sendData);
                    data.isRunning = false;
                }
                break;
            }
        }
    },
    
    async onChangeMachineAgentMode(id, value){
        let sendList = [];
        for(let data of this.equipmentList){
            if(data.EquipmentId === id || id === 0){
                let sendData = JSON.parse(JSON.stringify(data));
                sendData.EquipmentType = convertTypeNameToId('equipment', sendData.EquipmentType)
                sendData.EquipmentProtocolType = convertTypeNameToId('plc', sendData.ProtocolType)
                sendData.RunMode = parseInt(value); // 0 simulation, 1 actual
                sendList.push(sendData);
            }
        }
        
        let results = await Fetcher('post', '/httpAPI/updateEquipmentMode', sendList);
        
        for(let data of this.equipmentList){
            for(let result of results){
                if(data.EquipmentId === result.EquipmentId && Boolean(result.result) === true){
                    data.RunMode = parseInt(value);// 0 simulation, 1 actual
                }
            }    
        }

        return results; 
    },

    async onMachineAgentAllStart(){
        /*
            현재 구조에서 MA와 Socket이 연결되는 텀 사이 발생 가능한 문제로 주석처리함.
            향후 MA 관리 서비스와 통신 계획

        let datas = await Fetcher('get', '/httpAPI/getEquipmentInfoWithPlcInfo');
        let nowEnable = [];
        for (let data of datas) {
            let equipment = JSON.parse(JSON.stringify(data));
            if (Boolean(equipment.Enabled) === true) {
                nowEnable.push(equipment.EquipmentId);
            }
        }

        for(let data of this.equipmentList){
            if(nowEnable.includes(data.EquipmentId) === true){
                console.log(data.EquipmentId, "it is");
                this.webSocket.emit('machineAgentConnected', data.EquipmentId);
            }
        }
        */

        let result = await Fetcher('get', '/httpAPI/machineAgentAllStart');

        return result;
    },

    async onMachineAgentAllStop(){
        let result = await Fetcher('get', '/httpAPI/machineAgentAllStop');

        return result;
    },

    async initialize(websocket){
        let datas = await Fetcher('get', '/httpAPI/getEquipmentInfoWithPlcInfo');
        this.equipmentList = [];
        for (let data of datas) {
            let equipment = JSON.parse(JSON.stringify(data));
            equipment.isRunning = false;
            equipment.EquipmentType = convertIdToTypeName('equipment', data.EquipmentType);
            equipment.EquipmentProtocolType = convertIdToTypeName('plc', data.PlcType);
            equipment.EquipmentTypeCode = data.EquipmentType;
            this.equipmentList.push(equipment);
        }

        this.webSocket = websocket;

        this.webSocket.on("machineAgentConnected", async (equipmentId) =>{
            for(let data of this.equipmentList){
                if(data.EquipmentId === equipmentId){
                    data.isRunning = true;
                    break;
                }
            }
        });

        this.webSocket.on("machineAgentDisConnected", async (equipmentId) =>{
            for(let data of this.equipmentList){
                if(data.EquipmentId === equipmentId){
                    data.isRunning = false;
                    break;
                }
            }
        });

        return true;
    },



});

export { machineAgentListStore };